# Quant Bot — Güncel Yetkili Durum

**Son güncelleme:** 16 Eylül 2026
**Plan:** [`ANA_UYGULAMA_PLANI.md`](ANA_UYGULAMA_PLANI.md) v3.0
**Karar:** Çoklu sistem sanal parayla **otonom çalışıyor**; proje sahibi mühendislik
kararlarını devretti (14 Eylül 2026)
**Canlı karar:** `NO-GO — MAINNET KAPALI` (değişmedi)
**Aktif faz:** Faz H/I — güvenilirlik ve ileriye dönük kanıt. **Yeni strateji denemesi
durduruldu** (baş mühendis kararı, 14 Eylül 2026): 18 mühürlü denemenin hiçbiri tüm
kapıları geçmedi; ek deneme çoklu-test çıtasını yükseltir. Kanıt yalnız ileriye dönük
sanal paradan gelir (ara değerlendirme ~14 Ekim, Aşama 4 kararı ≥90 UTC günü).
Otonom çalıştırıcı arızalarda Telegram uyarısı gönderir; günlük rapor Aşama 4 ilerlemesini gösterir.

**Güvenilirlik katmanı (14 Eylül, gerçek veride doğrulandı)**
| Güvence | Kanıt |
|---|---|
| Telegram arıza uyarıları (Docker, Supabase, port, migration, döngü, beklenmeyen hata) | `scripts/telegram_alert.py`, 6 saatte bir tekilleştirme |
| Cüzdan ↔ defter tutarlılığı (miktar %0,1, özsermaye %0,5) | `engine/sleeves/reconcile.py`; fark → çıkış kodu 3 → uyarı; canlı: ok |
| Günlük yedek (6 tablo + cüzdan + gölge defter, 14 gün) | `backups/daily/`; satır sayıları DB ile birebir |
| Haber freni (zorunlu) | Döngüden önce taze haber toplanır; SEC, Fed, Cointelegraph, Decrypt, The Block (+GDELT). GDELT aylardır 8 sn zaman aşımına takılıyordu → `NEWS_HTTP_TIMEOUT_SECONDS`. Kaynak yoksa yeni giriş durur (çıkış kodu 4, uyarı). Canlı: 5 kaynak, 145 olay |
| Geri yükleme | `scripts/geri_yukle_yedek.ps1` (varsayılan yalnız gösterim, yazılı onay, tek işlem); canlı prova başarılı, sonrası döngü + tutarlılık ok, yalnız-eklemeli koruma aktif — [kılavuz](reports/stages/coklu-sistem/YEDEK_VE_GERI_YUKLEME.md) |

**Açık risk — Aşama 4 çalışma süresi kapısı:** `STAGE_4.min_uptime_pct = 99,5`. Ev PC'si günde
7-8 saat kapalı olduğu için bu kapı mevcut düzende **karşılanamaz**; kaçırılan barlar telafi edilse de
çalışma süresi kapısı gevşetilmez. Gerçek para kararından önce sürekli açık bir host (VPS) veya açık
bir insan kararı gerekir.
**Yerel veritabanı:** Supabase, portlar yalnız `127.0.0.1` (8421/8422), 51 migration
**Git dalı:** `feature/coklu-sistem`

---

## 14 Eylül 2026 (akşam) — Strateji Arenası kararı

Proje sahibi, üç bölümün hiçbirinde kanıtlanmış avantaj olmadığını kabul ederek **çok yöntemli, çok
botlu, çok AI modelli** ileriye dönük sanal yarışma istedi (sunucu kararı ertelendi; test ev PC'sinde).
Tasarım: [`reports/stages/arena/ARENA_TASARIM.md`](reports/stages/arena/ARENA_TASARIM.md).

- **Katılımcılar (mühürlenecek):** 5 kurallı bot (grid, trend, ortalamaya dönüş, futures kırılım ≤3x,
  carry v2) · 4 LLM trader (Opus 5, Fable 5.1, GPT-6 Astra, GPT-5.6 Sol; al-sat/kaldıraçlı/haber) ·
  4 LLM yönetici (kurallı botlara sermaye dağıtır) · kıyaslar (BTC tut, haftalık DCA, USDT faiz). Her biri
  ayrı 205,93 USDT (10.000 TL) sanal defter; gerçek bölümlere dokunmaz.
- **Ev PC'si için:** kurallı botlar kapalı geçen kapanmış mumları açılışta deterministik oynatır
  (kurallar mühürlü, karar yalnız o ana kadarki veriyi görür); LLM'ler yalnız canlı karar verir.
- **Faz 1 (tamamlanan kısım):** `engine/arena/` tek maliyet modeli (normal + ağır), mum yolu sanal borsa
  (spot + izole USDT-M, stop/hedef/süre, fonlama, likidasyon, olumsuz aynı-mum sırası, geçmiş tarihli emir
  reddi, atomik sağlama toplamlı durum), artımlı veri deposu (`data/arena_cache`, mühürlü önbelleklere
  yazmaz), migration `20260914100000` (değişmez hesap kimliği/mühür/sermaye, yalnız eklemeli dolum/karar/
  özsermaye, lookahead CHECK, FORCE RLS). Canlı DB'de 5 ihlal denemesinin 5'i reddedildi.
- **AI laboratuvarı:** 4 ücretsiz (Groq qwen3.8-27b, gpt-oss-120b; OpenCode big-pickle; NVIDIA gpt-oss-20b)
  + 4 abonelik modeli (Claude Code: Opus 5, Fable 5.1; Codex: GPT-6 Astra, GPT-5.6 Sol) gölge modda.
  Abonelik CLI'ları araçsız, API anahtarı görmeden; model başına günlük çağrı sınırı (sahibinin talebi).
- Deneme sayacı arena ajanlarıyla 18 → 31 olacak (kıyaslar hariç).

**27 Eylül 2026 — KUSUR: 1.000 satır sınırı raporları ve kurulun görünümünü bozdu (düzeltildi)**

Yerel PostgREST tek cevapta **en fazla 1.000 satır** döndürüyor; kodda `limit(50000)` gibi büyük sınırlar bunu
aşmıyor, **sessizce** ilk 1.000 satırı veriyor. `arena_fills` ~24 Eylül'de 1.000'i geçince:
- Sahibine verilen raporlarda "kasaya giren" **+80,55 $** göründü, doğrusu **−43,19 $**; komisyon 26,82 $ yerine **44,57 $**.
- Telegram komutları (`engine/arena/queries.py`) artan sıralı okuduğu için **en eski** 1.000 kaydı gösterdi (bayat veri).
- **Kurul (`arena_v9_board`)** istemindeki arena tablosunda kasaya-giren/ücret alanları yanlıştı (getiri doğruydu).
- Sağlık kontrolü dolum sayıları ve anlık görüntüleri eksik okuyordu.
Veri yazma yolu (`repository.py`, upsert + count=exact) **sağlamdı**: 1.536 dolumun hepsi DB'de.

Düzeltme: `engine/database/paging.py` (`fetch_all`), `engine/arena/views.py` (kurul + denetim ortak görünüm).
Sağlık, Telegram komutları, özet, model kullanımı ve karşılaştırma betiği sayfalı okuyor. `tests/test_paging.py`
tek seferde >1.000 satır isteyen her satırı yakalıyor (tek istisna mühürlü `engine/ai/lab/runner.py`, günlük
ai_calls ~300). Kurul **`arena_v10_board`** olarak yeniden mühürlendi (`*_k2`, 27 Eylül 06:00 UTC; `*_k1` arşivde
`data/arena_state/_archive_kurul_k1`, DB'de pasif). Üyeler, oy kuralları, risk, bütçe **değişmedi**; n_trials 66.

Not: fonlama botunun "kasaya giren" değeri (−69 $) fonlama gelirini içermiyor. Korumalı bacaklar zarar yazıyor,
fonlama ayrı kolonda. O botun gerçek performansı toplam özsermayesidir (+20 $).

**24 Eylül 2026 — sağlık denetimi: dört kör nokta kapatıldı, iki yapısal bulgu kaydedildi**

1. **ChatGPT girişi değişti.** Botun Codex girişi sahibinin Codex uygulamasıyla ortak (`~/.codex`). Hesap
   sar\*\*\*@googlemail.com → ome\*\*\*@gmail.com oldu (17:58). Geçişte ~16:40–17:58 arası bütün GPT
   yarışmacıları ve kurulun GPT üyeleri 401 aldı. Şu an yeni hesapla çalışıyor. Kalıcı çözüm ayrı bot girişi (`~/.codex_bot`).
2. **Sağlık kontrolü bu kesintiyi görmedi.** Yalnız "bütün gün hiç geçerli cevap yok" kuralı vardı. Eklendi: **üst üste 2
   başarısız çağrı = uyarı**. İlk çalıştırmada hemen Opus 5 (3 üst üste) ve qwen3.8 kopukluklarını yakaladı.
3. **Sağlık kontrolü dört mühürü hiç denetlemiyordu** (`arena_v6_openrouter`, `v7_opus55`, `v8_gpt6`, `v9_board`). Liste elle
   tutuluyordu, eklemeyi unutmuştum (ad/kimlik kusurlarıyla aynı sınıf). Eklendi. Test artık otomasyonun
   çalıştırdığı her `SEAL_PATH`'in listede olduğunu doğruluyor.

**Yapısal bulgu A — Opus 5'in geçerli cevap oranı düşüyor:** son 8 çağrının 5'i geçersiz. Sebep: `market_view_tr` 600
karakter sınırını aşıyor ("Otuz dördüncü karar: ..."). Hafıza büyüdükçe yorum uzuyor ve tek bir serbest metin alanı
bütün kararı çöpe atıyor. **Dokunulmadı**: kural herkese aynı ve mühürlü. Lider model kötüleşirken kuralı değiştirmek
sonuca göre ayar olurdu. Nihai bot için ders: serbest metin alanları **kırpılmalı, kararın tamamı reddedilmemeli**.

**Yapısal bulgu B — istem bir haftada ikiye katlandı** (7.000 → 12.000–14.000 karakter; hafıza + geçmiş). Groq
qwen3.8 ücretsiz katman sınırına çarpıyor (HTTP 413 "request too large", 23 Eylül akşamı 5 üst üste). gpt-oss-120b
~6.000 girdi token'ında sınıra yakın. 90 gün boyunca istem büyümeye devam edecek, küçük bağlamlı ücretsiz
modeller giderek düşecek. Bu da "ücretsiz modeller yarışabilir mi" sorusunun cevabının bir parçası. Dokunulmadı.
Nihai bot için ders: istem boyutu **sınırlı** tutulmalı (özetlenmiş hafıza).

Diğer: dünkü kurul denetimi Telegram'a gitti (5 uyarı). WSL düzeltmesi sonrası Docker belleği 486 MB.

**23 Eylül 2026 — Yönetim Kurulu kuruldu, MÜHÜRLENDİ**

Proje sahibi: "güçlü 4 model her şeyi bilsin, yönetsin, işlem yapsın, diğerlerini izlesin, gerektiğinde müdahale
etsin" → "kur". Uygulanan biçim: `arena_v9_board` (`arena_board_trader_k1`, `arena_board_manager_k1`, başlangıç
23 Eylül 00:00 UTC). Üyeler **Opus 5.5, Fable 5.1, GPT-6 Astra, GPT-6 Sol**. Seçim sonuca göre değil, önceden konan
"her firmanın en güçlü iki modeli" kuralına göre yapıldı. Arenada şu an en kârlı AI olan Opus 5 bilerek alınmadı.

- Üyeler **paralel ve birbirini görmeden** karar veriyor (`engine/arena/board.py`). Kurallar: yeni işlem **≥3/4**
  aynı bölüm+pazar+sembol+yönde; kapatma **≥2**; tutar/kaldıraç **en küçük** öneri; stop/kâr-al **ortanca**;
  dağıtım bot başına **ortanca**; geçerli üye 2'den azsa hiçbir şey yapılmaz. Kota biterse iki Claude üyesi tek başına
  işlem **açamaz** (bilinçli güvenli taraf).
- Kurul **bütün arenayı görüyor** (33 hesabın getirisi, kasaya giren kârı, ücreti; yönetici dağıtımları; model
  sağlığı; çalışma süresi) ama **yalnız kendi hesabını** yönetiyor. Diğer hesaplara dokunmak protokolde yasak.
- "Müdahale" test süresince insan üzerinden: `scripts/kurul_denetim.py` günde bir (21:00 İstanbul sonrası) Opus 5.5
  ile Türkçe denetim yazıp Telegram'a gönderiyor. Yalnız okur; mühüre dahil değil. İlk provada denetçi mühürlü
  ayarları değiştirmeyi önerdi (grid aralığı, pozisyon sınırı) → istemine "kurallar 90 gün mühürlü" eklendi.
- Prova: 4/4 geçerli, 47 sn. BTC long 3/4 ile açıldı, ETH (1/4) reddedildi, Astra işlem önermedi.
- n_trials 64 → **66**. Arena **35 hesap, 9 protokol**. 1451 test geçti.

**22 Eylül 2026 (gece) — GPT-6 Sol ve GPT-6 Luna arenaya girdi, MÜHÜRLENDİ (teşhis düzeltmesi)**

Az önce "GPT-6 Sol/Luna ChatGPT hesabında desteklenmiyor" yazmıştım — **YANLIŞTI**. Proje sahibi modelleri kendi
aboneliğinde kullandığını gösterdi. Ölçüm: sorun bizim **eski Codex CLI sürümümüzdeydi (0.154)**; 0.156 ile aynı hesap
iki modeli de çalıştırdı. Aynı kusur sınıfının üçüncü örneği (big-pickle, OpenRouter, şimdi bu): **sağlayıcıyı
suçlamadan önce kendi çağrı yolumuzu ölç.**

Global CLI yarış ortasında **güncellenmedi** — güncellense çalışan 5 GPT yarışmacısının çağrı yolu değişirdi. 0.156
`tools/codex-0.156` altına sabitlendi ve yalnız yeni adıma `CODEX_CLI_PATH` ile veriliyor (adımdan sonra geri alınır);
CLI ikili dosyası mühüre dahil. `arena_v8_gpt6` (`*_g1`, 22 Eylül 22:00 UTC): kardeşleri GPT-5.6 Sol/Luna ile aynı
kurallar, yalnız trader. Deneme: sol 2/2 (13–16 sn), luna 2/2 (9–11 sn). n_trials 62 → **64**. Arena **33 hesap, 8 protokol**.

**Kota riski (ölçüldü):** botun Codex hesabı proje sahibinin Codex Desktop / VS Code kullanımıyla **aynı hesap** —
son 40 oturumun 16'sı bot. Kota şu an rahat (5 saatlik %7, haftalık %17), ama biterse 7 GPT yarışmacısının hepsi
birlikte susar. Otomasyonda ayrı bot hesabı yuvası hazır (`~/.codex_bot`), henüz giriş yapılmadı.

**22 Eylül 2026 (akşam) — Claude Opus 5.5 arenaya girdi, MÜHÜRLENDİ; GPT-6 Sol/Luna alınamadı**

Proje sahibi yeni modellerin çıktığını bildirdi. Ölçüm (gerçek arena şeması, 2 deneme, DB'ye yazmadan):
`claude-opus-5-5` **2/2 geçerli, 10,5 sn** — abonelik modelleri içinde en hızlısı. `gpt-6-sol` ve `gpt-6-luna`
Codex önbelleğinde listeleniyor ama OpenAI sunucusu **"ChatGPT hesabıyla Codex'te desteklenmiyor" (HTTP 400)**
döndü; düz `codex exec` ile de aynı — hata bizim çağrı yolumuzda değil. Erişim açılırsa ayrı protokolle eklenir.

`arena_v7_opus55` (`*_n1`, başlangıç 22 Eylül 22:00 UTC): Opus 5 ile **aynı** roller (trader+yönetici), sermaye,
bütçe, istem ve risk limitleri — soru "aynı ailenin yeni sürümü eskisinden iyi mi". `engine/ai/lab/runner.py`
bu mühüre dahil edildi (aday-başına bütçe kuralı adil karşılaştırmanın parçası). Mevcut hesapların hiçbiri
değişmedi. Deneme sayacı 60 → **62**. Arena: **31 hesap, 7 mühürlü protokol**.

**22 Eylül 2026 — KUSUR: günlük karar bütçesi işler arasında paylaşılıyordu (düzeltildi)**

Ölçüm: 21 Eylül'de her model günde 12 karar hakkıyla yarışıyor olmalıydı; gerçekleşen **Fable 5.1 için
6+6**, Groq modelleri için **9+3** oldu. Sebep: günlük sayaç `engine/ai/lab/runner.py` içinde **model adı**
başına tutuluyordu, oysa aynı model birden fazla işte kullanılıyor — Fable hem abonelikli arenada
(`sub-fable51`) hem heyet başkanında (`chief-fable51`), Groq modelleri hem arenada (`free-oss120`) hem
haber/rapor işlerinde (`groq-oss120`). İki iş birbirinin bütçesini yedi: Fable'ın iki hesabı da diğer
modellerden **%40 az karar** verdi ve 16:00 UTC'den sonra tamamen sustu.

Bu, 20 Eylül'de kapattığım "karar sıklığı eşit olmalı" sorununun aynı sınıftan bir devamıdır: 90 gün
sonunda "model mi iyiydi yoksa daha mı çok baktı" sorusunu kirletirdi.

Düzeltme: sayaç artık **aday kimliği** başına (her protokol/iş kendi bütçesi). Bu, mühürlerin zaten
**yazdığı** şeyi uygular — protokoldeki her model satırı kendi `max_calls_per_day: 12` değerini taşıyor.
`engine/ai/lab/runner.py` **hiçbir aktif mühürde değil**, dolayısıyla mühür bozulmadı ve **hiçbir hesap
sıfırlanmadı**; hiçbir sonuç görülerek parametre seçilmedi (kimin kazandığına bakılmadı). Abonelik etkisi:
Fable günde 12 → 24 çağrı (Claude tarafında önemsiz), Groq ücretsiz 12 → 15 (ücretsiz). Codex modelleri
tek işte olduğu için etkilenmedi. Test: `test_daily_call_budget_is_per_candidate_not_per_model_name`.

**21 Eylül 2026 (gece) — OpenRouter ücretsiz modelleri arenaya girdi, MÜHÜRLENDİ**

Proje sahibi ücretsiz modelleri sorguladı ("daha iyi ücretsiz AI modelleri neden kullanmadık"), kendi
OpenRouter anahtarını `.env`'e ekledi ve gizlilik ayarını **açık onayla** değiştirdi. Ücretsiz uçların
reddedilme sebebi ölçümle bulundu: hata bizdeydi — `AI_ADVISOR_DATA_COLLECTION=deny` + ZDR isteği
sağlayıcıya `data_collection: deny` gönderiyordu ve OpenRouter "bu veri politikasına uyan uç yok" (404)
diyordu. Onay sonrası `allow` yapıldı; anahtarın **kredi limiti 0 USD**, yani sistem para harcayamaz.

**Aday elemesi (mühürden önce, gerçek arena şeması ve gerçek istemle, DB'ye yazmadan):** 7 aday, her
birine en az 2 deneme. Geçen 2: `nemotron-3-ultra-550b` (2/2, 45,7–85,0 sn), `nemotron-3-super-120b`
(4/5, 20,9–50,6 sn). Elenen 5: `gemma-4-31b` (5/5 HTTP 429 kota), `nemotron-3.5-lightning`,
`nex-n2.5-pro`, `dots-3-note` (JSON döndürmedi), `ling-3.0-flash-fin` (HTTP 400). Elenenler için istem,
şema veya sıcaklık **esnetilmedi** — şema uyumu modelin kendi özelliğidir.

`arena_v6_openrouter` **yeni protokol** olarak mühürlendi (`*_r1`, başlangıç 21 Eylül 22:00 UTC).
Mevcut protokole model eklemek mühürü bozar ve Groq hesaplarının **yeniden başlaması** demekti; bu yüzden
ayrı protokol + ayrı hesaplar. **27 hesabın hiçbiri etkilenmedi.** Modelden başka hiçbir şey farklı değil:
sermaye 2.000 USDT, 2 saatte bir / günde 12 karar, aynı risk limitleri, aynı bölüm payları, aynı evren,
aynı terfi kapıları. Deneme sayacı 58 → **60** (yeni yarışmacı kanıt çıtasını **yükseltir**).

Ölçülen yavaşlık (45–85 sn; Groq 1,6–3,3 sn) protokole yazıldı: karar 2 saatlik döngüde verildiği ve
emirler kapanmış mumdan fiyatlandığı için fiyat avantajı yaratmaz, ama "geçerli cevap oranı" kapısı
(%80) zaman aşımlarını cezalandırır — bilerek böyle. Doğrulama: mühürlü koşu çalıştı, iki hesap 2.000
USDT ile açıldı, arena sağlığı **29 hesap** görüyor.

**18 Eylül 2026 — KUSUR: yönetici defteri botları göremiyordu (düzeltildi)**

Proje sahibi "en çok kaybettirenlerin sorununu bul" dedi. En çok kaybettiren üç hesabın üçü de
**yönetici** çıktı ve sebep ölçüldü: defterlerinde `last_bot_equity` **boş**, kaybın tamamı ağırlık
değiştirme masrafıydı (2.000 → 1.995,05 USDT). Kök sebep 17 Eylül'deki sermaye değişikliği:
`engine/arena/llm/manager.py` bot hesaplarını `arena_grid_v1_1` gibi **tam kimlikle** tutuyordu;
botlar `_v1_2` olunca ve eski durum dosyaları arşive taşınınca yönetici aradığını bulamadı ve **kör
kaldı**. Trader istemlerine giden `bot_return_since_start_pct` alanı da boş gitti.

Düzeltme: kimlikler **sürümden bağımsız** ön eklerle çözümleniyor (durum klasöründeki en yeni sürüm;
arşiv klasörü sayılmaz; sürüm numaraları sayısal karşılaştırılır, `_v1_10 > _v1_2`). Aynı kusur sınıfı
bir gün önce skor tablosunda da çıkmıştı — orada da ön ek çözümlemesine geçilmişti.

Üç protokolün yeni sürümü mühürlendi: `arena_v1_7_llm` (`*_v8`), `arena_v1_3_council` (`*_v4`),
`arena_v3_free` (`*_f3`); başlangıç 18 Eylül 16:00 UTC. **Strateji, risk, sermaye ve kapılar
değişmedi** — yalnız bozuk veri yolu onarıldı. Kural botları (`*_v1_2`) ve ikinci kuşak botlar (`*_r3`)
**etkilenmedi, verileri duruyor**. n_trials 58'de kaldı (bozuk koşu atıldı, seçim yapılmadı).
Doğrulama: yöneticiler artık beş botun özsermayesini de görüyor.

**17 Eylül 2026 (akşam) — test sermayesi 10.000 TL → 100.000 TL (2.000 USDT), MÜHÜRLENDİ**

Ölçülen sebep: açılan 111 emrin ortancası **9,88 USDT** ile borsa minimumunun (5 USDT) iki katının
altındaydı; testnette ölçtüğümüz miktar yuvarlaması bu boyutta **%8'e varan büyüklük sapması** yaratıyor
ve geniş stoplu işlemler tabana takılma riski taşıyordu. Karar gerekçesi: **büyük defter sonradan
küçültülebilir** (aynı kararların 206 USDT'de ne getireceği hesaplanabilir), küçük defter büyütülemez —
206'da modelin "yerim yok" diye açmadığı işlemleri hiç göremeyiz, veri sansürlenir.

Yeni sürümler (hepsi 2.000 USDT, başlangıç 17 Eylül 18:00 UTC): `arena_v1_2_rules` (`*_v1_2`),
`arena_v1_6_llm` (`*_v7`), `arena_v1_2_council` (`*_v3`), `arena_v2_free` (`*_f2`),
`arena_v2_rules2` (`*_r3`). **Yalnız sermaye değişti**; risk yüzdeleri, bölüm payları, model listesi,
çağrı sınırları, sinyaller ve terfi kapıları aynen korundu (test doğruluyor). Eski 28 hesap kapatıldı ve
`data/arena_state/_archive_206usdt` altına arşivlendi. **Deneme sayacı 58'de kaldı**: eski koşular atıldı,
aralarından seçim yapılmadı — deneyin tamamı yeniden ölçeklendi.

Yeni kurallar 2.000 USDT'de: işlem başına risk 20 $, tek coine en fazla 400 $, kaldıraçlı teminat 200 $,
grid kademesi 180 $, günlük fren −60 $, durdurma (zirveden −%15) −300 $. Beklenen ortanca emir ~96 $
(borsa tabanının 19 katı), yuvarlama hatası %0,5 altı.

Raporlarda bundan sonra **iki rakam** verilecek: 2.000 USDT'de ölçülen ve 10.000 TL'ye indirgenmiş.

**Nihai trader bot tasarımı yazıldı** → [`reports/stages/arena/NIHAI_BOT_TASARIMI.md`](reports/stages/arena/NIHAI_BOT_TASARIMI.md)
Arena bir yarışma değil **işe alım sürecidir**; 16 Aralık 2026'da kapıları geçen yöntemler tek bir sisteme
alınacak. Nihai bot yedi katmandan oluşur: veri, **durum (bilinç)**, **üç ölçekli hafıza** (anlatı /
istatistik / yapısal ders), karar kurulu (kanıtlanmış yöntemler + dağıtıcı + AI vetosu), yürütme, sert risk
katmanı ve gecelik-haftalık-aylık öğrenme döngüsü. Hafıza riski **azaltabilir, asla artıramaz**. Bugün hazır
olan parçalar: hafıza motoru, atıf motoru, çalışma süresi ölçüsü, risk katmanı, testnet yürütme gerçekleri,
Telegram sorguları. Eksikler: rejim etiketleme, MFE/MAE, ders motoru, dağıtıcı, yürütme katmanı, tek sistem
koşucusu — 90 gün boyunca yazılacak.

**17 Eylül 2026 (akşam) — 7/24 denetimi ve eksiklerin kapatılması**

Proje sahibi sistemi 7/24 çalıştırma kararı aldı ("testi sağlam yapalım"). Denetimde beş eksik bulundu,
dördü kapatıldı:
1. **Çalışma süresi ölçülmüyordu** — `engine/arena/uptime.py`: her tur özsermaye fotoğrafı yazdığı için
   saat başına fotoğraf varsa o saat çalışmış sayılır (ayrı sayaç = yeni hata kaynağı). Sağlık kontrolü
   %90 altında uyarır, günlük rapor oranı yazar. İlk ölçüm %41,7 → saatlik döngüye geçişten sonra son 5
   saat kesintisiz.
2. **AI kanıt zinciri yedeklenmiyordu** — `ai_calls` ve `news_events` günlük yedeğe eklendi. Geri yükleme
   bu ikisini bilerek yazmaz (kanıt kaydı yeniden üretilmemeli).
3. **GDELT her turda 429 veriyordu** — `engine/news/backoff.py`: kaynak bazında üstel bekleme
   (15→240 dk). Güvenlik: bekleme yüzünden hiçbir kaynak kalmazsa bekleme yok sayılır, haber freni
   kaynaksız bırakılmaz.
4. **"Neden kazandı/kaybetti" aracı yoktu** — `engine/arena/analysis.py` + `scripts/arena_analiz.py`:
   hesap/sembol/çıkış sebebi kırılımında isabet, kâr faktörü, işlem başı beklenti, tutma süresi ve
   **ücretin brüt kâra oranı**. İlk bulgular (31 işlem): net +2,04 $, ücret brüt kârın **%23'ü**; tüm
   kayıp zarar-durdurlardan, tüm kazanç kâr-allardan; **BTCUSDT'de ücret brüt kârı aşıyor**.
5. **AI hafızası zayıf** (son 5 işlem + son 3 karar) — proje sahibi kararı: **şimdilik dokunulmayacak**.
   Gerekçe: arenanın işi modelleri güçlendirmek değil karşılaştırmak; zengin hafıza hepsine eşit yardım
   eder ama yarışı sıfırlar ve kanıt çıtasını 58→73 yükseltirdi. Zengin hafıza 90 gün sonunda kurulacak
   **nihai trader botunun** tasarımına saklandı.

**Zamanlanmış görev 7/24'e ayarlandı:** tekrar aralığı 2 saat → **1 saat** (mühürde zaten yazan karar
sıklığına kavuşmak için; kural botları kaçırılanı telafi eder, LLM ajanları edemez), süre sınırı 2 saat →
30 dakika, "bilgisayarı uyandır" açık, uyku/hazırda bekletme kapalı. Saatlik AI karar kapasitesi:
Opus 5 / Fable 5.1 / Sonnet 5 / Luna ve üç ücretsiz model günde 12 → **20–24** karar.

**17 Eylül 2026 — dört yeni parça** (proje sahibi: "bu şekilde başka neleri bağlayıp test edebiliriz")

1. **Arena geri yükleme yolu** (`scripts/arena_geri_yukle.py`): günlük yedekten yalnız **eksik** satırları
   ekler (doğal anahtar: id / fill_key / decision_key / snapshot_key); hiçbir satır silinmez veya
   güncellenmez, farklı olan rapor edilir. Yazmak için `--uygula` **ve** `--onay "GERI YUKLE"` gerekir.
   İlk canlı denemede **yedeğin bozuk olduğu ortaya çıktı**: psql çıktısı konsolun Türkçe kod sayfasıyla
   okunduğu için gerekçe metinleri bozuluyordu (135 dolumun 15'i, 390 kararın 20'si). Yedek bloğu artık
   UTF-8'e alıyor; bugünün yedeği doğru kodlamayla yeniden alındı, fark **0**.
2. **Panelde arena ekranı** (`/arena`): skor tablosu, ağır maliyet sütunu, en büyük düşüş, kapanan işlem
   ve tıklanabilir getiri eğrisi. Sunucu okuma listesine yalnız ölçüm sütunları eklendi (karar gerekçeleri
   ve emir içerikleri tarayıcıya gitmez). Hesap adları Python ile aynı okunsun diye çapraz test eklendi.
3. **Ücretsiz modeller arenada** (`arena_v1_free`, hesaplar `_f1`): Groq gpt-oss-120b, Groq qwen3.8,
   OpenCode big-pickle — para maliyeti sıfır, abonelik limiti tüketmez. Mühürden önceki biçim denemesinde
   NVIDIA gpt-oss-20b zaman aşımına düştüğü için **alınmadı**. Mühürlü `arena_llm_step.py` değiştirilmedi;
   `scripts/arena_ucretsiz_step.py` aynı main()'i kendi protokolüyle çağırır. n_trials 52 → 55.
4. **İkinci kuşak kurallı botlar** (`arena_v1_rules2`, hesaplar `_r2`): makas çifti (ETH/BTC oranı,
   delta-nötr), momentum rotasyonu (en güçlü 2 coin, eksili coin alınmaz), oynaklık hedefi (BTC'yi tutar
   ama maruziyeti %10'luk dilimlerle ayarlar). Mevcut beş bot ve `protocol.py` değişmedi. n_trials 55 → 58.
5. **Testnet emir hattı ölçümü** (`scripts/testnet_emir_testi.py`): gerçek Binance testnet API'sine
   bağlanır, evrendeki 10 sembolün kurallarını okur ve isteğe bağlı olarak piyasadan %30 uzağa bir limit
   emri açıp iptal eder. **Ölçülenler:** gecikme ortanca **250 ms** (emir açma 249 ms, iptal 380 ms),
   saat farkı 1,3 sn, tüm semboller testnette var, en küçük emir 5 USDT (DOGE 1 USDT) — arena varsayımıyla
   uyumlu. **Ortaya çıkan gerçek fark:** borsa miktarı adım adım yuvarlar ve bilimsel gösterimi reddeder;
   5,00 USDT'lik bir emir yuvarlandıktan sonra 5,36 USDT oluyor. Arena simülasyonu bu yuvarlamayı hiç
   yapmıyor (küçük hesapta pozisyon büyüklüğünü etkiler). Mainnet kilidi: araç `BINANCE_TESTNET=true`
   değilse ya da mainnet anahtarı tanımlıysa **çalışmaz**.

**Arena v1.5 + Heyet v1.1 — şema kusuru giderildi, MÜHÜRLENDİ** (`research/arena_v1_5_llm_protocol.json`,
`research/arena_v1_1_council_protocol.json`, kaynak `000d265`, 20/24 dosya; **başlangıç 16 Eylül 2026 08:00 UTC
= 11:00 İstanbul**) — 22 hesap (7'si dokunulmamış kurallı bot/kıyas + 15 yeni AI hesabı)
- **Sorun:** modeller şemada olmayan **boş** alanlar gönderiyordu (`"side_note": null`), katı şema kararın
  tamamını reddediyordu. 15-16 Eylül'de 51 çağrının 4'ü (%7,8), **Opus 5'te 8 çağrının 3'ü (%38)** böyle kayboldu;
  kayıp modele göre değiştiği için model karşılaştırması adaletsizdi (üstelik lider Opus 5 en çok ceza alandı).
- **Düzeltme:** boş fazlalık alanlar atılır, **dolu fazlalık alan hâlâ hatadır** (yanlış isimle gelen gerçek bir
  değer sessizce yutulmamalı); isteme "şemada olmayan alan ekleme" satırı eklendi. Kayıtlı üç bozuk cevap yeni
  şemayla doğrulandı: üçü de geçerli.
- **Parametre ayarı değildir:** risk limitleri, bölüm yüzdeleri, kaldıraç tavanı, model listesi, çağrı sınırları ve
  terfi kapıları aynen korundu (test ile doğrulandı). Mühürlü dosya değiştiği için yeni sürüm: AI hesapları `*_v6`,
  başkan/ortalama `*_v2`; eski 15 hesap kapatıldı ve `data/arena_state/_archive_llm_v5` altına arşivlendi.
- İki günlük sonuç görüldükten sonra yeniden başlatıldığı için **deneme sayacı 37 → 52** (çıta yükseldi).

**Arena Heyet — başkan AI + heyet ortalaması, MÜHÜRLENDİ** (`research/arena_v1_council_protocol.json`, mühür
`research/arena_v1_council_pre_run_seal.json`, kaynak `e7d6e22`, 23 dosya; görev adım 5a3) — **canlı, 22 hesap**
- Proje sahibi: "modeller fikir alışverişi yapsın, güçlü bir başkan karar versin". **Bağımsızlık korunarak** yapıldı:
  sekiz model kararını birbirini görmeden verir (sürü etkisi olmasın, "hangi model iyi" ölçülebilir kalsın); başkan ve
  ortalama yalnız üretilmiş kararları okur. Yatırım komitesi yöntemi: önce bağımsız raporlar, sonra karar verici.
- **Başkan: Fable 5.1** (2 saatte bir, tur başına 1 ek çağrı). Astra daha güçlü ama günlük 6 hakkı kendi trader rolüyle
  paylaşılıyor; iki günlük ölçümden sonra ikinci başkan olarak eklenebilir.
- **Heyet ortalaması: sıfır çağrı** — dört yöneticinin ağırlık ortalaması; başkanın basit ortalamayı geçip geçmediğini
  ölçer.
- 3 yeni hesap, deneme sayacı 37; mevcut mühürlü hesaplar etkilenmedi. Mühürsüz denemede iki kusur yakalanıp
  düzeltildi (başkanın cevabı uzunluk sınırını aşıyordu; görüşler emekli hesaplardan da toplanıyordu).

**Arena AI v1.4 — Opus 5 ve Sonnet 5'e de yönetici rolü** (`research/arena_v1_4_llm_protocol.json`, kaynak `3a78844`):
her model zaten tek cevapta hem trader hem yönetici kararı veriyor; Opus 5 ve Sonnet 5'in yönetici yarısı
kullanılmıyordu. **Ek çağrı maliyeti yok**, yönetici karşılaştırması 2'den 4 modele çıktı (12 AI hesabı, deneme 35).

**Arena AI v1.3 — sekiz trader, iki yönetici, zengin bağlam (v1.4 ile değişti)** (`research/arena_v1_3_llm_protocol.json`,
mühür `research/arena_v1_3_llm_pre_run_seal.json`, kaynak `08e22cd`, 25 dosya; **başlangıç 2026-09-16 06:00 UTC
= 09:00 İstanbul**, proje sahibi "gece değil sabah başlasın" dedi)
- **Yönetici rolü yalnız GPT-6 Astra ve Fable 5.1'de** (proje sahibi kararı); diğer altı model yalnız trader.
  10 AI hesabı (`*_v4`), deneme sayacı 33.
- **AI'a zengin bağlam:** `engine/arena/llm/context.py` — sembol başına açık pozisyon (open interest) ve
  Korku & Açgözlülük endeksi; anahtarsız, önbellekli, hata durumunda sessizce boş (karar akışı durmaz).
  Mühürlü kurallı arena dosyalarına dokunmaz.
- **Kullanım takibi:** Günlük arena raporunda model başına çağrı özeti (geçerli / limit / hata).
- **Sağlık kontrolü:** `scripts/arena_saglik.py` (görev adım 6c) — durum dosyası, sağlama toplamı, DB'nin dosyanın
  önüne geçmesi, bayat fotoğraf, durdurulan hesap ve **mühür doğrulaması**; sorun bulursa Telegram uyarısı.
- Bilgisayar gece açık kalacak (priz modunda uyku/hazırda bekletme kapatıldı).

**Arena AI v1.2 — sekiz abonelik modeli (hiç çalışmadı, v1.3 ile değişti)** (`research/arena_v1_2_llm_protocol.json`, mühür
`research/arena_v1_2_llm_pre_run_seal.json`, kaynak `7715e7d`, 23 dosya; başlangıç 2026-09-16 02:00 UTC)
- Proje sahibi iki hesaptaki tüm modellerin kullanılmasını istedi. **ChatGPT limiti hesap geneli** (16 Eylül'de
  doğrulandı: Luna ve Terra aynı anda limite takıldı), bu yüzden model sayısı kapasite eklemez, havuzu böler.
  Çözüm: model başına sıklık + günlük sınır + rol.

| Model | Rol | Aralık / günlük sınır |
|---|---|---|
| GPT-6 Astra | trader + yönetici | 4 saat / 6 |
| GPT-5.6 Sol | trader + yönetici | 2 saat / 12 |
| GPT-5.6 Terra | trader | 2 saat / 12 |
| GPT-5.6 Luna | trader | 1 saat / 24 |
| GPT-5.5 | trader | 4 saat / 6 |
| Opus 5, Fable 5.1 | trader + yönetici | 1 saat / 20 |
| Sonnet 5 | trader | 1 saat / 24 |

- 12 AI hesabı (`*_v3`), deneme sayacı 35. Codex modelleri güçlüden zayıfa sırayla; biri hata verirse o tur kalan
  Codex modelleri atlanır (limiti boşuna zorlamaz).
- v1 (15 Eylül 13:00–22:00 UTC) ve v1.1 (hiç çalışmadı) hesapları devre dışı; durum dosyaları arşivde.
- Kurallı botlar ve kıyaslar (v1.1 mührü) kesintisiz sürüyor.

**Arena AI v1.1 — saatlik karar + hafıza (hiç çalışmadı, v1.2 ile değişti)** (16 Eylül, `research/arena_v1_1_llm_protocol.json`,
mühür `research/arena_v1_1_llm_pre_run_seal.json`, kaynak `5f18617`, 23 dosya; başlangıç 2026-09-16 01:00 UTC)
- Proje sahibi: AI'lar saatte bir karar versin ve kendi kâr/zararını bilsin; bilgisayar gece açık kalacak
  (priz modunda uyku/hazırda bekletme kapatıldı). Karar sıklığı ve istem mühürlü olduğu için yeni sürüm:
  eski 8 AI hesabı (15 Eylül 13:00–22:00 UTC arası çalıştı) DB'de devre dışı, durum dosyaları `_archive_llm_v1`.
- Yeni hesaplar `arena_llm_{trader,manager}_<model>_v2`; sürümler `+risk1+mem1`.
- **Hafıza:** her soruda başlangıçtan beri getiri, zirveden düşüş, kapanan işlem sayısı/kazanan oranı, gerçekleşen
  kâr-zarar, son 5 kapanan işlem ve modelin kendi son 3 kararı.
- **Limit koruması:** günlük çağrı sınırı Astra 10, diğerleri 20 (ChatGPT Plus penceresi dar).
- Kurallı botlar ve kıyaslar (v1.1 mührü) etkilenmedi; verileri kesintisiz sürüyor.

**Arena AI hesapları (v1, durduruldu) — MÜHÜRLENDİ** (`research/arena_v1_llm_protocol.json`, mühür `research/arena_v1_llm_pre_run_seal.json`,
kaynak `4b843fb`, 23 dosya; başlangıç 2026-09-15 00:00 UTC)
- 4 abonelik modeli (Claude Code: Opus 5, Fable 5.1 · Codex: GPT-6 Astra, GPT-5.6 Sol) × 2 rol = 8 hesap:
  `arena_llm_trader_<model>` (spot %40 / kaldıraçlı %30 / olay %30 bölümleri, v1.1 risk katmanı) ve
  `arena_llm_manager_<model>` (kurallı v1.1 hesaplarının gerçek getirileri üzerinde ağırlık, devir maliyeti düşülür).
- Proje sahibi isteğiyle **soru aralığı 2 saat**; zamanlanmış görev 4 saatten **2 saatte bire** alındı (açılış tetikleyicisi korunur).
  Abonelik modeli başına günlük çağrı sınırı 12 (laboratuvarla ortak sayaç).
- Model fiyat yazmaz (stop/hedef yüzde), katı şema; tek geçersiz alan → o tur işlem yok. Haberler karar anına kadar.
- Format denemesi (mühürden önce, performans değil): 4/4 geçerli, 18–22 sn; dört model benzer kararlar verdi
  (BTC/ETH long, trend botuna ~%30) — korelasyon riski olarak izlenecek.
- Görev betiği adım 5a2; deneme sayacı 31.
- **Günlük arena skor tablosu** Telegram'da (`scripts/telegram_arena_raporu.py`, adım 6b, İstanbul 09:00 sonrası
  günde bir): 15 hesap sıralı, başlangıçtan/dün getirisi, zirveden düşüş, işlem sayısı, durdurulanlar, BTC tut ve
  USDT faizi geçenler; yalnız okur.

```
Python : 1253 passed, 5 skipped
```

**Arena v1.1 — risk katmanı eklendi ve YENİDEN MÜHÜRLENDİ** (`research/arena_v1_1_pre_run_seal.json`, kaynak
`8c5cebb`, 25 dosya). Proje sahibi 7/24 günlük/haftalık/aylık getiri hedefi için limit tasarımını baş mühendise
bıraktı. v1 hiç çalışmadı (0 karar/0 dolum) → v1 hesapları DB'de devre dışı, durum dosyaları `_archive_v1`.
`engine/arena/risk.py` (kıyaslar muaf): işlem başına risk ≤ %1 (stop mesafesine göre küçültme), spot pozisyon
≤ %20, kaldıraçlı teminat ≤ %10, toplam açık stop riski ≤ %5 · saatte ≤ 3 piyasa girişi, 3 ardışık zarar → 4 saat
soğuma · tek coinde %3 zarar → kapat + 24 saat yasak · gün −%3 / hafta −%6 / ay −%10 → yeni giriş yok ·
zirveden −%15 → her şey kapanır, kalıcı durur · kâr tavanı yok. Hesaplar `*_v1_1`, sürümler `+risk1`.

**Arena v1 kurallı ajanlar — mühürlendi, sonra v1.1 ile değiştirildi** (`research/arena_v1_pre_run_seal.json`, kaynak `fc488cd`, 23 dosya)
- **Başlangıç: 2026-09-15 00:00 UTC** (`start_utc`). Öncesinde hiçbir karar/dolum yarışmaya girmez.
- Ajanlar: `arena_grid_v1` (BTC/ETH 1h), `arena_trend_v1` (4h), `arena_meanrev_v1` (1h), `arena_breakout_fut_v1`
  (4h, 2x long/short), `arena_carry_v1` (1d, spot+perp çifti) · kıyaslar `arena_bench_hold`, `arena_bench_dca`.
- Evren (yalnız 30 günlük ortanca hacim, 14 Eylül): BTC ETH SOL ZEC XRP BNB DOGE SUI UNI PUMP.
- Mühürsüz deneme bir **lookahead açığı** yakaladı: günlük ajanlar mühürden önce görülmüş saatlerde geriye dönük
  doluyordu → `start_utc` eklendi, ikinci denemede sıfır karar doğrulandı. Ayrıca yeniden oynatmada gelecek
  fonlama kayıtlarının görünmesi düzeltildi.
- `scripts/arena_step.py` zamanlanmış göreve bağlandı (adım 5a, hatası döngüyü durdurmaz; mühür/protokol reddinde
  Telegram uyarısı); arena tabloları ve durum dosyaları günlük yedekte. Canlı DB senkronu doğrulandı
  (7 hesap, 7 başlangıç fotoğrafı, 0 karar/dolum).
- Sıradaki: LLM trader/yönetici ajanları (ayrı protokol `arena_v1_llm`), skor tablosu (Telegram + panel), zengin veri.

```
Python : 1237 passed, 5 skipped
DB     : 51 migration
```

---

## 14 Eylül 2026 — güncel durum (özet)

**Sanal kasa 10.000 TL** (205,93 USDT; proje sahibi TL istedi). Zamanlanmış görev
`QuantBot Ana Kasa Paper` PC açılışında ve 4 saatte bir `scripts/ana_kasa_otomatik.ps1`
çalıştırır: Docker/Supabase güvenli açılış → Bölüm 1 döngüsü → kasa fotoğrafı →
Bölüm 3 gölge defter → günlük Telegram raporu (İstanbul 09:00 sonrası ilk çalışma).

| Bölüm | Pay | Durum | Kanıt |
|---|---|---|---|
| 1 Ana kasa | 5.000 TL | ✅ sanal para, otonom | `core_allocator_v1` mühürlü koşu **REJECTED** (Calmar 1,06 vs 0,57 ve DD %48 vs %56 ile vol-eşlenmiş al-tut'u geçti; DSR 0,89, PBO %20 kaldı) — [rapor](reports/stages/core_allocator_v1/validation_report.json) |
| 2 Al-sat | 3.000 TL | ⏸ nakitte | `spot_active_v1` (30m sıkışma-kırılım, lot bazlı, 32 sembol noktasal-zamanlı evren) mühürlü koşu **REJECTED 3/10**: severe −%48,8, DD %68,8, PF 0,85 — [rapor](reports/stages/spot_active_v1/validation_report.json), [tasarım notu](reports/stages/coklu-sistem/FAZ_E_TASARIM_NOTU.md) |
| 3 Kaldıraçlı | 2.000 TL | 👁 gölge defter | Dondurulmuş `funding_carry_v2` (mühür `eaa208c`), 41 USDT kasa kurallarla tek pozisyon açamadığı için sinyal düzeyi gölge (sanal 10k USDT, "2.000 TL olsaydı"). 2026-08-05..09-13: **−%4,62**; kaybın ~%95'i tek baz kopması (HFTUSDT) — [tanı notu](reports/stages/carry_shadow/ILK_KOSU_TANI_NOTU.md) |

**Bu oturumda eklenenler**
- Faz D: `engine/sleeves/` (Ana kasa allocator, lot/varlık muhasebesi, spot yürütücü, günlük döngü) ve iki bağımsız inceleme turunun düzeltmeleri (sorgulanan emirde komisyon, piyasa emrinin otomatik yeniden denenmemesi, kısmi dolum, kurtarma grace süresi, akış bazlı hata yalıtımı).
- Getiri raporu: `sleeve_equity_snapshots` (yalnız eklemeli), `scripts/getiri_raporu.py`, `scripts/telegram_getiri_raporu.py`.
- Yönetici: aynı sembolde bağımsız lot (`review(lot_id=)`); paylaşılan mühür doğrulaması `engine/research/seal.py`.
- Proje deneme sayacı (DSR): 17.

**funding_carry_v3** (v2 + noktasal-zamanlı spot likidite filtresi, açılış 50M / çıkış 25M USDT; mühür `b60b2a4`): **REJECTED 9/10** — yalnız walk-forward kaldı (6 pencerenin 2'si pozitif, %33 < %60). Severe 2019-09..2024: +%62,1, DD %8,3, PF 4,18, PBO %2,9, en büyük işlemin brüt kâr payı %14,2 (v2: +%68,7, DD %10,2, PBO %25,7, pay %26,6). Getiri 2021'e yığılı (+%49,3; 2022 −%6,2, 2023 −%0,2, 2024 +%8,6); tanısal 2025..2026-07 −%6,0 (kanıt değil). Likidite filtresi kuyruk riskini ve aşırı uyumu azalttı, fakat aşırı funding rejimi dışında severe maliyet sonrası carry ≈ sıfır. Parametre onarımı yapılmaz — [rapor](reports/stages/funding_carry_v3/validation_report.json).

**basis_carry_v1** (BTC/ETH üç aylık vadeli fark kilitleme; mühür `d8b194c`; vade veri sözleşmesi 32 vadede doğrulandı): **REJECTED 7/10** — walk-forward %50 (3/6), DSR 0,36, PBO %57,1 kaldı. Severe 2021-03..2024: +%18,8 (yıllık ~%4,6), DD %8,1, PF 8,29, 28 kapanış; yıllar 2021 +%5,9, 2022 +%1,7, 2023 −%1,2, 2024 +%12,0. Getiri stabil coin faizi düzeyinde ve eşik/vade ayarına duyarlı (PBO yüksek). Parametre onarımı yapılmaz — [rapor](reports/stages/basis_carry_v1/validation_report.json).

```
Python : 1171 passed, 5 skipped
```

---

## 13 Eylül 2026 — yeni yön

Proje sahibi, tek stratejili al-tut odaklı öneriyi reddetti ve **üç bölümlü,
tek yöneticili bir sistem** kurulmasına karar verdi. Her şey önce sanal para /
testnet üzerinde çalışacak; gerçek para ayrı ve açık insan onayı ister.

| Bölüm | Görev | Önerilen pay |
|---|---|---:|
| 1 — Ana kasa | BTC/ETH spot, trend + volatilite hedefli ağırlık, bantlı dengeleme | %50 |
| 2 — Spot al-sat | Kaldıraçsız aktif işlem, 1h/4h | %30 |
| 3 — Kaldıraçlı | USDT-M futures long/short, en fazla 3x, testnet | %20 |
| Yönetici | Global risk, işlem günlüğü, raporlar, AI yalnız veto/küçültme, haber freni, Telegram | — |

Payların kesinleşmesi ve Bölüm 1 kabul kapıları onay bekliyor (Plan §7.2).

### Kod incelemesi (13 Eylül) — özet

- **Korunacak çekirdek:** DB-first emir yöneticisi, borsa uzlaştırması, komisyon
  muhasebesi, runtime lease, watchdog, outbox, araştırma istatistikleri (PBO/DSR).
- **Mimari engel:** `strategy_manager.py` grid merkezli; bölüm/sermaye kavramı yok,
  risk durumu tek ve hesap genelinde.
- **Kaldırılacak ölü kod:** `engine/hybrid/`, `engine/autopilot/` (portföy/AI skor).
- **Bilinen kritik hatalar** (§9 Faz A kalanları): futures stop emri python-binance
  1.0.37 ile algo uç noktasına gidiyor → idempotensi kırık; trend yürütme
  `bot_sessions` insert'i şemayla uyuşmuyor; `trade_memory` çıkışları hiç yazılmıyor;
  grid yokken günlük kayıp/drawdown değerlendirilmiyor; bazı bildirim anahtarları
  yalnız bir kez gidebiliyor.

### Faz A — bu oturumda yapılanlar

1. Düzenli kapanış artık trend pozisyonlarını **satmıyor** (ev PC'si her gece
   kapanıyor). Eski davranış yalnız env-only `SHUTDOWN_FLATTEN_TREND_POSITIONS=true`
   ile açılır; acil tasfiye yolu değişmedi.
2. `PAPER_TRADING` panel/DB beyaz listesinden çıkarıldı; çalışma modu yalnız `.env`.
3. AI'nın aday skorunu yükseltebildiği kanca (`AUTOPILOT_AI_SCORING`) kaldırıldı.
4. Trend yürütme oturumu şemaya aykırı yazılıyordu (`name` yok, `status='active'`,
   var olmayan `symbol` kolonu). İlk gerçek girişte insert reddedilip devre kesici
   açılırdı. Düzeltildi; test sahte DB'si artık gerçek `bot_sessions` kısıtlarını
   zorluyor (eski kodla 9 test kırılıyor, yeni kodla geçiyor).
5. Ölü kod silindi: `engine/hybrid/` (hiç başlatılmıyordu), `autopilot/ai_scorer.py`
   (AI skor artırma) ve `autopilot/portfolio.py` (tek adayla her zaman ağırlık 1,0).
   İlgili `HYBRID_*`, `AUTOPILOT_AI_SCORING`, `AUTOPILOT_PORTFOLIO_OPT` ayarları
   kaldırıldı; geri gelmemeleri testle bağlı. DB'de kalan eski satırlar artık
   uygulanmaz.
6. Tekrarlayan Telegram uyarıları kalıcı tekilleştirmede yutuluyordu: kâr kilidi,
   rejim değişimi, portföy risk skoru ve trend acil durum anahtarları zaman
   bilgisi taşımıyordu, aynı olay ikinci kez hiç bildirilmiyordu. Anahtarlara
   UTC gün/saat kovası eklendi (risk skoru 10'luk bantla); testle bağlı.
7. Haber sınıflandırıcısı yanlış alarm veriyordu: sembolsüz olumsuz haber "tüm
   semboller" kovasına düşüyor, kriptoyla ilgisiz bir SEC bülteni ("charged")
   ~0,64 skorla tüm girişleri 2 saat yarıya indiriyordu. Artık kripto bağlamı
   olmayan olumsuzluk kaydedilir ama risk üretmez. Her habere `category`
   (security/insolvency/delisting/regulatory/outage/market) ve motorun haberi
   gördüğü an `received_at` eklendi (DB şeması değişmedi, `metadata` içinde).

**Plan §7.2 kararları (hepsi onaylı):** sermaye payları %50/%30/%20; Bölüm 1
kapı seti (volatilite eşitlenmiş al-tut'a karşı); 2026-H2 yalnız canlı sanal
para testi, tarihsel holdout olarak puanlanmaz. Takvim beklemesi yok: sistem
tamamlanınca sanal para testi hemen başlar.

```
Python : 846 passed, 1 skipped (madde 1-7 sonrası tam koşu; silinen
         modüllerin 44 testi kaldırıldı, 7 regresyon testi eklendi)
Panel  : 13/13, tsc --noEmit temiz
```

### Faz B — şema (kapandı)

Üç bölümün ayrı sermaye, risk ve işlem günlüğü için veritabanı temeli kuruldu ve
yerel DB'ye uygulandı: `sleeves` (%50/%30/%20, futures 3x), altı yürütme
tablosunda `sleeve_id` (mevcut kayıtlar `legacy`), `sleeve_risk_state`, yalnız
eklemeli `sleeve_ledger` ve `ai_calls`, geri sarılamaz `bar_checkpoints`,
`trade_journal`, yalnız insanın kabul edebildiği `hypotheses`.

- Canlı kural doğrulaması **30/30**, geri alma betiği işlem içinde kanıtlandı.
- Yerel Supabase portları LAN'a açık bulundu → yalnız `127.0.0.1`'e kilitlendi.
- 5 Ağustos'tan beri kırık canlı DB entegrasyon testi düzeltildi (1/1).

```
Python : 854 passed, 1 skipped
DB     : 46 migration; canlı entegrasyon testi 1/1; kural doğrulaması 30/30
```

Ayrıntı: [`FAZ_B_NOTU.md`](reports/stages/coklu-sistem/FAZ_B_NOTU.md)

### Faz C — yönetici (kapandı)

`engine/supervisor/` paketi: yalnız sıkılaştırılabilir sınırlar, global ve bölüm riski
(günlük/haftalık duraklatma, drawdown devre kesicisi, ardışık kayıp), hesap maruziyeti,
tek ön-işlem kapısı, kapanma sonrası bar telafisi (yalnız son bar emre dönüşür), bölüm
sermaye defteri, işlem günlüğü ve açılış kurtarma. AI ve haber yalnız küçültür/engeller.

- 8 saatlik kapanma ve çökme senaryoları testle kanıtlandı (çift kayıt/emir yok).
- Üç bağımsız inceleme turunda bulunan yüksek/orta tüm sorunlar düzeltildi (1 kritik dahil).
- Risk durumu artık kaynak (paper/testnet/mainnet) başına ayrı; `updated_at` DB tetikleyicisiyle.
- Sermaye akışları defter satırı filigranıyla bir kez ve kendi zamanıyla uygulanıyor.
- Henüz çalışma akışına bağlı değil: bölümler Faz D–F'de kullanacak.

```
Python : 1015 passed, 5 skipped
DB     : 49 migration; canlı testler 5/5; şema doğrulaması 33/33
```

Ayrıntı: [`FAZ_C_NOTU.md`](reports/stages/coklu-sistem/FAZ_C_NOTU.md)

---

## 5 Ağustos 2026 — önceki karar (tarihsel)

**Karar:** Strateji arayışı durduruldu —
[`reports/PROJE_KAPANIS_KAYDI_20260805.md`](reports/PROJE_KAPANIS_KAYDI_20260805.md)

## Neden durduruldu

**14 strateji ailesi denendi, 14'ü de reddedildi.** Belirleyici karşılaştırma:

| 2019-2024, severe maliyet | Getiri | Max DD |
|---|---:|---:|
| `spot_v7` (en iyi adayımız) | +%84,60 | %28,70 |
| BTC/ETH al-tut | **+%2.331,97** | ~%77 |

10.000 USD ile strateji 18.460, hiçbir şey yapmamak 243.197 yapardı — ve
strateji hâlâ %28,70 drawdown yaşadı.

**Dürüst sonuç:** Günlük bar verisiyle, spot ve perpetual üzerinde, standart
sistematik mekaniklerle, ücret sonrası kullanılabilir bir avantaj bulunamadı.
Bu planın 2. maddesinde baştan öngörülmüştü: *"avantaj yoksa stratejiyi
reddet."* **Maliyeti yalnızca zaman oldu; tek kuruş kaybedilmedi.**

---

## Reddedilen aileler

| Aile | Karar | Not |
|---|---|---|
| btc_daily_breakout, weekly_sma_200, spot_v3–v6, grid_trend_gated, vol_harvest, trend_execution v1/v2, reversion_v1, eth_trend_v1(+SOL/BNB) | REJECTED | Tarihsel çalışmalar |
| `funding_carry` v1 | **INVALID** | Reddi dört muhasebe hatasından kaynaklanıyordu |
| `spot_v7` (çok-varlıklı vol-hedefli TSMOM) | REJECTED 4/10 | **Overfit değildi** (PBO %8,57), sinyal gerçekti ama zayıf |
| `spot_v8` (kesitsel momentum) | REJECTED 7/10 | PBO %81,43 — gürültü |
| `funding_carry` v2 (çoklu-sembol delta-nötr) | REJECTED 8/10 geçti | En iyi sonuç; ama P&L'in %38,5'i **tek işlemden** |

---

## Sistemin durumu

### Güvenlik denetimi (5 Ağustos) — temiz

| Kontrol | Durum |
|---|---|
| Mainnet / futures kilitleri (9 bayrak) | tümü `false` |
| `AUTOPILOT` — `.env` **ve** üretim DB | `false` |
| `*_admission` `allowed=true` | **0 satır** |
| `PAPER_TRADING` | `true` |

> Üretim DB'sinde `AUTOPILOT=True` kalmıştı; `.env` tek başına yetmiyor çünkü
> motor açılışta DB'yi üzerine yazar. Düzeltildi. Motoru başlatmadan önce
> **her ikisi de** kontrol edilmelidir.

### Testler

```
Python : 871 passed, 1 skipped
Panel  : 13/13, tsc --noEmit temiz
```

### Aşama 1 — kapatıldı, `PASS` değil (7 Ağustos)

Sekiz doğrulama paketi **tamam**. 72 saatlik soak kapısı **sağlanamadı**:
dört deneme, dördü de kesintiye uğradı — hiçbiri koddan değil, host'tan.

| Deneme | Süre | İhlal | Nasıl bitti |
|---|---:|---:|---|
| 1 | 4,6 / 72 sa | 0 | Konteyner kayboldu |
| 2 | 2,4 / 72 sa | 0 | Docker kapandı |
| 3 | 4,2 / 72 sa | **0** | `exit 137` (SIGKILL) |
| 4 | başlayamadı | — | PC kapandı, Docker `AutoStart: false` |

Motor çalıştığı her saniye kusursuzdu (502 örnek, 0 ihlal). Başarısız olan
yazılım değil, altındaki zemin. Kapı **gevşetilmedi**;
[`ASAMA_1_RAPORU.md`](reports/stages/asama-1/ASAMA_1_RAPORU.md) durumu olduğu
gibi kaydediyor.

**Host sertleştirmesi yapıldı** (kalıcı, depoda): `~/.wslconfig` yazıldı
(`autoMemoryReclaim=disabled`, `vmIdleTimeout=-1`, bellek tavanı 8 GB) ve
Docker Desktop `AutoStart: true`. İhtimali artırır, garanti etmez.

**Aşama 1'i gerçekten kapatmak için gereken tek şey:** her zaman açık bir host
(~5-10 USD/ay VPS). Aşama 7 için zaten gerekli.

---

## Bu oturumlarda düzeltilenler

1. Panel üç sayfada **uydurma veri** gösteriyordu; `Math.random()` ile equity
   eğrisi üretiyordu → tümü kaldırıldı, sözleşme testiyle bağlandı
2. Scheduler açlığı: lease/heartbeat düzenli atlanıyordu → adanmış executor +
   zorunlu timeout
3. Risk kuralları trend yolunda hiç uygulanmıyordu → kapı eklendi
4. Kâr kilidi tutar hesaplayıp **hiçbir sermaye korumuyordu** → gerçek nakit
   tabanı, restart'ta korunuyor
5. Planın zorunlu kıldığı ama **hiç yazılmamış** testler → PBO, Deflated
   Sharpe, purge/embargo kodlandı
6. Eşik-alışverişi → `engine/research/gates.py`, gevşetme `ValueError`
7. Holdout tüketim defteri → 2025'in 12 kez kullanıldığı kayda geçti
8. Paper broker backtest'ten iyimserdi → limit kuyruk modeli + market slipajı

---

## Yeniden başlamak için

Üçünden biri değişmeden devam etmek bilgi üretmez:

1. **Aralık 2026** — 2026 H2 tamamlanır, yeni dokunulmamış holdout açılır
2. **Farklı veri** — intraday, emir defteri, on-chain (haftalarca altyapı işi)
3. **Farklı amaç** — alfa yerine yürütme disiplini otomasyonu

Gereken her şey depoda ve çalışır durumda.

---

**AI Koordinatör İmzası:** Claude (Anthropic)
**Karar:** Strateji arayışı durduruldu; altyapı korundu; mainnet `NO-GO`.
