# Multi-Symbol SMA20 Daily Trend Ailesi — Tasarım Spec

## 1. Özet

YOL_HARITASI_V2.md Kural 4 gereği (≥2 strateji FAIL → yeni sinyal mekaniği),
eth_trend_v1'in kanıtlanmış mekaniği çoklu sembole genişletilmiştir.

**Temel fikir:** Piyasada işe yaradığı kanıtlanmış tek mekanizma (Close > SMA20 +
SMA20 slope, 1d, trailing+hard stop) alınıp ETH, SOL ve BNB'ye uygulanır.
Tek-coin riski, çeşitlendirme ile azaltılır. Karmaşıklık eklenmez.

## 2. Sinyal Mekaniği

```
Giriş:  Close > SMA20 VE SMA20[0] > SMA20[-5]
Çıkış:  Close < SMA20 (trend reversal)
     VEYA trailing stop %15 (peak'ten)
     VEYA hard stop %10 (giriş fiyatından)
```

- Zaman aralığı: 1d (günlük) — düşük frekans, yüksek sinyal/gürültü oranı
- SMA periyodu: 20 (sabit, tüm semboller için aynı)
- Slope lookback: 5 bar (düz/yatay SMA'da girişi engeller)
- Rearm: stop sonrası sinyal reset beklenir (flapping önler)

## 3. Risk Yönetimi

- Sembol başına max alım: $100 USDT (portföyün %1-$100)
- Tüm trend pozisyonları toplamı: max $300 (portföyün %3-%100)
- Nakit rezervi: min %30 (her girişte korunur)
- Rejim filtresi: yalnız UPTREND'de yeni giriş, diğer rejimler FLAT
- Multi-TF konsensüs: paper ≥1 UPTREND (1h/4h/1d), mainnet ≥2

## 4. Sembol Seçimi

| Sembol | Dev Return | Holdout 2025 | Seçilme Nedeni |
|--------|:---------:|:------------:|----------------|
| ETHUSDT | +46.49% | +6.38% | Kanıtlanmış, düşük DD (%9.61) |
| SOLUSDT | +63.81% | +6.25% | Yüksek getiri, BH'yi -34%'den +6%'e çevirdi |
| BNBUSDT | +104.58% | +7.36% | En yüksek getiri, farklı dinamik (exchange token) |

Seçim kriterleri:
- En az 5 yıl geriye dönük veri
- Günlük likidite > $100M
- BH'den bağımsız pozitif holdout
- Düşük korelasyon (ETH-SOL ~0.6, ETH-BNB ~0.5, SOL-BNB ~0.55)

## 5. Validasyon Sonuçları

Tüm semboller 4/4 gate PASS (development backtest, walk-forward, Monte Carlo,
holdout 2025). Ortak özellikler:
- Dev: tümü yüksek pozitif (%46-%105)
- WF: ≥%50 pozitif pencere
- MC: profit prob ≥%62 (ETH) / ≥%96 (SOL/BNB)
- Holdout: tümü pozitif (%6.25-%7.36) — 2025'te BH'nin çoğu negatifken

## 6. Uygulama Mimarisi

Mevcut `TrendExecutionManager` altyapısı kullanılır (değişiklik gerekmez):
- Her sembol için ayrı TrendExecutionManager instance'ı
- `signal_evaluator` parametresi ile SMA20 sinyali enjekte edilir
- Config: `TREND_EXECUTION_SYMBOLS` (virgüllü liste)
- Bot döngüsü: her 300sn'de tüm manager'lar sırayla çalıştırılır
- Acil durum: shutdown/hepsi emergency_exit çağırır

## 7. Paper Kampanya Planı

1. `PAPER_TRADING=true` ile bot başlat
2. `TREND_EXECUTION_ENABLED=true`, `TREND_EXECUTION_AUTOPILOT_ENABLED=true`
3. Tüm semboller (ETH, SOL, BNB) aynı anda izlenir
4. Her giriş $100 max, trailing stop %15, hard stop %10
5. 90 UTC gün + 5 round-trip / sembol sonrası değerlendirme

## 8. Gelecek Genişleme

- Yeni sembol ekleme: `TREND_EXECUTION_SYMBOLS`'a virgülle ekle, backtest'i geçerse çalışır
- SMA periyodu optimizasyonu: gereksiz — sabit 20 tüm sembollerde çalıştı
- Timeframe düşürme: yasak — 4h/1h daha önce başarısız oldu (trend_v1)
- AI iyileştirme: advisory-only, sinyal mekaniğini değiştiremez