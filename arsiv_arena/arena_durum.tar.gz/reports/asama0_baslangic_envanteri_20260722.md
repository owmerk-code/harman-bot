# Aşama 0 — Başlangıç Envanteri ve Kapsam Dondurma

Tarih: 2026-07-22T16:18:28Z  
Çalışma ağacı: `8cd2c7999200a7efb8229fa688237b3d579fd9c2` (`master`, `origin/master` önünde 71 commit)

## Karar

**Aşama 0: PASS.** Kapsam `NIHAI_UYGULAMA_YOL_HARITASI.md` ile
dondurulmuştur. Aşama 1 yalnız altyapı, muhasebe, risk ve işletim mührü için
açılmıştır. Aşama 2 ve sonrası kapalıdır; geçerli aktif strateji adayı yoktur.

Mainnet, genel/spot autopilot ve futures kapalıdır. Hiçbir eski çalışma
mainnet, paper kabulü veya yeni aday olarak yükseltilmemiştir.

## Çalışma ağacı envanteri

Rapor öncesi salt-okunur `git status --porcelain=v1` anlık görüntüsü 47 girdi
içeriyordu: 9 değiştirilmiş izlenen dosya ve 38 izlenmeyen girdi. Bunlar başka
çalışmaların kanıtı olabileceğinden silinmemiş, resetlenmemiş veya üzerine
yazılmamıştır.

Değiştirilmiş izlenen dosyalar:

- `DURUM.md`
- `GO_LIVE_READINESS.md`
- `README.md`
- `docker/docker-compose.yml`
- `engine/config.py`
- `engine/core/bot.py`
- `engine/indicators/__init__.py`
- `engine/indicators/core.py`
- `engine/strategies/__init__.py`

38 izlenmeyen girdi; 4 plan/doküman, `data/funding_cache/`, 4 strateji modülü,
11 rapor, 11 araştırma/protokol/mühür, 4 validation scripti ve 3 test dosyası
olarak sınıflandırılmıştır. Bunların ayrıntılı listesi aynı anlık görüntüdeki
`git status --short --branch` çıktısıyla yeniden üretilebilir.

Kanıt deposu envanteri: `reports/` altında 19 JSON, 3 log ve 1 açıklama;
`research/` altında 20 JSON vardı.

## Dondurulan kararlar

| Aday/çalışma | Sınıf | Karar |
|---|---|---|
| BTC breakout v1.1 | Tarihsel aday | `REJECTED` (`0/12`) |
| Weekly-SMA(200) | Mühürlü holdout | `REJECTED` |
| Spot-v3 | Development ailesi | `REJECTED` |
| Spot-v4 | Development ailesi; blind değil | `REJECTED` |
| Spot-v5 | Full validation | `REJECTED` (4 kapı FAIL) |
| Spot-v6 | Full validation | `REJECTED` (4 kapı FAIL) |
| Grid trend-gated | Sonuç görülmüş grid onarımı | `REJECTED`; yeniden çalıştırılmaz |
| Volatility harvesting | DCA/çıkışsız aile | `REJECTED`; kapsam dışı |
| Funding carry ilk koşu (`143907`) | Bug ile şişmiş/crash | `INVALID_OR_DIAGNOSTIC` |
| Funding carry ikinci koşu (`213130`) | Futures, 4 kapı FAIL | `REJECTED`; kapsam dışı |
| Futures-v2/v3 ve genel futures | Futures/proxy | `REJECTED_AND_DISABLED` |
| Quick-mode/crash logları | Hızlı/yarım çalışma | `INVALID_OR_DIAGNOSTIC` |
| `faz0_release_seal_20260721_023141.json` | Eski commit mührü | `HISTORICAL_BASELINE` |

Spot-v5 mühründeki yer tutucu hash ve bazı protokol/holdout çelişkileri
nedeniyle 2017–2025 dönemleri artık görülmüş kabul edilir. Bu raporlar yeni bir
"dokunulmamış holdout" olarak tekrar kullanılamaz. Aynı veri üzerinde parametre
onarımı veya yeniden adlandırma yapılmaz.

## Güvenlik kilitleri

Sır değerleri okunmadan/gösterilmeden gerçek `.env` dosyasında aşağıdaki
durumlar doğrulandı:

- `MAINNET_TRADING_ENABLED=false`
- `MAINNET_AUTOPILOT_ENABLED=false`
- `AUTOPILOT=false`
- `SPOT_TREND_AUTOPILOT_ENABLED=false`
- `SPOT_TREND_MAINNET_APPROVED=false`
- `FUTURES_ENABLED=false`
- `FUTURES_MAINNET_TRADING_ENABLED=false`
- `FUTURES_GO_LIVE_APPROVED=false`
- İlgili futures autopilot kilitleri `false`

Kod varsayılanları da `false`; env-only canlı onay anahtarları DB/panel
allowlist'inde değildir. `.env.example` içinde genel `AUTOPILOT` anahtarı
eksiktir ancak kod varsayılanı `false` kalır; Aşama 1'de örnek dosya açıkça
sertleştirilecektir.

Docker daemon çalışmadığından güncel DB `AUTOPILOT`, RLS, compose health ve
loopback portları doğrulanamadı. Bu eksiklik başarı sayılmamış ve Aşama 1
kapısına blocker olarak taşınmıştır.

## Başlangıç test kanıtı

İlk `pytest -q` koşusu: **563 passed, 1 skipped, 1 failed, 28 errors**.
28 hata izinli çalışma alanı dışındaki eski pytest temp dizinine erişim
reddinden kaynaklandı. İzinli `--basetemp` ile tek gerçek failure yeniden
üretildi: `test_db_overrides_are_revalidated_before_exchange_connect`, mevcut
strict DB ayarı çağrısının test double imzasıyla uyumsuzdur.

Bu sonuç release mührü değildir. Ayrıca salt-okunur denetimde
`TREND_EXECUTION_MAINNET_APPROVED` tanımlı olmasına rağmen trend execution
yolunda uygulanmadığı ve `force=True` yolunun enable/autopilot kapılarını
atladığı görüldü. Global mainnet kilitleri bugün kapalı olsa da bu savunma
katmanı Aşama 1 düzeltme ve regresyon testi gerektirir.

## Kırmızı çizgiler

- Gerçek emir yok; mainnet/autopilot/futures kilitleri değiştirilmeyecek.
- Yeni strateji, gösterge, coin evreni, AI karar yetkisi veya panel özelliği yok.
- Reddedilmiş/sonucu görülmüş aday aynı holdout üzerinde onarılmayacak.
- Eksik fill/komisyon, çözülemeyen emir, DB/risk persistence veya kritik sağlık
  belirsizliğinde yeni giriş fail-closed engellenecek.
- Aşama 1'in Python, panel, Docker, DB/RLS, port ve temel komut akışı birlikte
  geçmeden Aşama 2 ön-kaydı yapılmayacak.

## Güvenli sonraki adım

Aşama 1'de yalnız mevcut kritik yol açıkları düzeltilip test edilir. İlk hedef;
strict DB override test uyumsuzluğunu gidermek, eksik trend mainnet kapısını
uygulamak ve ardından tam Python/panel/DB/Docker mührünü yeniden almaktır.
