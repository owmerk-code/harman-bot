# Quant — Aşama 2: Strateji Ön-Kaydı (reversion_v1)

**Tarih:** 22 Temmuz 2026 — **Dondurulmuştur.**

---

**Sürüm:** `reversion_v1`
**Hipotez:** BTC günlük fiyatı alt BB bandına (< 2σ) düştüğünde aşırı satım bölgesine girer; orta banda (SMA 20) dönüş beklenir. Alçalan trendde nakitte kalır.

**Giriş (FLAT → LONG):** Close < BB_lower AND SMA20 eğimi > 0 (yükselen trend)
**Çıkış (LONG → FLAT):** Close > SMA20 VEYA trailing stop %10 VEYA stop loss %8

**Zaman dilimi:** 1d | **Evren:** BTCUSDT
**Boyutlama:** %20 portföy, max 100 USDT, ≥%30 nakit

**Parametreler (sabit):** BB period=20, BB std=2.0, SMA20 slope lookback=5

**Test takvimi:** Development 2020-2023, WF 2024, Holdout 2025

**Eşikler:** Dev >0, WF ≥%50 pozitif, MC ruin <%30, Holdout >0 ve DD ≤%12
