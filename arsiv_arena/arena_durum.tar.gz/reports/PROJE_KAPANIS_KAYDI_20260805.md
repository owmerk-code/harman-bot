# Proje Kapanış Kaydı — Strateji Arayışı Durduruldu

**Tarih:** 5 Ağustos 2026
**Karar:** Strateji arayışı **durduruldu**. Altyapı çalışır ve güvenli durumda bırakıldı.
**Canlı karar:** `NO-GO — MAINNET KAPALI` (değişmedi)
**Karar sahibi:** Proje sahibi

---

## 1. Neden durduruldu

**14 strateji ailesi denendi, 14'ü de reddedildi.**

Kırılım, haftalık SMA(200), Donchian, TSMOM (tek ve çok varlıklı), ATR-adaptif
grid, Bollinger mean-reversion, grid+trend, volatilite hasadı, EMA/MACD/RSI
trend, kesitsel momentum, delta-nötr funding carry.

Ve ölçüm aleti artık güvenilir: PBO, Deflated Sharpe, purge/embargo,
survivorship-bias'sız 574 sembollük evren, holdout tüketim defteri. Bu redlere
güvenilebilir.

### Belirleyici karşılaştırma

En iyi adayımız `spot_v7`, aynı dönemde hiçbir şey yapmamakla karşılaştırıldı:

| 2019-2024, severe maliyet | Getiri | Max drawdown |
|---|---:|---:|
| `spot_v7` (en iyi aday) | **+%84,60** | %28,70 |
| BTC/ETH al-tut | **+%2.331,97** | ~%77 |

10.000 USD ile: strateji **18.460**, hiçbir şey yapmamak **243.197**.

Ve strateji hâlâ %28,70 drawdown yaşadı. Getirinin %96'sından vazgeçildi,
karşılığında ciddi bir düşüşten kurtulunamadı. Bu, "alfa yok ama en azından
daha güvenli tutuyoruz" savunmasını da geçersiz kılar.

### Dürüst sonuç

> Günlük bar verisiyle, spot ve perpetual üzerinde, standart sistematik
> mekaniklerle, ücret ve slipaj sonrası kullanılabilir bir avantaj bulunamadı.

Bu bir başarısızlık değil, bir **cevaptır** — ve planın 2. maddesinde baştan
yazılıydı: *"avantaj yoksa stratejiyi reddet."* Sistem tam olarak bunu yaptı.

**Maliyeti yalnızca zaman oldu. Tek kuruş kaybedilmedi.**

---

## 2. Ek kısıt: holdout tükendi

| Dönem | Durum | Kaç kez puanlandı |
|---|---|---:|
| 2017-2024 | development | — |
| 2025 | **exhausted** | 12 |
| 2026 H1 | **consumed** | 1 (`spot_v8`) |
| 2026 H2+ | future | 0 |

Rezerve tarihsel holdout kalmadı. Yeni bir aday üretip eski veride test etmek
artık **bilgi üretmez**. Dürüst bir out-of-sample yalnızca ileriye dönük
zamandan gelir (Aralık 2026'da 2026 H2 açılır).

`engine/research/holdout.py` bunu kod seviyesinde zorlar: tüketilmiş bir
dönemde koşmaya çalışan runner `HoldoutExhaustedError` ile durur.

---

## 3. Bulunan ve düzeltilen hatalar

Bu oturumlarda **altı** ciddi hata bulundu. Beşi ölçümleri doğrudan
bozuyordu:

| # | Hata | Etki |
|---|---|---|
| 1 | Panel üç sayfada uydurma veri gösteriyordu; `Math.random()` ile equity eğrisi üretiyordu | Gerçek kayıtlardan ayırt edilemez sahte metrikler |
| 2 | `funding_carry` v1'de dört muhasebe hatası | Bir aile **haksız yere** reddedilmişti |
| 3 | Scheduler açlığı: lease/heartbeat düzenli olarak atlanıyordu | Sessiz kontrol kaybı riski |
| 4 | Risk kuralları trend yolunda hiç uygulanmıyordu | Pozisyon boyutu ve nakit rezervi denetimsiz |
| 5 | Kâr kilidi tutar hesaplayıp logluyor, **hiçbir sermaye korumuyordu** | Var gibi görünen, olmayan bir koruma |
| 6 | `funding_carry` v2'de veri hatası: 10 sembolde spot/perp uyuşmazlığı | İlk koşuda P&L'in %62'si tek bozuk sembolden |

Ayrıca kendi hatam kaydedildi: `spot_v8` mührüne koşunun değiştirdiği bir
dosyayı koymuştum — kendi kendini bozan bir mühür
(`MUHUR_BUTUNLUK_NOTU_20260804.md`).

---

## 4. Sistemin bırakıldığı durum

### Güvenlik denetimi (5 Ağustos)

| Kontrol | Durum |
|---|---|
| `MAINNET_TRADING_ENABLED` / `MAINNET_AUTOPILOT_ENABLED` | `false` |
| `FUTURES_*` (7 bağımsız kilit) | tümü `false` |
| `AUTOPILOT` — `.env` **ve** üretim DB | `false` |
| `TREND_EXECUTION_AUTOPILOT_ENABLED` — her ikisi | `false` |
| `spot_strategy_admission` `allowed=true` | **0 satır** |
| `futures_admission` `allowed=true` | **0 satır** |
| `PAPER_TRADING` | `true` |

> **Önemli:** Üretim DB'sinde `AUTOPILOT=True` kalmıştı. `.env`'i kapatmak tek
> başına yetmiyordu — motor açılışta DB'yi `.env`'in üzerine yazar. Bu oturumda
> düzeltildi. Motoru başlatmadan önce her ikisi de kontrol edilmelidir.

### Test durumu

```
Python  : 871 passed, 1 skipped
Panel   : 13/13, tsc --noEmit temiz
```

### Çalışmaya devam eden

- **Aşama 1 soak testi** — 3. deneme, 7 Ağustos ~22:25'te tamamlanır.
  0 hata, 0 ihlal, kontrollü restart kaydedildi.
  Bilgisayar açık kalmalı; `keep_awake.ps1` çalışıyor.

> **EK — 7 Ağustos 2026:** Yukarıdaki beklenti gerçekleşmedi. 3. deneme
> 4,2 saatte `exit 137` ile öldü, 4. deneme PC kapandığı için hiç başlayamadı.
> Aşama 1 **`PASS` DEĞİL** olarak kapatıldı; kapı gevşetilmedi.
> Yetkili belge: [`stages/asama-1/ASAMA_1_RAPORU.md`](stages/asama-1/ASAMA_1_RAPORU.md).
> Bu bölüm 5 Ağustos'taki durumu yansıttığı için tarihsel olarak korunmuştur.

---

## 5. Soak testinin ortaya çıkardığı gerçek

Soak iki kez öldü — ikisi de koddan değil, **barındırma ortamından**
(`SOAK_DENEME_KAYDI.md`). Bu bir test aksiliği değil:

> Gerçek parayla işlem yapan bir bot 7/24 çalışmak zorundadır. Host 3 gün
> ayakta kalamıyorsa Aşama 7 (canlı pilot) da çalıştırılamaz.

Kalıcı çözüm her zaman açık bir host (küçük bir VPS, ~5-10 USD/ay). Bu, para
riske atılmadan öğrenildi.

---

## 6. Geriye kalan değer

Para kazanılmadı. Ama şunlar gerçek ve kalıcı:

- **Kendini kandırmayan bir ölçüm sistemi.** Ön-kayıt + SHA-256 mühür, PBO,
  Deflated Sharpe, purge/embargo, holdout defteri, eşik-gevşetmeyi kodda
  imkânsız kılan `gates.py`.
- **Survivorship-bias'sız veri altyapısı.** 574 spot sembol (178'i delist),
  425 perp (81'i kapanmış), 2,6M+ veri noktası.
- **Kurumsal seviyede emir yürütme ve güvenlik mimarisi.** DB-first idempotent
  emir, fail-closed reconciliation, RLS lockdown, çift onaylı kilitler.
- **Dürüst bir kanıt zinciri.** Her red gerekçesiyle, her hata kaydıyla,
  her geçersiz sonuç `INVALID` etiketiyle duruyor.

---

## 7. Yeniden başlamak isterseniz

Üç koşuldan biri değişmeden devam etmenin bilgi üretmesi beklenmez:

1. **Aralık 2026** — 2026 H2 tamamlanır ve yeni bir dokunulmamış holdout açılır.
   Defteri güncelleyip yeni bir aday ön-kaydedebilirsiniz.
2. **Farklı veri** — intraday barlar, emir defteri, on-chain. Haftalarca
   altyapı işi ve daha hızlı oyunculara karşı yarış.
3. **Farklı amaç** — alfa aramak yerine yürütme disiplini otomasyonu. Bu
   piyasayı yenmez ama duygusal karar hatasını ortadan kaldırır.

Devam etmek için gereken her şey depoda ve çalışır durumda.

---

**AI Koordinatör İmzası:** Claude (Anthropic)
**Belge:** QBP-CLOSE-001 / 1.0
**Karar:** Strateji arayışı durduruldu; altyapı korundu; mainnet `NO-GO`.
**Not:** Bu belge bir kâr garantisi veya yatırım tavsiyesi değildir.
