# Funding carry v2 gölge defteri — ilk koşu tanı notu (14 Eylül 2026)

Mühür: `funding_carry_v2_shadow_pre_run_seal_v1` (`eaa208c`). Kurallar ve motor değişmedi.
Pencere: ilk işlem 2026-08-05 → son kapanmış gün 2026-09-12. Severe maliyet. Sanal kasa 10.000 USDT.

## Sonuç
| Ölçü | Değer |
|---|---|
| Getiri (tasfiye öncesi günlük eğri) | **−%4,67** (2.000 TL → 1.907 TL) |
| Tasfiye değeri | 9.499,59 USDT |
| En büyük düşüş | %5,04 |
| Toplanan funding | +102,75 USDT |
| Komisyon | −67,97 USDT |
| Ağustos / Eylül (12'sine kadar) | −%4,79 / +%0,12 |
| Evren / verisi olan | 425 / 348 sembol, çekme hatası %0 |

## Kaybın kaynağı: tek bir baz kopması
Kaybın ~%95'i **tek işlemden**: `HFTUSDT`, 2026-08-05 açıldı, 2026-08-07 `basis_broken` ile kapandı.
- Net −443,68 USDT (funding +43,51; spot −239,00; perp −245,22).
- 08-05 → 08-06 perp 0,0182 → 0,0303 (short zararı); 08-06 → 08-07 spot 0,0302 → 0,0128 (−%58) iken perp 0,0238 (−%21). Günlük kapanışta baz **%85,8**.
- İki bacak AYNI yönde zarar etti: delta-nötr varsayımı spot/perp fiyat kopmasında çöker. Bu, carry ailesinin bilinen kuyruk riskidir (delist/likidite olayı). Kural yalnız günlük kapanışta baz kontrolü yapar; gün içi kopmayı göremez.

Bu işlem hariç kalan 18 kapanış ve açık pozisyonlar yaklaşık **sıfır** (−%0,2 civarı) üretti: düşük funding rejiminde severe maliyet, toplanan funding'i büyük ölçüde yedi.

## Yorum (kural değişikliği DEĞİL)
- Sonuç, geliştirme raporundaki uyarıyı doğruluyor: getiri seyrek büyük olaylara bağımlı; kötü tarafı da tek olaydan gelebiliyor.
- 5 haftalık gölge kanıt tek başına bir karar için yetersiz. Protokol gereği parametre/evren değişmez; gölge defter izlenmeye devam eder.
- Yeni bir carry adayı (ör. likidite filtresi, gün içi baz koruması) ancak YENİ ön-kayıt ve mühürle denenebilir.
