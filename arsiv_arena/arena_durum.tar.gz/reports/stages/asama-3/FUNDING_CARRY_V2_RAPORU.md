# funding_carry v2 — Geliştirme Çalışması Raporu

**Rapor kimliği:** QBP-FC2-DEV
**Aday:** `funding_carry_v2_alpha` — çoklu-sembol delta-nötr funding hasadı
**Protokol:** `funding_carry_v2_development_v1`
**Çalışma tipi:** **DEVELOPMENT_ONLY** (holdout koşulmadı — rezerve dönem kalmadı)
**Koşu UTC:** 2026-08-04T20:16:53Z
**Karar:** **`REJECTED`** — 10 kapıdan 2'si başarısız, fakat **asıl sebep kapılar değil** (bölüm 4)

---

## 1. Kapı sonuçları

| # | Kapı | Ölçülen | Eşik | Sonuç |
|---|---|---:|---:|:--:|
| 1 | Profit factor | 3,2448 | ≥ 1,20 | ✅ |
| 2 | Kapanmış işlem | 443 | ≥ 20 | ✅ |
| 3 | Max drawdown | %10,18 | ≤ %15 | ✅ |
| 4 | Yıllık en kötü getiri | -%8,69 | ≥ -%15 | ✅ |
| 5 | Walk-forward pozitif | **%33,33** | ≥ %60 | ❌ |
| 6 | Deflated Sharpe | 1,0000 | ≥ 0,95 | ✅ |
| 7 | PBO | **%25,71** | ≤ %10 | ❌ |
| 8 | Monte Carlo kâr olasılığı | %82,65 | ≥ %55 | ✅ |
| 9 | Ruin olasılığı | %0,00 | ≤ %5 | ✅ |
| 10 | Kayıp içeren örneklem | var | zorunlu | ✅ |

Bu, 14 aile içinde **en çok kapı geçen** aday (8/10). Önceki en iyi `spot_v7` 6/10 idi.

---

## 2. Koşu sırasında bulunan veri hatası

İlk koşu (`funding_carry_v2_development_20260804_200922.json`) **`INVALID`**
ilan edildi ve sonuç olarak kullanılamaz.

**Ne oldu:** Toplam P&L'in %62'si tek sembolden (`RAYUSDT`), %76'sı delist
olmuş kontratlardan geliyordu.

**Kök neden:** `RAYUSDT`'nin spot fiyatı ~8,10 iken perp fiyatı 0,248'de
donmuştu — medyan baz farkı **%60,5**. Perp notional spot'a göre çok küçük
olduğu için hedge sahteydi; "delta-nötr" defter aslında **çıplak long**
pozisyondu. Kazanç funding'den değil bu veri uyuşmazlığından geliyordu.

**Kapsam:** 424 sembolün **10'u** bozuk (medyan baz %41,8, en kötüsü %2909).
**414'ü sağlıklı** (medyan baz **%0,090** — gerçek bir perp/spot çiftinde
beklenen değer).

**Düzeltme:** `max_basis_pct` veri tutarlılık kapısı. Baz eşiği aşan sembolde
pozisyon açılmaz; tutulan pozisyonda baz bozulursa funding sinyalinden
bağımsız olarak çıkılır. Bu bir **parametre onarımı değildir** — strateji
parametreleri değişmedi, bozuk veri elendi.

**Etki:** Delist kontratların payı %76,1 → **%2,6**. Max drawdown %20,84 →
%10,18. PBO %85,71 → %25,71.

---

## 3. Temiz sonuç (2019-09 … 2024-12)

| Maliyet | Getiri | Max DD | Sharpe | İşlem | Sembol |
|---|---:|---:|---:|---:|---:|
| normal | +%105,82 | %1,83 | 5,357 | 443 | 135 |
| high | +%90,19 | %4,75 | 4,650 | 443 | 135 |
| **severe** | **+%68,69** | **%10,18** | **3,601** | 443 | 135 |

Severe katmanda: funding **+11.481**, komisyon **-2.340**, slipaj **-2.495**.
Defter tutarlı: getirinin tamamı funding eksi maliyetlerden geliyor.

**Yıllık:** 2019 -%0,35 · 2020 +%12,16 · **2021 +%54,31** · 2022 -%8,69 ·
2023 -%0,28 · 2024 +%7,63

---

## 4. Asıl sebep: sonuç tek bir rejim olayı

Kapı başarısızlıklarından daha önemlisi bu.

| Yoğunlaşma | Pay |
|---|---:|
| **Tek işlem** (ADAUSDT) | **%38,5** |
| En iyi 1 sembol | %38,6 |
| En iyi 5 sembol | %73,6 |
| En iyi 10 sembol | %97,5 |
| İşlem yapılan sembol | 135 |

En iyi 5 işlemin **tamamı** 2020 sonunda açılıp **2021-05-21**'de kapanmış;
195-238 gün tutulmuşlar:

```
2021-05-21  ADAUSDT   net +2645  funding +2799  238 gun
2021-05-21  ZECUSDT   net  +640  funding  +666  225 gun
2021-05-21  ETHUSDT   net  +535  funding  +562  195 gun
2021-05-21  BATUSDT   net  +492  funding  +511  227 gun
2021-04-27  ALGOUSDT  net  +450  funding  +471  214 gun
```

Yani stratejinin tüm sonucu: **2021 boğasında funding olağanüstü yüksekken
birkaç pozisyonu aylarca tutmak ve Mayıs 2021 çöküşünde çıkmak.**

Bu, planın Aşama 3 şartını doğrudan ihlal eder:
> *"Sonuç birkaç uç işleme veya dar parametre noktasına bağımlı değildir."*

Ve diğer bulguları da açıklıyor:
- **Çarpıklık +4,44, basıklık 40,47** — birkaç devasa pozitif sonuç
- **Sharpe 3,60-5,36** — gerçek bir edge'den değil, bu nadir yapıdan
- **Walk-forward %33** — yalnızca 2021'i içeren pencereler kazanıyor
- **2021 dışındaki yıllar ~0** — normal rejimde funding ≈ maliyet

**Deflated Sharpe 1,0000 güvenilir değildir.** PSR normal dağılım varsayar;
çarpıklık 4,44 ve basıklık 40,47'de bu yaklaşım geçerliliğini yitirir. Kapı
geçmiş görünüyor fakat ölçüm anlamlı değil.

---

## 5. Yine de öğrenilen

**Funding carry mekanizması gerçek.** 11.481 USDT funding fiilen toplandı ve
defter delta-nötrlüğü dört fiyat yolunda `0.000000000` ile doğrulandı. Sorun
mekanizma değil, **büyüklüğü**: normal rejimde funding maliyetleri ancak
karşılıyor. Fazlası yalnızca aşırı boğa dönemlerinde çıkıyor.

Bu, 1.000-5.000 USD'lik bir hesap için şu anlama gelir: normal piyasada bu
strateji ~sıfır getirir; kazanç bir sonraki funding patlamasını beklemeye
bağlıdır. Bu bir **gelir kaynağı değil**, opsiyon benzeri bir bahistir.

---

## 6. Karar ve sınırlar

**`REJECTED`.** Parametre onarımı yapılmadı ve yapılmayacak.

- Bu bir Aşama 3 kabulü değildi zaten (holdout koşulmadı, rezerve dönem yok).
- `FUTURES_*` kilitlerinin tamamı kapalı kaldı; hiçbir runtime bayrağı
  değiştirilmedi.
- Çalışma yalnızca Binance public tarihsel veri okudu.

**Bu, 14. reddedilen ailedir.**

---

## 7. Doğrulama

```
Python regresyonu : 860 passed, 1 skipped
Mühür             : seal v2 dogrulandi (13 dosya SHA-256)
Delta-notrluk     : 4 fiyat yolunda yon PnL = 0.000000000 (maliyetsiz)
Nakit korunumu    : birim testle bagli
Baz kapisi        : 3 test (acilis reddi, saglikli baz, tutarken bozulma)
```

---

AI Koordinatör İmzası : Claude (Anthropic)
Belge                  : QBP-FC2-DEV / 1.0
UTC zaman              : 2026-08-04T20:16:53Z
Karar                  : **REJECTED** — sonuç tek rejim olayına bağımlı
İnsan onayı            : BEKLENİYOR
