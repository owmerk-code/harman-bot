# Aşama 3 — `spot_v7_alpha` Doğrulama Raporu

**Rapor kimliği:** QBP-STAGE-3-SPOTV7
**Plan sürümü:** 2.0
**Koşu UTC:** 2026-08-04T00:21:22Z
**Ön-kayıt:** [`research/spot_v7_development_protocol.json`](../../../research/spot_v7_development_protocol.json)
**Mühür:** [`research/spot_v7_pre_run_seal.json`](../../../research/spot_v7_pre_run_seal.json) — koşu öncesi doğrulandı (11 dosya)
**Makine raporu:** [`reports/spot_v7_validation_20260804_002122.json`](../../spot_v7_validation_20260804_002122.json)

## Karar

**`REJECTED`** — 10 kapıdan 4'ü geçilemedi.

Aynı veri üzerinde parametre onarımı yapılmayacaktır. Yeni bir aday, yeni sürüm
kimliği ve yeni ön-kayıtla başlar (protokol `failure_action`).

## Kapı sonuçları

| Kapı | Ölçülen | Eşik | Sonuç |
|---|---:|---:|---|
| Profit factor | **3,20** | ≥ 1,20 | ✅ |
| Kapanmış işlem | **191** | ≥ 20 | ✅ |
| Kayıp içeren örneklem | var | zorunlu | ✅ |
| PBO | **%8,57** | ≤ %10 | ✅ |
| Monte Carlo kâr olasılığı | **%64,55** | ≥ %55 | ✅ |
| Ruin olasılığı | **%0,00** | ≤ %5 | ✅ |
| Development max drawdown | **%28,70** | ≤ %15 | ❌ |
| Yıllık en kötü getiri | **-%20,41** | ≥ -%15 | ❌ |
| Walk-forward pozitif pencere | **%33,33** | ≥ %60 | ❌ |
| Deflated Sharpe | **0,5443** | ≥ 0,95 | ❌ |

## Ölçümler

### Evren (survivorship-bias'sız)

574 sembol · **178'i delist olmuş** · 761.901 bar · sıfır çekim hatası.
Development koşusunda 68 sembol işlem gördü ve **8 delist tasfiyesi** yapıldı.
Bu, deponun ilk survivorship-bias'sız çalışmasıdır.

### Development 2019–2024

| Maliyet | Getiri | Max DD | PF | İşlem |
|---|---:|---:|---:|---:|
| normal (10bps + 5bps) | +%87,02 | %28,38 | 3,28 | 191 |
| high (15bps + 10bps) | +%86,05 | %28,51 | 3,24 | 191 |
| **severe (20bps + 20bps)** | **+%84,60** | **%28,70** | **3,20** | **191** |

Maliyet duyarlılığı düşük — düşük devirli tasarım çalışıyor (72 yeniden dengeleme).

**Yıllık:** 2019 -%2,76 · 2020 +%28,29 · 2021 +%33,00 · **2022 -%20,41** ·
2023 +%22,19 · 2024 +%12,28

### Benchmark

Al-tut (BTC/ETH eşit ağırlık) aynı dönemde **+%2.331,97**. Strateji +%84,60.

Bu **beklenen** sonuçtur ve ön-kayıtta açıkça yazılıydı: TSMOM'un getiri kaynağı
fiyat tahmini değil risk yönetimidir; boğada geride kalması tasarım gereğidir.
Boğa piyasasında al-tut'u geçmek bir başarı ölçütü olarak konmamıştı.

### Holdout 2025

Getiri **-%1,99** · max DD %6,69 · 19 işlem · PF 0,55
Al-tut aynı dönemde **-%9,45** (BTC -%7,34, ETH -%11,57).

Yani düşüş yılında al-tut'tan **7,5 puan** daha iyi ve drawdown'ı çok daha
düşük — hipotezin öngördüğü koruma imzası **gözlendi**. Ama mutlak getiri yine
de negatif; koruma tek başına kabul için yeterli değildir.

*Körlük sınırı:* 2025 bu projede 11+ kez puanlandı. Aday-özgü dokunulmamış
holdout'tur, küresel blind kanıt değildir.

### İstatistiksel kontroller

- **PBO %8,57** (≤%10 geçti). Parametre komşuluğu üzerinde hesaplandı; dondurulmuş
  konfigürasyon sonuçlara bakılarak seçilmedi. **Aday overfit değil.**
- **Monte Carlo** (2000 blok-bootstrap, 180 gün ufuk): kâr olasılığı %64,55,
  ruin %0,00, medyan +%3,59, p05 -%11,41.
- **Deflated Sharpe 0,5443** — kapıyı geçemedi ve **en önemli bulgu budur.**
  Gözlenen günlük Sharpe **0,037981**; 12 denemelik çoklu-test düzeltmesinden
  sonra sıfır yetenekle beklenen en yüksek Sharpe **0,035567**.
  Yani gözlenen edge, seçim gürültüsünden ayırt edilemiyor.
- **Walk-forward** (purge + embargo, 6 pencere, 730 gün eğitim / 180 gün test):
  %33,33 pozitif. Pencere getirileri ±%4 bandında — düşük maruziyet nedeniyle
  sinyal zayıf.

## Yorum

Aday iki şeyi **başardı**: aşırı-uydurma yapmadı (PBO %8,57) ve düşüş yılında
korudu (holdout al-tut'a karşı +7,5 puan). Kâr faktörü 3,20 ve 191 işlemlik
örneklem, bu deponun bugüne kadar ürettiği en geniş kanıt tabanıdır.

Aday üç şeyde **kaldı**:

1. **Risk profili çok ağır.** %28,70 drawdown ve -%20,41 en kötü yıl, %12
   yıllık volatilite hedefiyle uyumsuz. Gerçekleşen portföy volatilitesi hedefin
   1,21 katı; 60 günlük geriye bakış rejim değişimini geç yakalıyor.
2. **Zaman içinde tutarsız.** Walk-forward pencerelerinin yalnızca üçte biri
   pozitif ve büyüklükler ±%4 — sinyal çoğu pencerede neredeyse hiç maruziyet
   üretmiyor.
3. **Edge, çoklu-test düzeltmesinden sonra kayboluyor.** Deflated Sharpe 0,54,
   yani bu sonuç 12 deneme yapıldığında şansla elde edilebilecek seviyeye çok
   yakın.

Kısacası: mekanizma **çalışıyor ama yeterince güçlü değil**. Aylık yeniden
dengeleme rejim değişimini yakalamakta yavaş, ve %12 vol hedefi kripto
volatilitesinde anlamlı bir maruziyet üretemiyor.

## Yasaklı eylem beyanı

Bu sonuçlara bakılarak `target_portfolio_vol_annual_pct`, momentum ufukları,
geriye bakış pencereleri veya evren büyüklüğü **değiştirilmemiştir**. Böyle bir
değişiklik parametre onarımıdır ve ön-kayıt tarafından yasaklanmıştır.

Motor smoke test'i sırasında kısmi sonuç görüldüğü, protokolün
`disclosure_engine_smoke_test` bölümünde koşudan **önce** kayda geçirilmişti.

## Runtime güvenliği

Bu çalışma emir göndermedi, hiçbir runtime/autopilot/mainnet/futures bayrağını
değiştirmedi ve yalnızca salt-okunur public piyasa verisi kullandı.
Rezerve edilen 2026 H1 dönemine erişilmedi.

## Sıradaki karar

Plan bölüm 5 gereği, başarısız bir adaydan sonra yeni aday üretmek **ayrı bir
insan kararıdır**. Teknik gözlem olarak kaydedilir (öneri değil, bulgu):
başarısızlık üç kapıda toplandı ve üçü de **maruziyet/rejim tepkisi** ekseninde;
sinyal mekaniğinde değil. Yeni bir aday bu ekseni ele almalıdır.

---

AI Koordinatör İmzası : Claude (Anthropic)
Belge                  : QBP-STAGE-3-SPOTV7 / 1.0
UTC zaman              : 2026-08-04T00:21:22Z
Kaynak commit          : 06ce114932e0
Karar                  : REJECTED
İnsan onayı            : gerekmiyor (ret kararı mainnet kilidi açmaz)
