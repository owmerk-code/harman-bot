# Aşama 3 — Kapanış Raporu (spot_v8)

**Rapor kimliği:** QBP-STAGE-3-V8
**Plan sürümü:** 2.0
**Aday:** `spot_v8_alpha` — kesitsel momentum + genişlik-kapılı nakit (long/cash)
**Protokol:** `spot_v8_development_v1`
**Kaynak commit:** `937a1bef2424`
**Koşu UTC:** 2026-08-04T00:58:49Z
**Mühür doğrulaması:** `seal_verified = true` (14 dosya SHA-256)
**Holdout:** 2026-01-01..2026-06-30 (`holdout-2026H1`, koşu öncesi **rezerve**, koşu sonrası **tüketildi**)
**Karar:** **`REJECTED`** — 10 kapıdan **7'si** başarısız

---

## 1. Kapı sonuçları

| # | Kapı | spot_v8 | spot_v7 | Eşik | Sonuç |
|---|---|---:|---:|---:|:--:|
| 1 | Profit factor | 1,2109 | 3,1973 | ≥ 1,20 | ✅ |
| 2 | Kapanmış işlem | 254 | 191 | ≥ 20 | ✅ |
| 3 | Development max drawdown | **%64,45** | %28,70 | ≤ %15 | ❌ |
| 4 | Yıllık en kötü getiri | **-%35,14** | -%20,41 | ≥ -%15 | ❌ |
| 5 | Walk-forward pozitif | %50,00 | %33,33 | ≥ %60 | ❌ |
| 6 | Deflated Sharpe | **0,1149** | 0,5443 | ≥ 0,95 | ❌ |
| 7 | PBO | **%81,43** | %8,57 | ≤ %10 | ❌ |
| 8 | Monte Carlo kâr olasılığı | **%50,50** | %64,55 | ≥ %55 | ❌ |
| 9 | Ruin olasılığı | **%5,40** | %0,00 | ≤ %5 | ❌ |
| 10 | Kayıp içeren örneklem | var | var | zorunlu | ✅ |

**spot_v8 her ölçüde spot_v7'den kötü.** Tek istisna walk-forward oranı
(%50 vs %33), o da eşiğin altında.

---

## 2. En önemli bulgu: PBO %81,43

spot_v7'nin PBO'su **%8,57** idi — yani parametre komşuluğunda en iyi
konfigürasyonu seçmek, out-of-sample'da sistematik bir dezavantaj üretmiyordu.
spot_v8'de bu oran **%81,43**.

Bu şu demek: kesitsel momentumda "en iyi parametre"yi seçmek, **on kez
denerseniz sekizinde** out-of-sample'da medyanın altına düşürür. Sinyal
parametre seçimine aşırı duyarlı — yani kalıcı bir yapı değil, gürültü.

Deflated Sharpe 0,1149 aynı şeyi söylüyor: 13 aile denendikten sonra gözlenen
performans, sıfır yetenekle beklenen en yüksek performanstan **ayırt
edilemiyor**.

---

## 3. Genişlik kapısı işe yaramadı

Tasarım hipotezi şuydu: klasik kesitsel momentum long-short'tur ve beta böyle
nötrlenir; spot'ta açığa satış olmadığı için maruziyeti **piyasa genişliğiyle**
ölçekleyerek aynı korumayı sağlayabiliriz.

**Sağlamadı.** Max drawdown %28,70'ten **%64,45'e** çıktı — koruma değil,
iki kat kötüleşme.

Muhtemel sebep: kesitsel momentum evrenin **en hızlı yükselen üst çeyreğine**
yoğunlaşır. Kriptoda bu dilim en spekülatif, en volatil varlıklardan oluşur.
Yoğunlaşma, genişlik kapısının sağladığı korumadan daha fazla risk ekliyor.
Ayrıca %40 genişlik eşiği kriptoda fazla geçirgen: piyasa düşerken bile
evrenin %40'ından fazlası bir süre pozitif formasyon getirisi taşıyabiliyor.

---

## 4. Ölçümler

**Development (2019–2024, severe maliyet)**
```
getiri            +%77,05        max drawdown   %64,45
profit factor      1,2109        kapanmış işlem    254
```

**Walk-forward (purge + embargo)**
```
2020-12-31  -%43,82      2022-08-29  +%1,07
2021-07-21   -%8,78      2023-03-19  +%1,45
2022-02-08   +%0,00      2023-10-07 +%14,23
```

**Monte Carlo (2000 sim):** kâr olasılığı %50,50 (yazı-tura), ruin %5,40

**Holdout 2026 H1:** getiri **-%13,82**, max DD %13,76, 8 kapanmış işlem

---

## 5. Holdout defteri — bu koşunun bedeli

`holdout-2026H1` koşu öncesi **rezerve** ve hiç puanlanmamıştı; bu yüzden
-%13,82 sonucu **geçerli bir out-of-sample ölçümdür**. Koşu sonrası dönem
`consumed` işaretlendi.

**Artık rezerve tarihsel holdout kalmadı.** Bundan sonraki adaylar için tek
geçerli out-of-sample kaynağı **ileriye dönük zamandır** (Aşama 4 forward
paper) veya takvim ilerledikçe açılacak yeni dönemlerdir (2026 H2).

Bu, bir sonraki adayın önündeki en önemli kısıttır ve sessizce aşılamaz:
`assert_holdout_available()` tüketilmiş bir dönemde koşmaya çalışan runner'ı
durdurur.

---

## 6. İki reddin birlikte söylediği

| | spot_v7 (TSMOM) | spot_v8 (kesitsel) |
|---|---|---|
| Overfit mi? | **Hayır** (PBO %8,57) | **Evet** (PBO %81,43) |
| Holdout | -%1,99 (B&H -%9,45) | -%13,82 |
| Sinyal | zayıf ama gerçek | gürültüden ayırt edilemiyor |

**Zaman-serisi momentumu kriptoda kesitsel momentumdan üstün.** spot_v7'nin
sinyali gerçekti, sadece yeterince güçlü değildi. spot_v8'inki gerçek bile
değil.

Bu, iki koşunun ürettiği kalıcı bilgi: **kesitsel momentum bu evrende
dondurulmuştur.** Yeni bir aday bu mekaniğe dönmemelidir.

---

## 7. Sonraki aday için

Ölçüm hattından çıkan yön, spot_v7'nin başarısızlık biçimine dayanıyor —
spot_v8'inkine değil (o zaten gürültü):

spot_v7 kripto betasından ayrışamadı ama **overfit değildi ve holdout'ta
buy & hold'u yendi**. Ayrışmayı artıracak, mekanik olarak farklı yollar:

1. **Piyasa-nötr yapı** — long/short gerektirir, yani futures. Bu, sahibin
   ayrı kararıdır ve `FUTURES_*` kilitleri kapalıdır.
2. **Açık drawdown kontrolü** — vol hedefleme drawdown'ı hedeflemiyor.
   Ayrı bir mekanik olarak ön-kaydedilebilir.
3. **funding_carry v2** — muhasebe hatası düzeltildi
   (`reports/funding_carry_INVALID_NOTE.md`) fakat henüz yeniden
   değerlendirilmedi. Delta-nötr olduğu için betadan yapısal olarak bağımsız.
   Futures gerektirir.

**Uyarı:** üçünden ikisi futures gerektiriyor ve rezerve holdout kalmadı.
Bir sonraki adım gerçek bir sahip kararıdır.

---

## 8. Doğrulama

```
Python regresyonu : 833 passed, 1 skipped
Mühür             : seal_verified = true (14 dosya SHA-256)
Holdout kapisi    : assert_holdout_available() koşu öncesi geçildi
Parametre onarımı : YAPILMADI
```

---

AI Koordinatör İmzası : Claude (Anthropic)
Belge                  : QBP-STAGE-3-V8 / 1.0
UTC zaman              : 2026-08-04T00:58:49Z
Kaynak commit          : 937a1bef2424
Karar                  : **REJECTED** (7/10 kapı başarısız)
İnsan onayı            : BEKLENİYOR — sonraki adım proje sahibine aittir
