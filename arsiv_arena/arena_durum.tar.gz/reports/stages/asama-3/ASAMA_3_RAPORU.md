# Aşama 3 — Kapanış Raporu (spot_v7)

**Rapor kimliği:** QBP-STAGE-3
**Plan sürümü:** 2.0
**Aday:** `spot_v7_alpha` — çok-varlıklı, volatilite-hedefli TSMOM (long/cash)
**Protokol:** `spot_v7_development_v1`
**Kaynak commit:** `06ce114932e000f7fa41226d8ffc4e3072ba77c7`
**Koşu UTC:** 2026-08-04T00:21:13Z
**Mühür doğrulaması:** `seal_verified = true` (11 dosya SHA-256)
**Karar:** **`REJECTED`** — 10 kapıdan 4'ü başarısız

---

## 1. Kapı sonuçları

| # | Kapı | Ölçülen | Eşik | Sonuç |
|---|---|---:|---:|:--:|
| 1 | Profit factor | **3,1973** | ≥ 1,20 | ✅ |
| 2 | Kapanmış işlem | **191** | ≥ 20 | ✅ |
| 3 | Development max drawdown | **%28,70** | ≤ %15 | ❌ |
| 4 | Yıllık en kötü getiri | **-%20,41** | ≥ -%15 | ❌ |
| 5 | Walk-forward pozitif pencere | **%33,33** | ≥ %60 | ❌ |
| 6 | Deflated Sharpe | **0,5443** | ≥ 0,95 | ❌ |
| 7 | PBO | **%8,57** | ≤ %10 | ✅ |
| 8 | Monte Carlo kâr olasılığı | **%64,55** | ≥ %55 | ✅ |
| 9 | Ruin olasılığı | **%0,00** | ≤ %5 | ✅ |
| 10 | Kayıp içeren örneklem | **var** | zorunlu | ✅ |

Plan bölüm 5: *"Tek zorunlu kapı bile geçmezse aday `REJECTED` olur."*

---

## 2. Evren — bu çalışmanın tek gerçek yeniliği

| | Önceki 11 aile | spot_v7 |
|---|---|---|
| Sembol sayısı | 1–2 | **574** |
| Toplam bar | ~10.000 | **761.901** |
| Delist olmuş sembol | 0 | **178** |
| Survivorship bias | var | **yok** |
| Kapanmış işlem (dev) | 3–18 | **191** |

Binance `exchangeInfo` işlemden kalkmış pariteleri `BREAK` statüsüyle tutar ve
bu semboller için tarihsel klines dönmeye devam eder. Evrene dahil edildiler.
Çalışma 68 farklı sembolde işlem yaptı ve **8 delist tasfiyesi** gerçekleşti —
yani batmış coinler gerçekten portföye girdi ve zararıyla kaydedildi.

---

## 3. Development sonucu (2017–2024, severe maliyet)

```
getiri            +%84,60        max drawdown   %28,70
Sharpe             0,7977        profit factor    3,1973
kapanmış işlem       191         win rate        %65,97
komisyon         $145,74         slipaj         $145,64
işlem gören sembol    68         delist tasfiyesi     8
yeniden dengeleme     68
```

Maliyet katmanları arasında fark küçük (normal +%87,02 → severe +%84,60);
aylık yeniden dengeleme devri düşük tuttuğu için strateji maliyete duyarlı
değil. Bu, tasarımın çalışan yanı.

---

## 4. Walk-forward (purge + embargo uygulandı)

| Test başlangıcı | Getiri | Max DD | İşlem |
|---|---:|---:|---:|
| 2020-12-31 | %0,00 | %0,00 | 0 |
| 2021-07-21 | -%0,59 | %0,68 | 2 |
| 2022-02-08 | -%0,55 | %1,14 | 5 |
| 2022-08-29 | **+%3,81** | %1,21 | 17 |
| 2023-03-19 | -%0,87 | %3,97 | 19 |
| 2023-10-07 | **+%3,96** | %2,45 | 10 |

Pozitif pencere oranı **%33,33** (eşik %60). İlk pencere sıfır işlem üretti;
bu, "yeterli örneklem yok" durumudur ve pozitif sayılmamıştır.

---

## 5. Holdout 2025 — en anlamlı bulgu

```
getiri              -%1,99          max drawdown     %6,69
profit factor        0,5461         Sharpe          -0,3495
kapanmış işlem          19
buy & hold: BTC -%7,34 | ETH -%11,57 | eşit ağırlık -%9,45
```

Strateji holdout'ta **buy & hold'u 7,46 puan yendi** (-%1,99 vs -%9,45) ve
drawdown'ı %6,69'da tuttu. Bu, TSMOM'un beklenen savunma imzasıdır ve gerçektir.

**Ancak "buy & hold'dan az kaybetmek" bir edge değildir.** Mutlak getiri
negatiftir; 1.000–5.000 USD'lik bir hesapta bu, para kaybetmek demektir.

**Körlük sınırı:** 2025 dönemi bu projede 11+ kez puanlanmıştır. Bu holdout
adaya özgü olarak dokunulmamıştır fakat **küresel anlamda blind değildir**.

---

## 6. Yorum — neden reddedildi ve bu ne anlama geliyor

**Bu bir overfit değil.** PBO %8,57 (eşik %10) ve holdout'ta buy & hold'un
üzerinde performans var. Önceki ailelerin çoğu tam tersini gösteriyordu.
Sinyal gerçek; sorun gücü.

Dört başarısızlık aynı şeyi söylüyor: **strateji kripto beta'sının filtrelenmiş
hâli.** Yükselişi yakalıyor, düşüşte kaybı azaltıyor, ama:

- Drawdown %28,70 — kripto'nun kendi drawdown'ından yeterince ayrışmıyor.
- En kötü yıl -%20,41 — vol hedefleme (%12) pratikte %14,6 gerçekleşiyor ve
  rejim kırılmalarında koruma gecikiyor (aylık yeniden dengeleme).
- Walk-forward %33 — kazanç iki pencerede yoğunlaşmış, sürekli değil.
- Deflated Sharpe 0,544 — çoklu-test düzeltmesinden sonra gözlenen Sharpe
  (0,80) "yeterince deneme yapılırsa tesadüfen çıkabilecek" seviyeden
  ayırt edilemiyor.

**Parametre onarımı yapılmamıştır ve yapılmayacaktır.** `engine/research/gates.py`
`tightened()` fonksiyonu eşik gevşetmeyi `ValueError` ile reddeder; sonucu
görüp eşik düşürmek bu projenin daha önce düştüğü hatadır.

---

## 7. Aşama 4'e devredilmeyenler

Aday Aşama 3'ü geçmediği için **forward paper kampanyası başlatılmaz**.
90 günlük Aşama 4 süreci bu adayla harcanmaz.

---

## 8. Sonraki aday için zorunlu farklar

`spot_v7` reddi, **çok-ufuklu TSMOM + vol hedefleme + aylık yeniden dengeleme**
mekaniğini bu evrende dondurur. Yeni aday farklı bir mekanik kullanmalıdır.
Ölçüm hattından çıkan somut yönler:

1. **Çapraz-kesitli (relative) momentum** — mevcut sinyal zaman-serisi
   momentumu; her varlık kendi geçmişine göre değerlendiriliyor. Kesitsel
   sıralama (en güçlü N varlık, en zayıflara karşı) kripto betasından daha
   iyi ayrışabilir.
2. **Daha sık risk yönetimi** — aylık yeniden dengeleme rejim kırılmasında
   30 güne kadar geç kalıyor; en kötü yıl kaybının ana kaynağı bu.
3. **Açık drawdown kontrolü** — vol hedefleme drawdown'ı hedeflemez. Ayrı bir
   drawdown-tepkili maruziyet azaltma katmanı ölçülmelidir.

---

## 9. Doğrulama

```
Python regresyonu : 805 passed, 1 skipped
Mühür             : seal_verified = true (11 dosya SHA-256)
Maliyet katmanları: normal / high / severe — kapılar severe ile değerlendirildi
Look-ahead        : karar barı t-1, yürütme t açılışı; purge+embargo uygulandı
Nakit korunumu    : birim testle bağlı (test_portfolio_engine)
```

---

AI Koordinatör İmzası : Claude (Anthropic)
Belge                  : QBP-STAGE-3 / 1.0
UTC zaman              : 2026-08-04T00:21:13Z
Kaynak commit          : 06ce114932e000f7fa41226d8ffc4e3072ba77c7
Karar                  : **REJECTED** (4/10 kapı başarısız)
İnsan onayı            : BEKLENİYOR — yeni aday kararı proje sahibine aittir
