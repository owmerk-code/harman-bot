# Aşama 1 — Üretim Güvenilirliği

**Durum:** `KISMİ — PASS DEĞİL`
**Başlangıç:** 31 Temmuz 2026 · **Kapanış:** 7 Ağustos 2026
**Kapanış raporu:** [`ASAMA_1_RAPORU.md`](ASAMA_1_RAPORU.md)
**Yetkili kapsam:** [`ANA_UYGULAMA_PLANI.md`](../../../ANA_UYGULAMA_PLANI.md)

Tamamlanan doğrulama paketleri:

- Trade memory FORCE RLS ve SECURITY DEFINER lockdown
- AI shadow/advisory ile env-only enforcement ayrımı
- Autopilot aday yaşı ve emir öncesi taze REST fiyatı
- Stale heartbeat canlılık kontratı
- Gerçek yerel DB execution integration
- Emir/fill/fee muhasebesi ve risk persistence
- Watchdog, Docker build/health, uygulama backup/restore
- Kontrollü restart ve runtime lease kaybı fault injection

Sağlanamayan kapı:

- İzole paper stack üzerinde en az 72 saatlik soak. **Dört deneme, dördü de
  kesintiye uğradı** — hiçbiri koddan değil, barındırma ortamından. En uzun
  temiz gözlem 4,6 saat (hedefin %6,4'ü); motor çalıştığı sürece **sıfır
  ihlal** üretti.

Aşama 1, soak özeti `complete=true` ve `passed=true` üretmeden tamamlanmaz —
ve **üretmedi**. Kapı gevşetilmedi; durum olduğu gibi kayda geçirildi.
Gereken tek şey her zaman açık bir host. Ayrıntı:
[`ASAMA_1_RAPORU.md`](ASAMA_1_RAPORU.md) ve
[`SOAK_DENEME_KAYDI.md`](SOAK_DENEME_KAYDI.md).
