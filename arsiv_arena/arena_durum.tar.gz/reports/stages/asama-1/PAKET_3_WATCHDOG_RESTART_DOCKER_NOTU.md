# Aşama 1 — Paket 3 Watchdog, Restart ve Docker Notu

**Durum:** `72H_SOAK_IN_PROGRESS`  
**Tarih:** 1 Ağustos 2026  
**Mainnet:** `NO-GO`

## Uygulanan güvenlik değişikliği

- Graceful shutdown yeni iş kapısını kapatır kapatmaz event-loop watchdog'u
  disarm eder.
- Uzun fakat düzenli DB/exchange cleanup süreci artık yanlış `exit(70)` üretmez.
- Cleanup sonundaki watchdog thread stop davranışı korunur.
- Docker `stop_grace_period=60s` takılan shutdown için dış sınır olmaya devam
  eder.

## Doğrulamalar

- Watchdog/restart/health/lifecycle hedefli Python: 49 passed.
- Tam Python regresyonu: 693 passed, 1 skipped, 6 üçüncü taraf uyarısı.
- Panel güvenlik sözleşmeleri: 11 passed.
- TypeScript `tsc --noEmit`: PASS.
- Docker Compose statik config: PASS.
- Engine Docker image build: PASS.
- Panel Docker image + Next.js production build (19 route): PASS.
- Engine image runtime safety-lock assertion: PASS.
- Container kullanıcıları:
  - engine: `uid=10001(quant)` / root değil.
  - panel: `uid=1000(node)` / root değil.
- Panel image smoke:
  - Docker health: `healthy`.
  - localhost HTTP `/`: 200.
  - Geçici container test sonunda kaldırıldı.
- Uygulama backup/restore:
  - Tam Supabase platform dump'ı `realtime` ve Vault bağımlılıkları/secrets
    riski nedeniyle uygulama yedeği olarak reddedildi.
  - Yalnız `public` ve `supabase_migrations` kapsamlı dump izole DB'ye restore
    edildi.
  - Restore bağımlılığı olarak yalnız Supabase'in `auth.role()` ve `auth.uid()`
    sözleşmeleri test DB'sinde stublandı; kaynak DB değiştirilmedi.
  - Kaynak/restore özeti birebir eşleşti:
    `44 migration | 2223 grid_orders | 277 bot_sessions | 1 risk_state |
    96 settings | 27 public tablo | processing constraint=1 |
    trade_memory RLS/FORCE=1/1`.
  - İzole restore DB ve geçici dump doğrulamadan sonra silindi.
- `git diff --check`: içerik hatası yok; yalnız Windows CRLF bilgilendirmeleri.
- İzole paper-only çalışma ortamı:
  - Supabase DB/Kong `healthy`, REST `running`.
  - Engine ve panel `healthy`; panel `/health` ve `/` HTTP 200.
  - Panel izinli `bot_status` ve güvenli `settings` okumaları HTTP 200.
  - Başlangıç ledger özeti: `0 aktif oturum | 0 çözümlenmemiş emir |
    1 aktif runtime lease | 0 eksik filled-order ücreti`.
- Kontrollü engine restart:
  - Container başlangıç zamanı değişti ve yeniden `healthy` oldu.
  - Runtime lease yeniden tekilleşti; oturum/emir sayıları sıfır kaldı.
  - Paper state SHA-256 değişmedi.
- Runtime lease kaybı fault injection:
  - Yalnız izole `bot_runtime_lease` singleton satırı silindi.
  - Motor lease yenilemeyi reddetti, logda `fail-closed duruyor` kaydı oluştu
    ve süreç kapandı.
  - Docker restart politikası motoru yeniden başlattı; motor paper kilidini
    doğruladı, lease'i yeniden aldı ve `healthy` duruma döndü.
  - Kurtarma sonrası `1 lease | 0 aktif oturum | 0 çözümlenmemiş emir` ve
    değişmemiş paper state hash'i doğrulandı.
- `scripts/stage1_soak_monitor.py` eklendi ve iki birim testi geçti.
  - Motor/panel/HTTP, heartbeat, singleton lease, ledger, ücret tamlığı ve paper
    state hash'ini 30 saniyede bir JSONL kanıtına yazar.
  - Toplama hatası veya herhangi bir ihlal sonucu otomatik olarak FAIL yapar.
  - Hata veya ihlalde sonraki sağlıklı örneklerle silinmeyen `alert.json` üretir.
  - Runtime sırları ve kanıt dizini `data/stage1_soak/` Git dışında tutulur.
- Supabase loopback güvenlik betiğinin runtime secret mount'larını ve motor API
  ağ takma adını koruduğunu doğrulayan iki statik sözleşme testi geçti;
  PowerShell parser sonucu sıfır hatadır.
- Temiz 72 saatlik soak `2026-08-01 05:26:12 UTC` tarihinde başlatıldı;
  en erken tamamlanma `2026-08-04 05:26:12 UTC` (`08:26:12 Europe/Istanbul`).
  - İlk iki örnek: `0 toplama hatası | 0 ihlal | 1 restart geçişi`.
  - `complete=false` ve `passed=false` olması süre dolana kadar beklenen güvenli
    durumdur.

## Kalan kabul kapıları

- En az 72 saat kesintisiz soak süresinin tamamlanması ve özetin
  `complete=true`, `passed=true` üretmesi.

Bu belge Aşama 1 kapanış raporu veya canlı işlem onayı değildir.
