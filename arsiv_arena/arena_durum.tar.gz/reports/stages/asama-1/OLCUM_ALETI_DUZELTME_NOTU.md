# Ölçüm aleti düzeltmesi — soak izleyicisi açılış penceresi

**Tarih:** 7 Ağustos 2026
**Dosya:** [`scripts/stage1_soak_monitor.py`](../../../scripts/stage1_soak_monitor.py)
**Sınıflandırma:** **ALET KUSURU DÜZELTMESİ** — kabul kapısı değişikliği *değil*
**Onay:** Proje sahibi ("EN İYİ OLANI YAP", seçenekler ve riski açıkça sunulduktan sonra)

> **Bu değişiklik başarısız bir sonuç görüldükten SONRA yapılmıştır.**
> Bu, projenin kırmızı çizgisine ("eşikleri sonuç görünce değiştirme") temas
> eden bir durumdur ve bu yüzden gizlenmek yerine ayrı bir belgeyle kayda
> geçiriliyor. Aşağıda hem gerekçe hem de karşı argüman yazılıdır; okuyucu
> kendi kararını verebilsin.

---

## 1. Ne oldu

5. soak denemesinde, koşunun **3. örneğinde** ihlal kaydedildi:

```json
"engine":      { "health": "starting", "started_at": "2026-08-06T22:51:42.520776101Z" },
"observed_at": "2026-08-06T22:51:47.705906+00:00",
"violations":  ["engine_not_healthy"]
```

Motor bozulmamıştı. Bu, **runbook'un zorunlu kıldığı kontrollü restart'ın**
açılış penceresiydi — 5 saniye sonra `healthy` oldu.

## 2. Çelişki

Runbook'un kendi kabul ölçütleri:

| # | Ölçüt |
|---|---|
| 6 | "En az bir **kontrollü motor restart** geçişi görülür ve sistem kendiliğinden sağlığa döner" |
| 7 | "Toplama hatası veya kabul **ihlali varsa sonuç PASS olamaz**" |

Eski kod ([satır 107](../../../scripts/stage1_soak_monitor.py#L107)):

```python
if engine["status"] != "running" or engine["health"] != "healthy":
    found.append("engine_not_healthy")
```

`starting` de `healthy` değildir → ihlal. Ve ihlaller **kalıcı olarak
mandallanır** (*"Deliberately latched: a later healthy sample must not erase
evidence."*).

**Sonuç:** Ölçüt 6 restart'ı zorunlu kılıyor, ölçüt 7 restart'ı öldürüyor.
Örnekleme aralığı 30 sn, açılış penceresi ~15 sn → örneğin pencereye düşme
olasılığı **~%50**. Yani Aşama 1'in geçip geçmemesi **yazı-turaya** bağlıydı.

Bu bir teori değil, gözlem:

| Deneme | Örnek | Restart | İhlal | Sonuç |
|---|---:|---:|---:|---|
| 3 | 502 | 1 | 0 | Tura — pencere ıskalandı |
| 5 | 3 | 1 | **1** | Yazı — pencereye düşüldü |

Aynı sistem, aynı davranış, zıt ölçüm.

## 3. Yapılan düzeltme

Yalnızca **motorun** sağlık kontrolü, yalnızca **sınırlı** bir pencere için:

| Durum | Eski | Yeni |
|---|---|---|
| `status != running` | ihlal | **ihlal** (değişmedi, ayrı isim: `engine_not_running`) |
| `health = unhealthy` | ihlal | **ihlal** — mazeret yok, pencere yok |
| `health = starting`, pencere **içinde** | ihlal | ihlal değil |
| `health = starting`, pencere **dışında** | ihlal | **ihlal** (`engine_startup_exceeded_grace`) |
| Zaman damgası okunamıyor | — | **ihlal** — fail-closed |
| Panel `starting` | ihlal | **ihlal** (kasıtlı restart edilmiyor) |
| heartbeat / lease / paper state | ihlal | **ihlal** — pencere içinde de aynen işler |

Pencere: `--startup-grace-seconds`, **varsayılan 90 sn**, `summary.json`'a
yazılır (gizli ayar değil). Ölçülen tipik açılış ~15 sn.

## 4. Bu neden bir gevşetme değil

1. **Kapının niyeti korunuyor.** Kapı *kararlı durumda sağlık* ölçer. Ölçüt 6
   zaten geçici bir kesintiyi öngörüp "kendiliğinden sağlığa döner" diyor —
   yani geçici bir sağlıksızlık ölçütün **beklentisidir**.
2. **`starting` "hasta" demek değildir.** Docker'da `starting` = "sağlık
   kontrolü henüz sonuçlanmadı". `unhealthy` ayrı bir durumdur ve **hâlâ
   anında ihlaldir**.
3. **Düzeltme bazı yerlerde kapıyı SIKILAŞTIRIYOR.** Eskiden 90 saniyeyi aşan,
   takılmış bir açılış ile 5 saniyelik normal açılış **aynı** görünüyordu.
   Artık takılmış açılışın kendi ihlal adı var. Eski kod bu arızayı ayırt
   edemiyordu.
4. **Eşiklerin hiçbiri değişmedi.** Süre 72 saat, heartbeat 120 sn, lease 1,
   toplama hatası 0, paper state değişmez — hepsi aynı.

## 5. Karşı argüman (dürüstlük payı)

- Değişiklik **başarısız sonuç görüldükten sonra** yapıldı. Bu yapısal olarak
  şüphelidir ve öyle kalır.
- 3. deneme aynı kodla 0 ihlal üretmişti; yani alet **evrensel olarak** bozuk
  değildi, **kararsızdı**. "Bozuk" demek yerine "kararsız" demek daha doğru.
- 90 saniyelik pencere bir yargı kararıdır. Ölçülen açılış ~15 sn olduğu için
  bol; ama bolluk bir varsayımdır, ölçüm değil.

Bu maddeler düzeltmeyi geçersiz kılmaz, fakat okuyucunun bilmesi gerekir.

## 6. Kanıt

- Testler: [`tests/test_stage1_soak_monitor.py`](../../../tests/test_stage1_soak_monitor.py)
  — `TestControlledRestartStartupWindow`, 7 test, düzeltmenin gevşetme
  olmadığını maddeler hâlinde kanıtlar (`unhealthy` mazur görülmez, takılmış
  açılış yakalanır, diğer kapılar pencere içinde de işler, okunamayan zaman
  fail-closed).
- İhlali doğuran ham örnek:
  `data/stage1_soak/evidence-INVALID-20260806-alet-kusuru/samples.jsonl`
  (3. satır) — silinmedi, kanıt olarak saklandı.

## 7. Bu düzeltmeden ÖNCEKİ koşuların durumu

| Deneme | Durum |
|---|---|
| 1, 2, 3, 4 | Değişmedi. Hiçbiri bu kusur yüzünden başarısız olmadı; hepsi **host** kaynaklı kesintiyle öldü ([`SOAK_DENEME_KAYDI.md`](SOAK_DENEME_KAYDI.md)) |
| 5 | **INVALID** — alet kusuru nedeniyle; sonuç olarak kullanılamaz |

Aşama 1'in `PASS DEĞİL` kararı bu düzeltmeyle **değişmedi**; kapı hâlâ
sağlanmış değil.

---

**AI Koordinatör İmzası:** Claude (Anthropic)
**Belge:** QBP-S1-INSTR-001 / 1.0
