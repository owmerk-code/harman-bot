# Aşama 1 — Paket 1 Güvenlik Notu

**Durum:** `VALIDATED`
**Tarih:** 31 Temmuz 2026
**Mainnet:** `NO-GO`

## Uygulanan değişiklikler

1. `20260731000000_trade_memory_security_lockdown.sql`
   - `trade_memory` FORCE RLS
   - PUBLIC/anon/authenticated tablo yetkilerinin kaldırılması
   - `get_similar_trades` sabit search path
   - Fonksiyon execute yetkisinin service role ile sınırlanması
2. AI pre-trade
   - `AI_TRADE_GATE_ENABLED` yalnız analiz/shadow toplar.
   - `AI_TRADE_GATE_ENFORCEMENT_ENABLED` ayrı, varsayılan false ve env-only.
   - Enforcement açıksa provider/parse hatası, wait, skip, geçersiz/düşük skor
     yeni girişi fail-closed engeller.
3. Autopilot veri tazeliği
   - Aday kanıtı varsayılan en fazla 1200 saniye yaşında olmalıdır.
   - Eksik, timezone'suz, gelecekte veya eski timestamp reddedilir.
   - Grid bandı açılmadan hemen önce Spot REST ticker yeniden okunur.
4. Runtime canlılığı
   - Stale `running=true` kaydı tek başına operasyonel sayılmaz.
   - Panel ve command route taze heartbeat'i zorunlu tutar.

## Doğrulamalar

- Hedefli Python: 39 passed.
- Panel: 11 passed.
- TypeScript: PASS.
- Gerçek DB execution integration: 1 passed.
- Tam Python regresyonu: 681 passed, 1 skipped, 6 warnings
  (258.87 saniye).
- Migration canlı DB:
  - anon function call: reddedildi.
  - service role function call: başarılı.
  - trade_memory RLS/FORCE: true/true.

## Sonuç

Paket 1 kabul edildi. Uygulanan güvenlik değişiklikleri hedefli testlerde,
gerçek yerel DB entegrasyonunda, panel sözleşmelerinde ve tam Python
regresyonunda hata üretmedi.

Bu belge Aşama 1 kapanış raporu veya mainnet onayı değildir. Aşama 1; emir
muhasebesi, reconciliation, risk persistence, fail-closed yaşam döngüsü,
watchdog/restart, Docker/DB/panel sağlık kapıları ve kesintisiz soak kanıtı
tamamlanmadan geçilmiş sayılmaz.
