# Aşama 1 — Üretim Güvenilirliği · Kapanış Raporu

**Tarih:** 7 Ağustos 2026
**Durum:** `KISMİ — SOAK KAPISI BU HOST ÜZERİNDE SAĞLANAMADI`
**Aşama 1 kararı:** `PASS DEĞİL`
**Plan:** [`ANA_UYGULAMA_PLANI.md`](../../../ANA_UYGULAMA_PLANI.md) v2.0

> Bu rapor Aşama 1'i **geçmiş** ilan etmez. Sekiz doğrulama paketi tamamlandı;
> dokuzuncu kapı (72 saat kesintisiz soak) dört denemede de sağlanamadı ve
> sebebi kod değil barındırma ortamıdır. Kapıyı düşürmek yerine durum
> olduğu gibi kayda geçiriliyor.

---

## 1. Neden şimdi kapatılıyor

Aşama 1 açık bırakılmasının bir faydası kalmadı:

Strateji arayışı 5 Ağustos'ta durduruldu
([`PROJE_KAPANIS_KAYDI_20260805.md`](../../PROJE_KAPANIS_KAYDI_20260805.md)) —
14 aile denendi, 14'ü reddedildi, aktif aday yok. Soak testi bir **adayı canlıya
taşıma yolundaki** güvenilirlik kapısıdır. Taşınacak aday olmadığı için kapının
şu an koruduğu bir şey yok.

Dolayısıyla dürüst hareket, kapıyı zorlamak ya da gevşetmek değil, **ne
sağlandığını ve ne sağlanamadığını net yazıp bırakmaktır.**

---

## 2. Tamamlanan — sekiz doğrulama paketi

| # | Paket | Kanıt |
|---|---|---|
| 1 | `trade_memory` FORCE RLS + SECURITY DEFINER lockdown | [`PAKET_1_GUVENLIK_NOTU.md`](PAKET_1_GUVENLIK_NOTU.md) |
| 2 | AI shadow/advisory ile env-only enforcement ayrımı | `PAKET_1` |
| 3 | Autopilot aday yaşı + emir öncesi taze REST fiyatı | `PAKET_1` |
| 4 | Stale heartbeat canlılık kontratı | `PAKET_1` |
| 5 | Gerçek yerel DB execution integration | [`PAKET_2_...NOTU.md`](PAKET_2_MUHASEBE_RISK_PERSISTENCE_NOTU.md) |
| 6 | Emir/fill/fee muhasebesi + risk persistence | `PAKET_2` |
| 7 | Watchdog, Docker build/health, backup/restore | [`PAKET_3_...NOTU.md`](PAKET_3_WATCHDOG_RESTART_DOCKER_NOTU.md) |
| 8 | Kontrollü restart + runtime lease kaybı fault injection | `PAKET_3` |

Bunların hepsi geçerlidir ve depoda testlerle bağlıdır.

---

## 3. Sağlanamayan — 72 saatlik soak

**Kabul ölçütü:** `complete=true`, `passed=true`, `collection_errors=0`,
`violations=0`, en az 1 kontrollü restart geçişi.

**Dört deneme, dördü de kesintiye uğradı:**

| # | Süre | Örnek | İhlal | Nasıl bitti |
|---|---:|---:|---:|---|
| 1 | 4,6 / 72 sa | 553 | 0 | Konteyner kayboldu |
| 2 | 2,4 / 72 sa | — | 0 | Docker kapandı |
| 3 | **4,2 / 72 sa** | **502** | **0** | Konteynerler `exit 137` (SIGKILL) |
| 4 | başlayamadı | — | — | PC kapandı; Docker `AutoStart: false` |

En uzun temiz gözlem: **4,6 saat.** Hedefin **%6,4**'ü.

### Kritik ayrım

**Motor çalıştığı her saniye kusursuzdu.** 3. denemede 502 ölçüm alındı ve
**sıfır ihlal** kaydedildi; paper defteri hash'i taban değerinde kaldı
(`3b963e26…`), kontrollü restart geçişi başarıyla gözlendi.

> Başarısız olan yazılım değil, **altındaki zemindir.**

Bu ayrım önemlidir: soak testi yazılımın 72 saat çalışıp çalışamayacağını
ölçemedi, ama **host'un** çalışamayacağını kesin olarak ölçtü.

---

## 4. Kök neden ve yapılan sertleştirme

7 Ağustos'ta iki somut yapılandırma açığı bulundu ve düzeltildi:

| Bulgu | Neden öldürüyordu | Düzeltme |
|---|---|---|
| `~/.wslconfig` **hiç yoktu** | `autoMemoryReclaim` ve `vmIdleTimeout` varsayılanda; WSL2 uzun süreli konteynerleri geri kazanım sırasında SIGKILL'leyebiliyor — `exit 137` ile birebir uyumlu | `.wslconfig` yazıldı: `memory=8GB`, `processors=6`, `swap=2GB`, `autoMemoryReclaim=disabled`, `vmIdleTimeout=-1` |
| Docker Desktop `AutoStart: false` | PC yeniden başlayınca Docker hiç gelmiyor; `restart: unless-stopped` politikası daemon çalışmadığı için anlamsız | `settings-store.json` → `AutoStart: true` (yedek: `.bak-20260807`) |

Makine profili: 16 GB RAM, 8 mantıksal çekirdek, WSL 2.7.10, Docker 29.6.1.

**Dürüstlük payı:** Bu düzeltmeler bir masaüstünün 72 saat dayanma
**ihtimalini artırır, garanti etmez.** Dört bağımsız kesinti — biri kullanıcı
kaynaklı yeniden başlatma — bunu gösteriyor. Bu yüzden Aşama 1 `PASS`
işaretlenmedi.

---

## 5. Bunun asıl değeri

Soak testi başarısız olmadı; **cevabını verdi.** Sadece beklenen cevabı vermedi:

> Gerçek parayla işlem yapan bir bot 7/24 çalışmak zorundadır. Bu masaüstü
> 72 saat kesintisiz kalamıyor — dolayısıyla Aşama 7 (canlı pilot) bu host
> üzerinde **çalıştırılamaz.**

Bu, testin var oluş sebebiydi ve **tek kuruş riske atılmadan** öğrenildi.
Aksi hâlde bu bilgi ilk canlı pozisyon açıkken, gözetimsiz bir gecede
öğrenilirdi.

---

## 6. Aşama 1'i gerçekten kapatmak için gereken

Tek koşul: **her zaman açık bir host.** Küçük bir VPS (~5-10 USD/ay) yeterli.
Aşama 7 için zaten gerekecektir.

Soak'ı orada başlatmak için gereken her şey depoda ve çalışır durumda:

```
scripts/stage1_soak_monitor.py --duration-hours 72 --interval-seconds 30 \
    --minimum-start-transitions 1
```

Kabul ölçütü **değişmedi ve değiştirilmeyecektir**. Yarım bir koşu tamamlanmış
sayılmaz; `abort ≠ complete` ayrımı izleyicide kodludur.

---

## 7. Doğrulama

```
Python : 871 passed, 1 skipped
Panel  : 13/13, tsc --noEmit temiz
```

Güvenlik denetimi (5 Ağustos, değişmedi):
`MAINNET_*` · `FUTURES_*` (7 kilit) · `AUTOPILOT` (.env **ve** DB) → tümü `false`
`*_admission allowed=true` → **0 satır** · `PAPER_TRADING` → `true`

---

## 8. Karar

| Kalem | Durum |
|---|---|
| Aşama 1 doğrulama paketleri (8/8) | **TAMAM** |
| 72 saatlik soak kapısı | **SAĞLANAMADI** — host kaynaklı |
| Aşama 1 genel | **`PASS` DEĞİL** — kısmi, açıkça kayıtlı |
| Aşama 7 (canlı pilot) | **ENGELLİ** — ayrıca aday da yok |
| Mainnet | `NO-GO` (değişmedi) |

---

**AI Koordinatör İmzası:** Claude (Anthropic)
**Belge:** QBP-S1-CLOSE / 1.0
**İlgili:** [`SOAK_DENEME_KAYDI.md`](SOAK_DENEME_KAYDI.md) ·
[`PROJE_KAPANIS_KAYDI_20260805.md`](../../PROJE_KAPANIS_KAYDI_20260805.md)
**Not:** Bu belge bir kâr garantisi veya yatırım tavsiyesi değildir.
