# Aşama 1 İzole Soak Runbook

Durum: ÇALIŞIYOR — 1 Ağustos 2026 tarihinde temiz pencere başlatıldı; kabul
kararı yalnız en az 72 saatlik kanıt tamamlandıktan sonra verilir.

## Kapsam ve güvenlik

- Yalnız `quant-bot-soak` izole Supabase projesi, `quant-engine-soak` ve `quant-panel-soak` kullanılır.
- Motor `PAPER_TRADING=true`; `AUTOPILOT`, spot trend yürütme, mainnet ve futures kilitleri kapalıdır.
- Tarihsel `quant-bot` veritabanındaki oturum/emir satırları değiştirilmez.
- Runtime env, JWT ve paper state `data/stage1_soak/` altında tutulur ve Git tarafından yok sayılır.

## Kabul ölçütleri

1. Kesintisiz gözlem süresi en az 72 saattir.
2. Motor, panel ve loopback Supabase sağlık kontrolleri başarılıdır.
3. Heartbeat yaşı 120 saniyeyi aşmaz; aktif runtime lease sayısı tam olarak birdir.
4. Girişler kapalıyken aktif oturum, çözümlenmemiş emir veya paper state değişimi oluşmaz.
5. Filled emirlerde eksik komisyon/fill muhasebesi oluşmaz.
6. İzleme sırasında en az bir kontrollü motor restart geçişi görülür ve sistem kendiliğinden sağlığa döner.
7. Toplama hatası veya kabul ihlali varsa sonuç PASS olamaz.

## İzleme

Repo kökünden:

```powershell
.\.venv\Scripts\python.exe scripts\stage1_soak_monitor.py --duration-hours 72 --interval-seconds 30 --minimum-start-transitions 1
```

Kanıtlar `data/stage1_soak/evidence/samples.jsonl` ve `summary.json` dosyalarına
yazılır. Toplama hatası veya kabul ihlali oluşursa kalıcı `alert.json` alarmı
üretilir; sonraki sağlıklı örnek bu alarmı silmez. `summary.json` içindeki
`complete=true` ve `passed=true` birlikte görülmeden Aşama 1 kapatılmaz.

İlk sağlıklı örnek kaydedildikten sonra kontrollü restart:

```powershell
docker restart --timeout 60 quant-engine-soak
```

Restart sonrasında motorun `healthy`, lease sayısının bir ve paper state hash'inin değişmemiş olduğu izleyici tarafından kanıtlanır.

## Durdurma

İzleyici veya bileşenler yalnız hata araştırması ya da soak tamamlanması için durdurulur. İzole stack temizliği, proje kimliği ve hedefler yeniden doğrulanmadan yapılmaz. Aşama raporuna süre, örnek sayısı, ihlaller, restart geçişi ve nihai PASS/FAIL özeti eklenir.
