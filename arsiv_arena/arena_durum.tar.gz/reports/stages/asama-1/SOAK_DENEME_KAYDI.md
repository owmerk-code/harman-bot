# Aşama 1 soak — deneme kaydı

Kabul ölçütü **kesintisiz 72 saattir**. Kesinti olan bir koşu tamamlanmış
sayılmaz ve baştan başlar. Bu dosya denemeleri kayıt altında tutar; yarım
koşuların "72 saat" gibi sunulmasını engeller.

| # | Başlangıç | Süre | Nasıl bitti | Kanıt |
|---|---|---:|---|---|
| 1 | 1 Ağu 05:26 UTC | 4,6 / 72 sa | `quant-engine-soak` konteyneri kayboldu; izleyici 14 saat ölü konteyneri sorgulayıp 1702 anlamsız hata biriktirdi | `evidence-FAILED-20260801-18h/` |
| 2 | 4 Ağu 00:37 UTC | 2,4 / 72 sa | Makine/Docker kapandı (~03:00 UTC). Ölçümler o ana kadar **temizdi**: 0 hata, 0 ihlal, restart geçişi kaydedilmişti | `evidence-FAILED-20260804-2.4h/` |
| 3 | 4 Ağu 19:25 UTC | 4,2 / 72 sa | Konteynerler `exit 137` (SIGKILL) ile öldürüldü. Ölçümler o ana kadar **temizdi**: 502 örnek, 0 ihlal, restart geçişi kaydedilmişti. İzleyici 5 ardışık hatada kendini durdurdu | `evidence-FAILED-20260804-4.2h/` |
| 4 | — | — | Başlatılamadı: PC kapandı, Docker geri gelmedi (`AutoStart: false`) | — |

**Sonuç: dört deneme, dördü de kesintiye uğradı. Aşama 1 bu host üzerinde
kapatılamadı.** Bkz. [`ASAMA_1_RAPORU.md`](ASAMA_1_RAPORU.md).

## Kök neden

Dört başarısızlığın hiçbiri **koddan** kaynaklanmadı; hepsi **barındırma
ortamındandı**. Motor çalıştığı her saniye temizdi:

| Deneme | Örnek | İhlal | Toplama hatası |
|---|---:|---:|---:|
| 2 | — | 0 | 0 |
| 3 | 502 | **0** | 5 (yalnızca stack öldükten sonra) |

3. denemede `exit 137` = SIGKILL. Sertleştirme sırasında iki somut sebep
bulundu ve düzeltildi:

| Bulgu | Durum | Düzeltme |
|---|---|---|
| `~/.wslconfig` **yoktu** → `autoMemoryReclaim` ve `vmIdleTimeout` varsayılan; WSL2 uzun süreli konteynerleri öldürebiliyor | 7 Ağu düzeltildi | `.wslconfig` yazıldı: bellek tavanı 8 GB, `autoMemoryReclaim=disabled`, `vmIdleTimeout=-1` |
| Docker Desktop `AutoStart: false` → PC yeniden başlayınca Docker hiç gelmiyor | 7 Ağu düzeltildi | `settings-store.json` → `AutoStart: true` (yedek: `.bak-20260807`) |

> **Bu kaydın önceki sürümündeki hata:** "Docker Desktop açılışta başlıyor,
> yani yeniden başlatmada konteynerler geri gelir" yazıyordu. **Yanlıştı** —
> `AutoStart` `false`'tu ve 4. deneme tam olarak bu yüzden hiç başlayamadı.
> Doğrulanmadan yazılmış bir varsayımdı; kayda geçiriliyor.

## Bunun asıl anlamı

Bu bir test aksiliği değil, **gerçek bir işletim gereksiniminin erken ortaya
çıkmasıdır**:

> Gerçek parayla işlem yapan bir bot 7/24 çalışmak zorundadır. Host 3 gün
> ayakta kalamıyorsa Aşama 7 (canlı pilot) da çalıştırılamaz.

Soak testi tam olarak bunu ölçmek için vardır ve cevabı verdi. Para riske
atılmadan öğrenildi.

## Denemeler boyunca eklenen kalıcı iyileştirmeler

Dördü de başarısız oldu, ama her biri gerçek bir kusur ortaya çıkardı ve
düzeltmeler depoda kaldı:

| Kaynak | İyileştirme |
|---|---|
| Deneme 1 | İzleyici artık 5 ardışık toplama hatasında **erken durur**. 1702 anlamsız örnek yerine 5. Ölçülen fark: 14 saat boşa gözlem → 2,5 dakika. |
| Deneme 1 | `abort ≠ complete` ayrımı: yarım koşu artık "tamamlandı" olarak raporlanamaz |
| Deneme 2 | `scripts/keep_awake.ps1` — Windows uykusu engellenir |
| Deneme 2 | İzleyici oturumdan bağımsız süreç olarak çalışır |
| Deneme 3 | `~/.wslconfig` — WSL2 bellek/idle kaynaklı SIGKILL yolları kapatıldı |
| Deneme 4 | Docker Desktop `AutoStart: true` |

## Yeniden denenecekse: koşu sürerken YAPILMAMASI gerekenler

1. Bilgisayarı kapatmak / yeniden başlatmak
2. Oturumu kapatmak (log off)
3. Docker Desktop'ı kapatmak
4. `keep_awake.ps1` süreçini sonlandırmak
5. `quant-*-soak` konteynerlerini durdurmak

Bilgisayarı kullanmaya devam edebilirsiniz — yalnızca açık kalması gerekiyor.

## Kalıcı çözüm

Her zaman açık bir host (küçük bir VPS, ~5-10 USD/ay). Aşama 7 için zaten
gerekecektir.

Yukarıdaki sertleştirmeler bir masaüstünün 72 saat dayanma **ihtimalini
artırır, garanti etmez** — dört bağımsız kesinti bunu gösterdi. Kapıyı
düşürmek sorunu çözmez, gizler; bu yüzden Aşama 1 geçmiş sayılmadı.
