# AI laboratuvarı — kurulum ve kullanım

**Ne yapar:** Aynı görevi tanımlı TÜM modellerde aynı girdiyle çalıştırır, sonucu `ai_calls`
tablosuna yazar ve modelleri karşılaştırır. **Gölge mod:** hiçbir sonuç emir, risk veya işlem
büyüklüğüne bağlanmaz (`decision` her zaman boş; veritabanı kısıtı geçersiz cevabın karar
taşımasını da engeller).

| Görev | Ne zaman | Çıktı |
|---|---|---|
| `news_review` | Aktif haber risk kaydı varsa, en fazla 6 saatte bir | Her risk kaydı için: gerçekten o coini ilgilendiriyor mu, önerilen eylem (izle/küçült/engelle), Türkçe gerekçe |
| `daily_comment` | Günde bir kez | Sade Türkçe günlük özet, en fazla 3 dikkat maddesi |

## Açma (`.env`)
```
AI_LAB_ENABLED=true
AI_LAB_DAILY_USD_LIMIT=0.50
ANTHROPIC_API_KEY=...            # ücretli: Claude
OPENROUTER_API_KEY=...           # ücretsiz modeller için (OpenRouter hesabı)
AI_LAB_CANDIDATES=[{"id":"opus5","provider":"anthropic","model":"claude-opus-5"},{"id":"sonnet5","provider":"anthropic","model":"claude-sonnet-5"},{"id":"haiku45","provider":"anthropic","model":"claude-haiku-4-5"},{"id":"free1","provider":"openrouter","model":"<saglayici>/<model>:free"}]
```
- Anahtarı olmayan aday otomatik atlanır; hiç aday yoksa hiçbir çağrı yapılmaz.
- Claude fiyatları koda gömülüdür (Opus 5 $5/$25, Sonnet 5 $2/$10, Haiku 4.5 $1/$5 / 1M token).
  Diğer ücretli modeller için adaya `input_usd_per_mtok` ve `output_usd_per_mtok` ekleyin;
  `:free` uzantılı ve yerel (ollama) modeller 0 kabul edilir.
- Günlük harcama `AI_LAB_DAILY_USD_LIMIT`e ulaşınca yeni çağrı yapılmaz (`skipped` kaydı).
- Claude Opus 5 isteği reddederse sunucu tarafında Opus 4.8'e otomatik geçer.

## Ücretsiz sağlayıcılar — gerçek deneme sonucu (14 Eylül 2026)
| Sağlayıcı | `.env` | Durum |
|---|---|---|
| NVIDIA | `NVIDIA_API_KEY` | Çalışıyor. `openai/gpt-oss-20b` geçerli JSON, ~15 sn (en iyi aday); `google/gemma-4-31b-it` geçerli ama ~80 sn. nemotron-3-super 503, deepseek-v4-flash / kimi-k3 / glm-5.3-flash zaman aşımı |
| OpenCode (uygulama) | `opencode` CLI kurulu ve giriş yapılmış olmalı; sağlayıcı `opencode_cli` | Ücretsiz Zen modelleri doğrudan API'den değil **resmi OpenCode uygulaması** üzerinden çalışır (API: HTTP 400 "free tier can only be used in OpenCode"). Lab uygulamayı **tüm araçları kapalı** bir ajanla (`permission: {"*":"deny"}`), boş geçici klasörde çağırır; komut deneme testi reddedildi, dosya oluşmadı. big-pickle ~5–9 sn; nemotron-3.5-lightning-free ~128 sn |
| Groq | `GROQ_API_KEY` (adres varsayılan) | Çalışıyor, çok hızlı (0,6–2,2 sn). gpt-oss-20b, gpt-oss-120b, qwen3.8-27b iki görevde de geçerli JSON. Bilinen yanlış alarmı (başka projenin köprü hack'i) yalnız qwen3.8-27b doğru ayırdı. Ücretsiz katman: ~30 istek/dk, gpt-oss 1.000 istek/gün |
| OpenRouter | `OPENROUTER_API_KEY` | `:free` modeller var; anahtar yok. Gizlilik ayarları nedeniyle birçoğu reddedebilir (aşağıya bakın) |

Örnek adaylar: `{"id":"groq-oss20","provider":"groq","model":"openai/gpt-oss-20b","input_usd_per_mtok":0,"output_usd_per_mtok":0}`,
`{"id":"oc-pickle","provider":"opencode_cli","model":"big-pickle"}` (`-free` ile biten ve big-pickle modelleri otomatik 0 USD).
OpenCode ücretsiz modellerinde gönderilen verinin model geliştirmede kullanılabileceğini varsayın (gönderilen: kasa/işlem özeti ve haber başlıkları; anahtar yok).
(ücretsiz sağlayıcılarda fiyatı 0 yazın; yazılmazsa maliyet "bilinmiyor" kaydedilir).
Hata kayıtlarında sağlayıcının kısa mesajı da tutulur (anahtar maskelenir).

## Güçlü modeller — kendi aboneliğinizle (Claude Max, ChatGPT Plus)
| Sağlayıcı | Nasıl | Güvenlik |
|---|---|---|
| `claude_cli` | Resmi Claude Code CLI (`claude -p`), hesabınızla giriş yapılmış | `--tools ""` (hiç araç yok), MCP/kullanıcı ayarları yüklenmez, oturum kaydedilmez |
| `codex_cli` | Resmi Codex CLI (`codex exec`), ChatGPT hesabıyla giriş yapılmış | salt-okunur kum havuzu + komut/tarayıcı/bilgisayar kontrolü/eklenti özellikleri kapalı (komut deneme testi reddedildi) |

- Görev metni stdin'den gider; boş geçici klasörde çalışır. `ANTHROPIC_API_KEY`/`OPENAI_API_KEY` alt sürece verilmez
  (verilirse CLI aboneliği bırakıp ücretli API'ye geçer).
- **Limit koruması:** `max_calls_per_day` (abonelik modellerinde yazılmazsa varsayılan 3/gün). Hatalı çağrılar da sayılır;
  sayım yapılamazsa çağrı yapılmaz. Etkin sınırlar: Opus 5, Fable 5.1, GPT-6 Astra → 2/gün; GPT-5.6 Sol → 3/gün.
- Fable 5.1 için Claude Code ≥ 2.1.251, GPT-6 Astra için güncel Codex gerekir (14 Eylül'de 2.1.270 / 0.154.0'a güncellendi).
- Kurallar: resmi CLI'ı kendi bilgisayarınızda kişisel kullanım; giriş jetonu başka programa kopyalanmaz.

14 Eylül gerçek görev testi (yanlış alarm örneği + gerçek günlük rapor): Opus 5 (12/17 sn), Fable 5.1 (11/13 sn),
GPT-6 Astra (9/11 sn), GPT-5.6 Sol (6/6 sn) — **dördü de iki görevde geçerli**, yanlış alarmı doğru ayırdı ve günlük
yorumda rakamları doğru yazdı (207,15 USDT ≈ 10.053 TL). Codex her çağrıda ~11–13 bin token taban maliyeti taşır.

## Etkin kurulum (14 Eylül 2026'dan itibaren)
`.env`: `AI_LAB_ENABLED=true`, zaman aşımı 60 sn, `OPENCODE_CLI_PATH` gerçek `opencode.exe` yolu. Adaylar (hepsi 0 USD):
`groq-qwen38` (qwen/qwen3.8-27b), `groq-oss120` (openai/gpt-oss-120b), `oc-pickle` (OpenCode big-pickle),
`nv-oss20` (NVIDIA openai/gpt-oss-20b). Laboratuvar otomatik döngüde (`ana_kasa_otomatik.ps1` adım 5b) çalışır;
en az 2 hafta sonra `ai_model_karsilastirma.py --days 14` ile karşılaştırılır. Günlük yorumlarda
**rakam uydurma** (ör. yanlış bakiye) ayrıca kontrol edilmelidir.

## Gizlilik
`AI_ADVISOR_DATA_COLLECTION=deny` ve `AI_ADVISOR_ZDR=true` (varsayılan) OpenRouter'a "veriyi saklamayan
sağlayıcıları kullan" der. **Birçok ücretsiz model bu koşulu karşılamaz ve istek reddedilebilir**
(kayıtta `error`). Ücretsiz modeli yine de denemek isterseniz bu iki ayarı bilerek gevşetmeniz gerekir;
gönderilen veri kasa/işlem özetidir (anahtar veya cüzdan bilgisi gönderilmez).

## Karşılaştırma
```
.venv\Scripts\python.exe scripts\ai_model_karsilastirma.py --days 14
```
Model başına: çağrı sayısı, geçerli cevap %, ortanca süre, toplam maliyet, haber denetiminde diğer
modellerle ikili uyum %. Karar için en az 2 hafta veri önerilir; ardından seçilen model gerçek freni
yalnız **küçültme/engelleme** yönünde ve ayrı bir onayla devralabilir.
