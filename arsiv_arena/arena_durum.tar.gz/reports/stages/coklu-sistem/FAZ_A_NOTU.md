# Faz A — Güvenlik Temizliği: Kapanış Notu

**Plan:** `ANA_UYGULAMA_PLANI.md` v3.0 §9
**Tarih:** 13 Eylül 2026
**Git dalı:** `feature/coklu-sistem` (commit edilmedi)
**Karar:** `PASS` — tüm Faz A maddeleri tamamlandı, testler geçiyor
**Canlı karar:** `NO-GO — MAINNET KAPALI` (değişmedi)

---

## 1. Kapsam ve sonuç

| # | Madde | Önceki davranış | Yeni davranış | Kanıt |
|---|---|---|---|---|
| 1 | Kapanışta tasfiye | Düzenli kapanış tüm trend pozisyonlarını piyasadan satıyordu; ev PC'si her gece kapandığı için her gece istemsiz satış | Pozisyonlar korunur; eski davranış yalnız env-only `SHUTDOWN_FLATTEN_TREND_POSITIONS=true` ile. Acil tasfiye yolu değişmedi | `test_shutdown_keeps_trend_positions_by_default`, `test_shutdown_flatten_is_explicit_opt_in` |
| 2 | Çalışma modu panelden | `PAPER_TRADING` DB/panel beyaz listesindeydi; panel satırı motoru gerçek emir moduna geçirebilirdi | Yalnız `.env`; panel formu ve komut beyaz listesinden de çıkarıldı | `test_runtime_mode_and_shutdown_flatten_are_not_panel_settable` |
| 3 | AI skor artırma | `AUTOPILOT_AI_SCORING` AI'nın aday skorunu yükseltmesine izin veriyordu (§3 ihlali) | Kanca ve modül silindi | `test_removed_ai_score_and_portfolio_hooks_stay_removed` |
| 4 | Trend yürütme oturumu | `bot_sessions` insert'i şemaya aykırıydı (`name` yok, `status='active'`, olmayan `symbol` kolonu); ilk gerçek girişte devre kesici açılırdı. Sahte DB kısıtları zorlamadığı için testler geçiyordu | Şemaya uygun insert (`running`, `name`, `started_at`); sahte DB gerçek kısıtları zorluyor | Eski kodla 9 test kırılıyor, yeni kodla `test_trend_execution_manager.py` geçiyor |
| 5 | Ölü kod | `engine/hybrid/` hiç başlatılmıyordu; `autopilot/portfolio.py` tek adayla her zaman ağırlık 1,0 veriyordu | Silindi; `HYBRID_*`, `AUTOPILOT_AI_SCORING`, `AUTOPILOT_PORTFOLIO_OPT` ayarları kaldırıldı | Aynı regresyon testi |
| 6 | Tek seferlik bildirimler | Kâr kilidi, rejim değişimi, risk skoru ve trend acil durum anahtarları sabitti; kalıcı tekilleştirme ikinci olayı sessizce yutuyordu | UTC gün/saat kovası (risk skoru 10'luk bant) | `test_notification_event_keys.py` |
| 7 | Haber yanlış pozitifleri | Sembolsüz olumsuz haber tüm sembollere uygulanıyordu; kriptoyla ilgisiz SEC bülteni ~0,64 skorla tüm girişleri 2 saat yarıya indiriyordu | Kripto bağlamı yoksa risk üretmez (denetim için kaydedilir); `category` ve `received_at` eklendi | 4 yeni test, `test_news_risk.py` |

## 2. Doğrulama

```
Python : 846 passed, 1 skipped, 6 warnings (310 s)
         — silinen modüllerin 44 testi kaldırıldı, 7 regresyon testi eklendi
Panel  : 13/13 (npm test), tsc --noEmit temiz
```

Faz A boyunca her madde sonrası tam Python koşusu yapıldı (883 → 883 → 840 →
842 → 846); hiçbirinde başarısız test yok. Panel yalnız madde 2'de değişti ve
o değişiklik sonrası test + tip kontrolü koşuldu.

## 3. Bilinçli olarak Faz A dışında bırakılanlar

| Konu | Neden şimdi değil | Hedef faz |
|---|---|---|
| Grid yokken günlük kayıp / drawdown değerlendirilmiyor (`monitor()` erken dönüş) | NAV hesap geneli; bot pozisyonu yokken koşulsuz değerlendirme, manuel varlıkların değer kaybını bot kaybı sayıp tasfiye tetikleyebilir. Doğru çözüm bölüm kapsamlı risk defteri | C |
| Futures stop emri python-binance 1.0.37 ile algo uç noktasına gidiyor (idempotensi kırık, stoplar uzlaştırmada görünmez) | Futures henüz hiçbir çalışma yolunda başlatılmıyor; düzeltme futures yöneticisiyle birlikte testnet'te kanıtlanmalı | F |
| `trade_memory` çıkışları hiç yazılmıyor, AI dersleri prompta geri besleniyor | İşlem günlüğü şemasıyla birlikte yeniden yazılacak | B + C |
| OpenRouter şeması tüm AI çağrılarına aynı gönderiliyor (gate her zaman "wait") | AI kapısı şema doğrulamalı olarak yeniden yazılacak | C |
| Başlangıçta DB lease'in koşulsuz `force_release` edilmesi | Tek host (ev PC'si) için pratik etkisi yok; VPS/çok host geçişinde ele alınmalı | I öncesi |
| Panelde uydurma "korelasyon" ve "risk skoru geçmişi" grafikleri | Görünürlük fazında bölüm görünümleriyle birlikte | H |

## 4. Açık riskler

- Değişiklikler commit edilmedi; çalışma dalı yerel.
- DB'de eski `PAPER_TRADING`, `HYBRID_*`, `AUTOPILOT_AI_SCORING` satırları kalmış
  olabilir; artık uygulanmazlar ama panelde okunmaya devam edebilirler. Faz B
  migration'ında temizlenecek.
- Haber bağlam listesi anahtar kelime tabanlıdır; kripto terimi içermeyen ama
  kriptoyu etkileyen makro haberler (ör. bir ülkenin ani sermaye kontrolü)
  artık "tüm semboller" riski üretmez. Bu bilinçli bir tercihtir: yanlış pozitif
  her girişi küçültüyordu.

---

AI Koordinatör İmzası : Claude (Anthropic)
Belge                  : QBP-MS-FAZ-A / 1.0
UTC zaman              : 2026-09-13
Kaynak commit          : 1af6069 + commit edilmemiş değişiklikler (`feature/coklu-sistem`)
Karar                  : PASS
İnsan onayı            : Kapsam onaylı (13 Eylül 2026); faz notu incelemesi BEKLENİYOR
