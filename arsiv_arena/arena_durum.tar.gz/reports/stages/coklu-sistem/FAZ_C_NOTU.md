# Faz C — Yönetici: Kapanış Notu

**Plan:** `ANA_UYGULAMA_PLANI.md` v3.0 §9
**Tarih:** 13 Eylül 2026
**Paket:** `engine/supervisor/`
**Migration'lar:** `20260913010000_trade_journal_decision_key.sql`, `20260913020000_sleeve_risk_state_source_and_flows.sql`, `20260913030000_sleeve_risk_state_flow_watermark.sql`
**Karar:** `PASS` (üç bağımsız inceleme turu sonrası)
**Canlı karar:** `NO-GO — MAINNET KAPALI` (değişmedi)

---

## 1. Ne yapıldı

Üç bölümün üstünde duran, emir göndermeyen, deterministik yönetici katmanı:

| Modül | Görev |
|---|---|
| `models.py` | Bölüm, emir niyeti, pozisyon, kapı kararı modelleri; niyet doğrulaması |
| `limits.py` | Global ve bölüm risk sınırları; yalnız sıkılaştırılabilir (`tightened()` gevşetmeyi reddeder) |
| `scoped_risk.py` | Günlük/haftalık kayıp duraklatması (ertesi gün/hafta kendiliğinden açılır), maksimum drawdown devre kesicisi (yalnız insan sıfırlar), ardışık kayıp duraklatması, sermaye akışı ayarlaması |
| `exposure.py` | Hesap geneli brüt kaldıraç ve baz varlık başına net yön |
| `gate.py` | Tek ön-işlem kapısı: niyet geçerliliği, uzlaştırma, veri tazeliği, açılış durumu, risk tazeliği, bölüm açık/kapalı, kaldıraç, sermaye kapasitesi, futures koruyucu stop (yönü ve likidasyon öncesi mesafe), risk kapsamları, maruziyet, haber (sembol eşleşmeli), AI (yalnız küçültür/veto eder) |
| `catchup.py` | Kapanma sonrası kaçırılan kapanmış barların planı; yalnız son bar emre dönüşebilir |
| `journal_math.py` | Brüt/net PnL, yön bağımlı kayma, süreç-önce sonuç sınıfı |
| `repository.py` | Supabase erişimi: sayfalı defter okuma, iyimser eşzamanlı risk yazımı, idempotent günlük ve checkpoint |
| `ledger.py` | Bölüm sanal sermaye defteri (yalnız eklemeli, idempotent) |
| `journal.py` | Karar → açılış → kapanış; borsa için 32 karakterlik emir kimliği |
| `supervisor.py` | Risk döngüsü, açılış kurtarma, bar telafisi, niyet inceleme, sermaye akışları, kapanış |

Eski çalışma yolundaki "grid yokken günlük kayıp değerlendirilmiyor" hatası bu katmanda
yapısal olarak yoktur: risk, aktif strateji sayısından bağımsız her döngüde tüm kapsamlarda
değerlendirilir.

## 2. Plan kabul kapısı

> Restart ve 8 saatlik kapanma senaryoları testle kanıtlanır; belirsizlikte yeni işlem yok.

| Senaryo | Kanıt |
|---|---|
| PC 02:01–09:30 kapalı: 7 kaçırılmış bar, 6'sı "kaçırıldı" olarak günlüğe, yalnız 08:00 emre dönüşür | `test_eight_hour_shutdown_restart_is_idempotent_and_acts_only_on_latest_bar` |
| Son bar işlenmeden çökme → ikinci açılış çift kayıt üretmez; üçüncü açılışta iş yok | Aynı test |
| Kararı verilmiş bar sonraki açılışta ayrıca "kaçırıldı" sayılmaz | `test_bar_reviewed_before_a_crash_is_not_also_recorded_as_missed` |
| Kayıtlı "planlandı" kararı, güncel kontroller başarısızsa tekrar onaylanmaz (çift emir yok) | `test_replayed_planned_decision_is_denied_when_current_checks_fail` |
| Uzlaştırma belirsiz → azaltma dahil hiçbir emir yok | `test_unclean_reconciliation_blocks_entries_and_reductions` |
| Eksik stop / özsermaye yok / sermaye tahsis edilmemiş → yeni giriş yok, korumasız pozisyon kapatılabilir | `test_other_startup_problems_block_entries_but_allow_reductions` |
| Kapanışta çökme → defter bir kez, kayıp eksik sayılmaz | `test_crash_between_ledger_posting_and_close_is_retry_safe` |
| Transfer ortasında çökme → yeniden deneme eksik adımı tamamlar, çift uygulamaz | `test_transfer_is_idempotent_and_completes_after_a_crash` |

## 3. Bağımsız inceleme turları

| Tur | Bulgu | Durum |
|---|---|---|
| 1 | 4 yüksek, 9 orta, 5 düşük | Hepsi düzeltildi |
| 2 (doğrulama) | 17 düzeltmeden 14 tam, 3 kısmi; 1 kritik + 2 yüksek + 5 orta yeni bulgu | Hepsi düzeltildi |
| 3 (son kontrol) | 8 düzeltmeden 7 tam, 1 kısmi (sermaye akışı çökme kurtarması); 2 yüksek + 2 orta + 3 düşük yeni bulgu | Yüksek ve orta olanlar düzeltildi; düşükler aşağıda |

Önemli olanlar:

- **Haber seviyeleri:** gerçek haber kapısının `allow`/`unavailable` seviyeleri günlüğü düşürüyordu. Artık eşleniyor; üst akış hata metni kopyalanmıyor.
- **Çift emir riski:** tekrar incelemede eski karar körü körüne onaylanıyordu. Artık kayıtlı karar + güncel kontrollerin tamamı gerekiyor ve tutar ikisinin küçüğü.
- **Kapanış çökmesi:** kâr/zarar deftere hiç geçmeyebiliyordu. Sıra değişti: defter → risk sayacı → durum.
- **1.000 satır sınırı:** defter sessizce kesiliyordu. Artık sayfalı okunuyor, toplam sayı doğrulanıyor, eksikse duruyor.
- **Operatör müdahalesi ezilebiliyordu:** `updated_at` DB tetikleyicisiyle her güncellemede yenileniyor, yazım koşullu.
- **Kaynak ayrımı:** paper/testnet/mainnet aynı risk satırını paylaşıyordu. Artık `(scope, source)` anahtarlı.
- **Sermaye akışları:** oranla ölçekleniyor, anahtarla bir kez uygulanıyor, akıştan sonra kurulan referansı kaydırmıyor.
- **Haber radarı kapalıyken** "olay yok" sanılmıyor; dışarıdan açılan devre kesici bir sonraki incelemede etkili.
- **Sermaye akışı çökme kurtarması (3. tur):** tahsis/transfer ayarlamaları sınırlı anahtar listesi yerine
  bölüm başına "uygulanmış en büyük defter satırı" filigranıyla izleniyor. Akış zamanı defter satırının
  kendi `occurred_at` değeri; açılışta risk değerlendirmesinden önce yansımamış akışlar uygulanıyor.
  Böylece yazılmış ama yansımamış bir transfer sahte drawdown ile devre kesiciyi açamıyor, 200+ transferden
  sonra ilk tahsis yeniden uygulanamıyor ve çıkış kaydı yazılmış bir transferin yeniden denemesi sonradan
  oluşan kayıplarla kilitlenmiyor.

## 4. Doğrulama

```
Python (tam koşu)        : 1015 passed, 5 skipped
Yönetici birim testleri  : tests/test_supervisor_*.py
Canlı Supabase testleri  : 5/5 (QUANT_RUN_DB_TESTS=1; geride kayıt yok)
Şema kural doğrulaması   : 33/33 (scripts/verify_multi_sleeve_schema.sql, geri alındı)
Yerel DB                 : 49 migration, portlar yalnız 127.0.0.1
```

## 5. Faz D'ye devredilen ve bilinçli sınırlar

- **Bağlantı yok:** yönetici henüz `engine/core/bot.py` çalışma akışına bağlı değil. Bölüm yöneticileri Faz D–F'de onu kullanacak.
- **Emir gönderme sözleşmesi:** çağıran emri `ReviewResult.client_order_id` ile gönderir ve göndermeden önce bu kimlikle borsada mevcut emri sorgular (Binance kimliği yalnız açık emirler arasında tekil sayar).
- **Haber:** `NewsRiskGate.check(symbol, automatic=True)` ile çağrılmalı.
- **Hesaba mevduat/çekim:** `record_external_flow` ile para borsaya yansımadan önce kaydedilmeli. Çekim kayıttan önce değerlendirilirse devre kesiciyi açabilir.
- **Kapanış çökmesi penceresi:** kayıp iki kez sayılabilir (sıkı yön); hiç sayılmaması mümkün değil.
- **Stratejiler hedef durum üretmeli:** kaçırılan barların niyetleri yürütülmez; son bar hedefi hâlâ geçerliyse o bar için yeniden üretilir.
- **Emir gönderme ile "açıldı" işareti arasında çökme (3. tur, orta):** satır `planned` kalır ve aynı bar
  yeniden onaylanabilir. Faz D yürütücüsü göndermeden önce `client_order_id` ile borsayı sorgulamayı
  zorunlu yapmalı (Binance kimliği dolmuş emirleri tekil saymaz).
- **Transfer yeniden denemesinde akış öncesi özsermaye** yeniden deneme anındaki gerçekleşmemiş PnL ile
  yaklaşık hesaplanır; defter satırının kendi zamanı ve filigran doğrudur.
- **Dış mevduat/çekim:** akış öncesi özsermaye çağırandan gelir; yeniden denemede ilk çağrının değeri geçerlidir.
- **Temel migration'ın yeniden koşulması** (tohum `ON CONFLICT (scope)`) kaynak sütunu sonrası çalışmaz;
  migration'lar yalnız bir kez uygulanır, geri alma betiği hepsini birlikte unutturur.

---

AI Koordinatör İmzası : Claude (Anthropic)
Belge                  : QBP-MS-FAZ-C / 1.0
UTC zaman              : 2026-09-13
Kaynak commit          : 10a623a + doğrulama düzeltmeleri (Faz C kapanış commit'i)
Karar                  : PASS
İnsan onayı            : Kapsam onaylı (13 Eylül 2026); faz notu incelemesi BEKLENİYOR
