# Yedek ve geri yükleme kılavuzu

## Otomatik yedek
`scripts/ana_kasa_otomatik.ps1` her gün ilk başarılı döngüden sonra `backups\daily\YYYY-MM-DD\` altına yazar:
`trade_journal`, `sleeve_ledger`, `bar_checkpoints`, `sleeve_risk_state`, `sleeve_equity_snapshots`, `sleeves`
tabloları (JSON), sanal cüzdan (`multi_sleeve_paper.json`) ve gölge carry durumu. Son 14 gün tutulur.
Klasörde `DONE` dosyası yoksa yedek tamamlanmamıştır. Yedek alınamazsa Telegram uyarısı gelir.
Yedekler yalnız bu bilgisayarda durur (`.gitignore`).

## Ne zaman geri yüklenir
- Docker veri alanı silindi/bozuldu ve veritabanı boş açıldı.
- Tutarlılık uyarısı ("Cüzdan ile işlem defteri UYUŞMUYOR") geldi ve nedeni bozuk kayıt.
Şüphede önce **yalnız gösterim** çalıştırın.

## Adımlar
1. Yalnız göster (hiçbir şey değişmez):
   `powershell -ExecutionPolicy Bypass -File scripts\geri_yukle_yedek.ps1 -Date 2026-09-14`
2. Geri yükle:
   `powershell -ExecutionPolicy Bypass -File scripts\geri_yukle_yedek.ps1 -Date 2026-09-14 -Apply -Onay EVET-GERI-YUKLE`

Betik: zamanlanmış görevi durdurur, otonom çalıştırıcının kilidini alır, mevcut durumu
`backups\pre_restore_<zaman>` altına yedekler, tüm veritabanı değişikliğini tek işlemde yapar,
yalnız-eklemeli korumasını aynı işlemde geri açar, satır sayılarını ve korumayı doğrular, görevi yeniden açar.
Herhangi bir hata tüm veritabanı değişikliğini geri alır.

## Sınırlar
- Yedek tarihinden sonraki kayıtlar kaybolur; sistem açılışta kaçırılan barları telafi eder
  ama o aradaki sanal işlemler yeniden oluşmaz (gerçek emir yoktur).
- Veritabanı şeması (migration'lar) yedeğe dahil değildir; önce `baslat_guvenli_supabase.bat`.
