# Faz B — Şema: Kapanış Notu

**Plan:** `ANA_UYGULAMA_PLANI.md` v3.0 §9
**Tarih:** 13 Eylül 2026
**Migration:** `supabase/migrations/20260913000000_multi_sleeve_foundation.sql`
**Karar:** `PASS`
**Canlı karar:** `NO-GO — MAINNET KAPALI` (değişmedi)

---

## 1. Ne eklendi

| Nesne | Amaç | Korunan kural |
|---|---|---|
| `sleeves` | Üç bölüm + `legacy` | Hedef ağırlık toplamı ≤ %100 (ertelenmiş kısıt tetikleyicisi); kaldıraç yalnız futures'ta ve en fazla 3x. Tohum: core %50, spot_active %30, futures %20 (3x), legacy %0; hepsi `enabled=false` |
| `sleeve_id` kolonu | `bot_sessions`, `grid_orders`, `balances_snapshot`, `futures_order_intents`, `futures_position_snapshots`, `trade_memory` | `NOT NULL DEFAULT 'legacy'` + FK; mevcut çalışma yolu değişmeden çalışır |
| `sleeve_risk_state` | Global + bölüm başına devre kesici, giriş duraklatma, günlük/haftalık baz, zirve özsermaye | Tetiklenmiş kapsam gerekçe ve zaman ister; eski tekil `risk_state` legacy yol için aynen durur |
| `sleeve_ledger` | Bölüm sanal sermaye defteri | Yalnız eklemeli (UPDATE/DELETE/TRUNCATE reddedilir); idempotensi anahtarı tekil; komisyon her zaman borç |
| `bar_checkpoints` | Kapanma sonrası telafi için işlenen son bar | Geri sarılamaz (aynı barın iki kez işlenip çift emir üretmesini engeller) |
| `trade_journal` | İşlem öncesi gerekçe + sonrası ayrıştırma | Spot yalnız kaldıraçsız long; kaldıraç ≤ 3; `net = brüt − komisyon + fonlama` kimliği DB kısıtı; kapalı kayıt eksiksiz olmalı |
| `ai_calls` | AI çağrı denetim kaydı | Yalnız eklemeli; geçersiz/zaman aşımlı çıktı karar taşıyamaz; karar yalnız `pre_trade`; boyut çarpanı ≤ 1 |
| `hypotheses` | AI'nın işlem sonrası önerileri | Kabul yalnız `decided_by = 'human'` (AI veya sistem kabul edemez) |

Tüm yeni tablolar `FORCE ROW LEVEL SECURITY`, yalnız `service_role`; tarayıcı rollerine
hiçbir yetki verilmedi. Faz A'da kaldırılan ayarların eski DB satırları silindi.

## 2. Doğrulama

| Kontrol | Sonuç |
|---|---|
| Statik sözleşme testi (`tests/test_migration_multi_sleeve.py`) | 8/8 |
| SQL deneme koşusu (işlem içinde, geri alındı) | Hatasız; 4 bölüm, ağırlık toplamı 1,0000 |
| Canlı kural doğrulaması (`scripts/verify_multi_sleeve_schema.sql`) — her kural bilerek ihlal edildi, tümü geri alındı | **30/30 PASS** |
| Geri alma betiği (`scripts/rollback_multi_sleeve_foundation.sql`) işlem içinde denendi | Tüm nesneler ve migration kaydı silindi; geri alınınca hepsi yerinde |
| Mevcut veri | 277 oturum, 2.223 emir değişmedi; tümü `legacy` bölümünde |
| Canlı DB entegrasyon testi (`QUANT_RUN_DB_TESTS=1`) | 1/1 — motor emir/oturum yazıyor, test satırları temizlendi |
| Python tam koşu | 854 passed, 1 skipped |

## 3. Bu fazda bulunan ve düzeltilen iki ek sorun

1. **Yerel Supabase portları LAN'a açıktı.** Supabase CLI 2.117 ile yeniden
   başlatılan yığın `0.0.0.0:8421/8422` üzerinde dinliyordu (varsayılan
   `postgres/postgres` şifresiyle). Güvenlik betiği Kong'un artık host mount
   kullanmaması nedeniyle "mount envanteri boş" diyerek fail-closed durdu.
   `scripts/secure_supabase_local.ps1` güncellendi: veritabanı mount şartı
   aynen zorunlu; Kong için yalnız gömülü `KONG_DECLARATIVE_CONFIG` doğrulanırsa
   boş mount kabul ediliyor. Sonuç: portlar yalnız `127.0.0.1`, veri korunmuş.
2. **Canlı DB entegrasyon testi 5 Ağustos'tan beri kırıktı.** Varsayılan koşuda
   atlandığı için fark edilmemişti: `10a520d` paper market emrine 5 baz puan kayma
   ekledi, test kaymasız sabit bir beklenti taşıyordu. Beklenti ayardan
   hesaplanacak şekilde düzeltildi.

Ek olarak bekleyen `20260804000000_risk_state_locked_profit.sql` migration'ı
yerel DB'ye uygulanmamıştı; bu fazda uygulandı (46 migration).

## 4. Açık riskler ve sonraki faza devredilenler

- Şema hazır, **motor henüz kullanmıyor**: tüm yazmalar `legacy` bölümüne gider.
  Bölüm kimliğini emir/oturum yoluna taşımak Faz C'nin işidir.
- `supabase start` her çalıştırıldığında portları yeniden `0.0.0.0`'a açabilir;
  `baslat_guvenli_supabase.bat` (start → güvenlik betiği → migration) sırası
  korunmalı, `supabase start` tek başına çalıştırılmamalı.
- Postgres imajı `17.6.1.143` → `17.6.1.167` yükseldi (CLI sürümüyle birlikte).
  Veri kontrolleri temiz; kalıcı etkisi gözlenmedi.

---

AI Koordinatör İmzası : Claude (Anthropic)
Belge                  : QBP-MS-FAZ-B / 1.0
UTC zaman              : 2026-09-13
Kaynak commit          : f2e1713 + commit edilecek Faz B değişiklikleri
Karar                  : PASS
İnsan onayı            : Kapsam onaylı (13 Eylül 2026); faz notu incelemesi BEKLENİYOR
