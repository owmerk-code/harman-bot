# Faz E — Bölüm 2 Al-sat: tasarım notu (14 Eylül 2026)

## Sahibin gereksinimleri
- 30 dakikada bir tarama; analiz edilen coinlerde işlem açılır.
- Aynı coinde birden fazla eşzamanlı işlem (lot); tek işlem açıp bekleme yok.
- Üç bölüm de otonom; toplam sonuç günlük/haftalık/aylık raporlanır.

## Yapılanlar
| Parça | Dosya | Durum |
|---|---|---|
| Sinyal + lot kuralları (saf, canlı ve test ortak) | `engine/sleeves/spot_active_signals.py` | ✅ sentetik testli |
| Çok coinli 30m lot motoru | `engine/backtest/spot_active_backtest.py` | ✅ iki bağımsız inceleme turu |
| Yönetici lot kimliği (`review(lot_id=)`) | `engine/supervisor/supervisor.py` | ✅ |
| Ön-kayıt protokolü + koşucu | `research/spot_active_v1_development_protocol.json`, `scripts/spot_active_v1_validation.py` | Mühür bekliyor |
| Paylaşılan mühür doğrulaması | `engine/research/seal.py` | ✅ |
| 30m veri (33 sembol, noktasal-zamanlı evren) | `data/klines_cache/*_30m_*` | İndiriliyor |

## Veri bulguları
- Tüm sembollerde en uzun olağan boşluk 6 saat (borsa kesintileri).
- `LUNAUSDT`: 2022-05-13 00:30'da **437,5 saat** boşluk — eski LUNA delist, aynı sembolle yeni coin. Motor: 1 günden uzun boşlukta lotlar son görülen kapanıştan zorla kapanır. Göstergeler boşluklarla ayrılmış segmentlerde ayrı hesaplanır (ikinci inceleme: tek seri EMA200 1.600 bar sonra bile eski fiyatı %13,5 taşıyıp sahte "yükseliş" üretebiliyordu); her segment 600 tamamlanmış 4h bar ısınır.
- `MATICUSDT` 2024-09-10'da biter (POL'e geçiş) → delist kuralı.

## Canlı (paper) çalıştırma için AÇIK işler
1. **Sabit fiyatlı stop.** `ExchangeClient.create_stop_loss_order` yalnız `trailingDelta` ile iz süren STOP_LOSS gönderir; paper durum doğrulaması da `trailingDelta` zorunlu tutar. Lot başına ATR stopu için `stopPrice` destekli sabit STOP_LOSS (canlı + paper) ve yukarı taşıma için iptal/yeniden kur akışı gerekir. Binance sembol başına açık stop (algo) emri sınırı: lot tavanı 3.
2. **PC kapalıyken paper stop.** Paper stop yalnız süreç çalışırken ve o anki fiyatla tetiklenir; PC kapalıyken fiyat stopa değip geri dönerse paper stop KAÇAR (iyimser). Açılışta kapalı kalınan süredeki 30m düşükleri klines'tan okunup stop seviyesine değen lotlar stop fiyatından (boşlukta açılıştan) kapatılmalıdır. Gerçek Binance stopları borsada durduğu için bu sorun canlıda yoktur.
3. **Lot bazlı varlık muhasebesi.** Ana kasa sembol başına ortalama maliyet kullanır; al-sat için her lotun miktar, giriş, stop ve en yüksek kapanışı günlükten yeniden kurulmalı.
4. **Asgari tutar.** Bölüm kasası ~62 USDT; 5 USDT altı lot satılamaz (motor bunu modeller, canlı akış da SkipOrder ile uymalı).
5. **Zamanlama.** Görev 30 dakikada bir çalışmalı (şu an 4 saat); aynı 30m barın tekrar işlenmesi idempotent olmalı.

## Sonuç ve karar (14 Eylül 2026)
- `spot_active_v1` mühürlü koşu (`37e3b52`): **REJECTED 3/10**. Severe maliyet 2020-06..2024: −%48,8, DD %68,8, PF 0,85, 773 işlem, walk-forward 1/6. Normal maliyette bile −%5. Rapor: `reports/stages/spot_active_v1/validation_report.json`.
- Parametre onarımı yapılmaz. Al-sat kasası yeni ve farklı bir mekanizma ön-kaydedilene kadar **nakitte** kalır; reddedilen kural paper'da da çalıştırılmaz.
- Lot, segment ve boşluk altyapısı (yönetici `lot_id`, `signal_arrays`, motor) sonraki adaylar için korunur.
- Sonraki öncelik: Bölüm 3 için dondurulmuş `funding_carry_v2` ileriye dönük paper/testnet (Faz F altyapısı gerekli).

## Kabul
STAGE_3 ön-kayıt + doğrulama (`engine/research/gates.py`). Sonuç ne olursa olsun olduğu gibi raporlanır; reddedilirse bölüm yalnız "unvalidated" paper çalışır.
