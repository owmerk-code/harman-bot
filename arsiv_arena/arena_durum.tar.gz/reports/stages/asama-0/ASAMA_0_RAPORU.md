# Aşama 0 — Kapanış Raporu

**Rapor kimliği:** QBP-STAGE-0
**Plan sürümü:** 1.0
**Başlangıç:** 31 Temmuz 2026
**Bitiş UTC:** 2026-07-31T01:08:35.215Z
**Kaynak commit:** `8de8e39f4a91423cff98c65f3c8a0c8da9e8a2ac`
**Karar:** `PASS`

## 1. Amaç ve kapsam

Tek yetkili planı kurmak, geçmiş çelişkili belgeleri kayıpsız arşivlemek,
çalışma ağacının sahiplik envanterini çıkarmak, geçmiş strateji kanıtlarını
sınıflandırmak, test tekrarlanabilirliğini geri kazanmak ve canlı güvenlik
kilitlerini doğrulamak.

## 2. Yapılanlar

- `ANA_UYGULAMA_PLANI.md` tek yetkili plan olarak yürürlüğe alındı.
- `DURUM.md`, `AGENTS.md` ve `CLAUDE.md` tek-kaynak yapısına geçirildi.
- Eski belgeler `archive/legacy-plans/` altında korundu.
- Geçersiz “2395 günlük paper” kanıtı `INVALID_FORWARD_EVIDENCE` olarak
  sınıflandırıldı.
- 63 tarihsel araştırma/rapor artifact'i SHA-256 ile envanterlendi:
  - 49 `REJECTED`
  - 6 `RESEARCH_ONLY`
  - 1 `INVALID_FORWARD_EVIDENCE`
  - 1 `INVALID_DERIVED_DECISION`
  - 4 `HISTORICAL_ENGINEERING_EVIDENCE`
  - 2 `SUPPORTING_LOG`
- Önceden bulunan AI/runtime kod değişiklikleri `PRESERVE_AND_REVIEW` olarak
  kaydedildi; silinmedi veya resetlenmedi.
- Yerel DB migration/RLS/runtime ve güvenli ayar denetimi yapıldı.
- Test çalışma dizini problemi ayrıldı ve mevcut paket doğrulandı.

## 3. Doğrulamalar

| Doğrulama | Ölçülen sonuç | Karar |
|---|---:|---|
| Python collection | 665 test / 4.13 saniye | PASS |
| Python full | 664 passed, 1 skipped / 252.85 saniye | PASS |
| Panel | 10/10 | PASS |
| TypeScript | exit 0 | PASS |
| Compose config | exit 0 | PASS |
| Migration parity | 42 yerel = 42 DB | PASS |
| Mainnet/futures efektif kilitleri | tamamı false | PASS |
| Evidence sınıflandırması | 63/63 sınıflandırıldı | PASS |
| Legacy plan konsolidasyonu | tek aktif plan | PASS |

## 4. Kabul kapısı değerlendirmesi

| Kapı | Sonuç |
|---|---|
| Tek yetkili plan ve durum kaynağı | PASS |
| Kaynak commit ve dirty değişiklik sahipliği kayıtlı | PASS |
| Python testleri süreli ve tekrarlanabilir | PASS |
| Geçmiş kanıt sınıfları açık | PASS |
| Canlı mainnet/futures kilitleri kapalı | PASS |

## 5. Aşama 1'e devredilen zorunlu riskler

1. `trade_memory` için FORCE RLS eksik.
2. `get_similar_trades` SECURITY DEFINER fonksiyonu sabit search path'e sahip
   değil ve PUBLIC EXECUTE açık.
3. Stale DB kaydı `bot_status.running=true` gösterebiliyor.
4. AI Trade Gate provider hatasında `enter` fallback üretiyor.
5. WS retry sonrası REST fallback'in veri tazeliği/yeni giriş güvenliği
   mühürlenmemiş.
6. Gerçek DB integration testi skip durumda.
7. Üç local commit ve önceden bulunan AI/runtime diff'i henüz release incelemesi
   görmedi.

Bu bulgular Aşama 0'ı değil, Aşama 1 üretim güvenilirliği kapısını bloke eder.

## 6. Sonuç

Aşama 0 kabul koşullarının tamamı geçildi. Aşama 1 — Üretim güvenilirliğini
mühürleme çalışması başlayabilir. Mainnet kararı değişmemiştir: `NO-GO`.

---

AI Koordinatör İmzası : Codex (OpenAI)
Belge                  : QBP-STAGE-0 / 1.0
UTC zaman              : 2026-07-31T01:08:35.215Z
Kaynak commit          : 8de8e39f4a91423cff98c65f3c8a0c8da9e8a2ac
Kanıt manifest hash'i  : ff878ab6f98f56609c5f3d97ba12d7d1ff3768d250b9f4f599f23f6394c5926a
Karar                  : PASS
İnsan onayı            : Aşama 0 teknik kapanışı; mainnet onayı değildir
