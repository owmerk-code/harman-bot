# Aşama 0 — Çalışma Ağacı Envanteri

**Envanter zamanı:** 31 Temmuz 2026
**Kaynak HEAD:** `8de8e39f4a91423cff98c65f3c8a0c8da9e8a2ac`
**Dal:** `master`
**Remote durumu:** `origin/master` dalından 3 commit ileride

## 1. Remote üzerinde olmayan commitler

| Commit | Tarih (+03) | Açıklama | Sınıf |
|---|---|---|---|
| `ea5b15c` | 2026-07-28 00:58 | Scheduler overload/runtime lease değişiklikleri | PREEXISTING_UNREVIEWED |
| `529ce26` | 2026-07-28 01:52 | AI Trade Gate ve trade memory | PREEXISTING_UNVALIDATED |
| `8de8e39` | 2026-07-28 04:34 | Docker compose network düzeltmesi | PREEXISTING_UNREVIEWED |

Bu commitler silinmeyecek veya yeniden yazılmayacaktır. Aşama 1 öncesinde
işlevsel ve güvenlik incelemesinden geçmeleri gerekir.

## 2. Bu koordinasyon çalışmasından önce bulunan commit edilmemiş kod

Dosya zamanları 28 Temmuz 2026'dır ve 31 Temmuz tek-plan çalışmasından önce
mevcuttur.

| Dosya | Değişiklik özeti | İlk risk değerlendirmesi |
|---|---|---|
| `engine/ai/providers/anthropic.py` | Çağrı başına model override | Provider sözleşmesi ve test kapsamı doğrulanmalı |
| `engine/ai/providers/base.py` | Provider arayüzüne model parametresi | Tüm provider implementasyonlarının uyumu doğrulanmalı |
| `engine/ai/providers/openai_compat.py` | OpenCode URL/model biçimi ve override | Dış API davranışı ve model adı doğrulanmamış |
| `engine/ai/trade_gate.py` | Pre/post trade model override | Gate fallback güvenliği çözülmemiş |
| `engine/config.py` | `AI_TRADE_GATE_MODEL` ayarı | DB/settings allowlist ve secret sınırı doğrulanmalı |
| `engine/core/bot.py` | WS için beş deneme sonrası REST ile devam | Veri tazeliği kapısı olmadan yeni giriş riski incelenmeli |
| `engine/engine/strategy_manager.py` | Thread offload, model override ve trade-memory entry | Event-loop için olumlu olabilir; karar/fail-open etkisi doğrulanmalı |
| `tests/test_trade_gate.py` | AI gate/memory testleri | Untracked; üretim davranışıyla birlikte gözden geçirilmeli |

İlk karar: `PRESERVE_AND_REVIEW`. Sahiplik ve niyet bilinmeden reset veya silme
yapılmayacaktır.

## 3. 31 Temmuz tek-plan koordinasyon değişiklikleri

| Kapsam | Dosyalar | Sınıf |
|---|---|---|
| Tek plan ve durum | `ANA_UYGULAMA_PLANI.md`, `DURUM.md` | CURRENT_GOVERNANCE |
| AI yönlendirmeleri | `AGENTS.md`, `CLAUDE.md` | CURRENT_GOVERNANCE_POINTER |
| Aktif belge düzeltmeleri | `README.md`, `KURULUM.md`, `GO_LIVE_READINESS.md` | CURRENT_GOVERNANCE |
| Legacy arşivi | `archive/legacy-plans/` | HISTORICAL_ARCHIVE |
| Aşama rapor sistemi | `reports/stages/` | CURRENT_EVIDENCE |
| Manifest üretici | `scripts/build_stage0_evidence_manifest.py` | CURRENT_EVIDENCE_TOOL |

## 4. Birleştirme/commit kararı

Mevcut çalışma ağacında yönetişim belgeleri ile önceden bulunan AI/runtime kodu
aynı anda dirty durumdadır. Aşama 0 kapanışında:

1. Önceden bulunan kod değişiklikleri test ve güvenlik incelemesinden geçirilecek.
2. Kabul edilen kod ile yönetişim belgeleri mantıksal commitlere ayrılacak.
3. Reddedilen değişiklikler silinmeden önce gerekçe ve diff arşivi oluşturulacak.
4. Proje sahibinin açık talimatı olmadan remote'a push yapılmayacak.

## 5. İlk güvenlik sonucu

- Mainnet ve futures kod kilitleri efektif settings düzeyinde `false`.
- Çalışan Docker container yok.
- Efektif `PAPER_TRADING=true` ve `BINANCE_TESTNET=true`.
- Genel paper autopilot ve trend paper autopilot efektif olarak `true`.
- AI advisor, AI Trade Gate ve post-trade analiz efektif olarak `true`.

Paper/testnet otomasyonunun açık olması gerçek para riski yaratmıyor; ancak
Aşama 1 ve strateji ön-kaydı tamamlanmadan operasyon kanıtı olarak kabul
edilmeyecektir.
