# Aşama 0 — Başlangıç Raporu

**Rapor kimliği:** QBP-STAGE-0-START
**Plan sürümü:** 1.0
**Başlangıç tarihi:** 31 Temmuz 2026
**Durum:** `IN_PROGRESS`
**Canlı karar:** `NO-GO`

## Amaç

Tek yetkili planı yürürlüğe almak, geçmiş çelişkili plan/handoff belgelerini
kayıpsız arşivlemek ve Aşama 1'e geçmeden önce güvenilir bir kaynak/test/kanıt
başlangıcı oluşturmaktır.

## Başlangıç bulguları

- `master`, `origin/master` dalından üç commit ileridedir.
- Başka modellerden kalan yedi tracked değişiklik ve untracked bir test vardır.
- Bu değişiklikler sahiplik belirlenmeden silinmemiş veya resetlenmemiştir.
- Önceki “2395 günlük paper” yaklaşık iki saniyede tarihsel mum döngüsüyle
  üretilmiştir ve gerçek forward kanıt değildir.
- Son denetimde Docker, yerel DB, motor ve panel çalışmıyordu.
- Panel testleri 10/10 ve TypeScript typecheck temizdi.
- Python testleri hem tam hem dar pakette koleksiyon/çalışma aşamasında zaman
  aşımına uğradı; tek komisyon testi de koleksiyonda takıldı.
- AI Trade Gate provider hatasında `enter` fallback davranışı göstermektedir.

## Bu başlangıçta yapılan belge düzenlemesi

- `ANA_UYGULAMA_PLANI.md` tek yetkili plan olarak oluşturuldu.
- `DURUM.md`, `AGENTS.md` ve `CLAUDE.md` kısa tek-kaynak yönlendirmelerine
  dönüştürüldü.
- Eski sürümleri `archive/legacy-plans/` altında korundu.
- Aşama rapor yapısı ve imza şablonu oluşturuldu.
- README/KURULUM içindeki geçersiz `eth_trend_v1 ACCEPTED` anlatımı
  `RESEARCH_ONLY` olarak düzeltildi.

## Aşama 0'ın kalan işleri

1. Dirty çalışma ağacındaki her değişikliğin köken ve amacını kaydetmek.
2. Python test koleksiyonu takılmasının kök nedenini düzeltmek.
3. Tüm strateji/rapor kanıtlarını sınıflandıran makine-okunur manifest üretmek.
4. Mainnet/autopilot/futures kilitlerini env ve DB düzeyinde doğrulamak.
5. Aşama 0 kapanış testlerini çalıştırmak.
6. `ASAMA_0_RAPORU.md` ve evidence manifest hash'i ile PASS/FAIL kararı vermek.

## Karar

Aşama 0 başlamıştır fakat tamamlanmamıştır. Aşama 1'e geçiş izni yoktur.

---

AI Koordinatör İmzası : Codex (OpenAI)
Belge                  : QBP-STAGE-0-START / 1.0
UTC zaman              : 2026-07-31
Kaynak commit          : 8de8e39f4a91423cff98c65f3c8a0c8da9e8a2ac
Kanıt manifest hash'i  : AŞAMA 0 KAPANIŞINDA ÜRETİLECEK
Karar                  : IN_PROGRESS
İnsan onayı            : Proje sahibinin tek-plan talimatıyla başlatıldı
