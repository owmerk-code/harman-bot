# Aşama 0 — Doğrulama Sonuçları

**Tarih:** 31 Temmuz 2026
**Kaynak HEAD:** `8de8e39f4a91423cff98c65f3c8a0c8da9e8a2ac`
**Çalışma ağacı:** Dirty; ayrıntı `WORKTREE_ENVANTERI.md`

## Python

Temiz geçici pycache ve temp diziniyle, doğru repo çalışma dizininden:

```text
665 collected
664 passed
1 skipped
6 warnings
252.85 seconds
exit code 0
```

Atlanan test gerçek yerel DB paper integration testidir. DB ayrıca doğrudan SQL
ile incelenmiş, fakat bu skip Aşama 1 entegrasyon kapısında kapatılmalıdır.

Önceki zaman aşımlarının tekrarlanamama nedeni:

- Proje eski `Yeni klasör/quant-bot` konumundan
  `Desktop/QUANTBOT/quant-bot` konumuna taşınmıştı.
- İlk denetim geçersiz başlangıç çalışma dizini nedeniyle `C:\tmp` üzerinden
  yürütülmüştü.
- Doğru repo çalışma dizini ve ayrı `PYTHONPYCACHEPREFIX` ile koleksiyon 4.13
  saniyede tamamlandı.
- Tam paket aslında takılmıyor; bazı güvenlik/lifecycle testleri gerçek zamanlı
  beklemeler içerdiği için toplam süre yaklaşık dört dakikadır.

## Panel

```text
10 tests
10 passed
0 failed
duration 180.9066 ms
```

TypeScript:

```text
tsc --noEmit --incremental false
exit code 0
```

Panel testinde yalnız Node `MODULE_TYPELESS_PACKAGE_JSON` uyarısı vardır.

## Docker/Compose

- `docker compose config --quiet`: `PASS`
- Engine ve panel başlatılmadı.
- Yerel DB yalnız denetim süresince başlatılıp yeniden durduruldu.
- Son durumda çalışan Quant container yok.

## Statik kalite

Yeni/aktif yönetişim dosyalarında:

- Kırık yerel Markdown bağlantısı yok.
- Trailing whitespace yok.

Önceden bulunan `engine/core/bot.py` whitespace izi temizlendi; davranış
değişikliği yapılmadı.

## Sonuç

Aşama 0 test tekrarlanabilirliği kapısı `PASS`. Canlı DB entegrasyon skip'i,
RLS/function privilege ve stale runtime status bulguları Aşama 1'in zorunlu
işleridir.
