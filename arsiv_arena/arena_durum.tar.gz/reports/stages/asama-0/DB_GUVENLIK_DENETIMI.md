# Aşama 0 — Yerel DB ve Güvenlik Kilidi Denetimi

**Denetim tarihi:** 31 Temmuz 2026
**Kapsam:** Yerel `supabase_db_quant-bot` Postgres container'ı
**Engine/panel durumu:** Denetim boyunca kapalı

## Uygulama yöntemi

Yalnız yerel Postgres container'ı geçici olarak başlatıldı. Engine, panel,
PostgREST, Realtime ve Kong başlatılmadı. SQL sorguları sır veya API anahtarı
okumadı; yalnız migration, RLS, güvenli boolean ayar ve runtime sağlık
metadata'sı incelendi. Denetim sonunda DB yeniden durduruldu.

## Sonuçlar

### Migration

- Yerel migration sürümü sayısı: 42
- DB'ye uygulanmış migration sürümü sayısı: 42
- Yerelde olup DB'de olmayan sürüm: yok
- DB'de olup yerelde olmayan sürüm: yok
- Son sürüm: `20260728000000`

Karar: `PASS`.

### RLS

Public şemadaki 27 tablonun tamamında RLS açık.

- 26 tabloda `FORCE ROW LEVEL SECURITY` açık.
- `trade_memory` tablosunda RLS açık fakat FORCE RLS kapalı.
- `trade_memory_service_only` politikası `auth.role() = 'service_role'`
  kontrolüne sahip.

Karar: `PARTIAL`. Aşama 1'de FORCE RLS eklenmeden DB güvenlik mührü verilemez.

### SECURITY DEFINER fonksiyonu

`public.get_similar_trades` için:

- `SECURITY DEFINER=true`
- Sabit `search_path` tanımlı değil
- `PUBLIC` rolüne `EXECUTE` verilmiş

Karar: `FAIL` (Aşama 1 güvenlik kapısı). Fonksiyonun search path'i
`pg_catalog, public` gibi açık bir listeyle sabitlenmeli, PUBLIC/anon/authenticated
execute yetkileri kaldırılmalı ve yalnız service role için açıkça verilmelidir.

### Runtime durumu

- `bot_runtime_lease` içinde `engine` lease kaydı var fakat süresi dolmuş.
- Son heartbeat: 29 Temmuz 2026.
- `bot_status.running=true` kalmış olmasına rağmen heartbeat eski ve çalışan
  engine container yok.

Karar: `PARTIAL`. Stale `running=true` durumu panel/operasyon katmanında yanlış
canlılık gösterebilir. Aşama 1'de heartbeat yaşı ve lease geçerliliği tek gerçek
canlılık kaynağı olmalıdır.

### Güvenlik kilitleri

Efektif Python settings:

| Ayar | Değer |
|---|---|
| `BINANCE_TESTNET` | `true` |
| `PAPER_TRADING` | `true` |
| `MAINNET_TRADING_ENABLED` | `false` |
| `MAINNET_AUTOPILOT_ENABLED` | `false` |
| `SPOT_TREND_AUTOPILOT_ENABLED` | `false` |
| `SPOT_TREND_MAINNET_APPROVED` | `false` |
| `TREND_EXECUTION_MAINNET_APPROVED` | `false` |
| `FUTURES_ENABLED` | `false` |
| `FUTURES_MAINNET_TRADING_ENABLED` | `false` |
| `FUTURES_GO_LIVE_APPROVED` | `false` |

DB `settings` tablosu mainnet/futures kilitleri için `true` override içermiyor.
DB'de paper/testnet otomasyonu ve AI katmanları açık.

Karar: Mainnet/futures kilidi `PASS`; paper otomasyonu Aşama 1/2 kabul kanıtı
değildir.

## Aşama 1 zorunlu düzeltmeleri

1. `trade_memory` için FORCE RLS migration'ı.
2. `get_similar_trades` için güvenli search path ve execute privilege daraltma.
3. Stale `bot_status.running` davranışı için canlılık semantiği/testi.
4. AI Trade Gate'in hata halinde `enter` üretmesinin kaldırılması veya gate'in
   yalnız shadow/advisory moda alınması.
5. WS REST fallback sırasında veri tazeliği doğrulanmadan yeni giriş
   açılamadığının kanıtlanması.
