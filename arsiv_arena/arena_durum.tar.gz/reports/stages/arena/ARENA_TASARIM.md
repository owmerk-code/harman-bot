# Strateji Arenası v1 — mühendislik tasarımı

Durum: TASLAK (2026-09-14). Kurallar `research/arena_v1_protocol.json` olarak **mühürlenmeden** arena başlamaz.

## 1. Amaç
Birden fazla kurallı bot ve LLM ajanını, **aynı piyasa verisi, aynı maliyet modeli ve aynı saat** ile ileriye dönük
(forward) sanal parayla yarıştırmak; kanıtlanan ajanı insan onayıyla gerçek bölümlere (core / spot_active / futures)
aday yapmak. Arena gerçek bölümlerin cüzdanına, defterine, risk durumuna **dokunmaz**.

Değişmez güvenlik kuralları:
- Gerçek emir yok (spot/futures mainnet ve testnet emir yolu arenada hiç çağrılmaz; yalnız public veri).
- Kaldıraç ≤ 3x, kaldıraçlı her pozisyonda zarar-durdur zorunlu, izole marjin, likidasyon modellenir.
- AI yalnız **öneri** üretir; doğrulama katmanı reddedebilir; AI kuralları/limitleri değiştiremez.
- Kurallar sonuç görüldükten sonra değiştirilmez (yeni sürüm = yeni ajan, yeni deneme sayılır).

## 2. Mimari karar: ayrı arena defteri (supervisor kaynak genişletmesi DEĞİL)
İnceleme: supervisor yalnız `paper/testnet/mainnet` kaynaklarını ve 3 sabit sleeve'i kabul ediyor; `OrderIntent`
yalnız piyasa emri + spot long destekliyor (grid limit emirleri, futures short yok). Kaynak CHECK'lerini gevşetmek
üretim güvenlik kısıtlarını zayıflatır. Bu yüzden:
- `engine/arena/` kendi kendine yeten paket: maliyet modeli, mum tabanlı deterministik broker, ajan arayüzü, çalıştırıcı.
- Yeniden kullanılan: `GridStrategy`/`plan_grid_execution` mantığı, sinyal fonksiyonları (trend, BB/RSI, kırılım,
  carry v2), `catchup.last_closed_bar_open` hizalaması, haber tabloları, `engine/ai/lab` istemcileri ve çağrı sınırları,
  araştırma istatistikleri (DSR/PBO).
- Terfi = aynı `strategy_version`'ın supervisor yolunda **yeniden** devreye alınması (arenadan veri kopyalanmaz).

## 3. Bileşenler
| Modül | Sorumluluk |
|---|---|
| `arena/costs.py` | TEK maliyet kaynağı: spot fee 10 bps, futures taker 5 bps / maker 2 bps, kayma 5 bps (normal); "ağır" katman fee×2 + kayma 20 bps raporda ayrıca hesaplanır. Fonlama: gerçek Binance fonlama kayıtları. Bakım marjı 0,5 %, likidasyon ücreti 0,5 %. |
| `arena/market.py` | Artımlı önbellek `data/arena_cache/` (mühürlü önbelleklere asla yazmaz): spot+perp 15m/1h/4h/1d kapanmış mumlar, fonlama, premiumIndex, open interest, Korku&Açgözlülük, olay takvimi. Tutarlı anlık görüntü: `snapshot_id = sha256(kesim zamanı + sembol başına son open_time)`. |
| `arena/broker.py` | Hesap başına deterministik sanal borsa: spot (long) + USDT-M (long/short, ≤3x, izole). Emir türleri: piyasa, limit (grid), zarar-durdur, kâr-al. Dolum 15m mum yolu ile; aynı mumda stop ve hedef birlikte değerse **olumsuz sıra** (önce stop). Limit dolumu fiyat limiti 5 bps geçerse. Durum dosyası atomik + sha256 (mevcut paper cüzdan deseni). |
| `arena/agents/` | `RuleAgent` (deterministik, mum mum yeniden oynatılabilir) ve `LlmAgent` (yalnız canlı karar). Çıktı: `ArenaOrder` listesi. |
| `arena/validate.py` | Emir doğrulama: evren, bakiye, pozisyon başına ≤ bölüm sermayesinin %30'u, kaldıraç ≤3x, stop zorunlu, stop mesafesi likidasyondan önce. |
| `arena/runner.py` | Adım: veri güncelle → kurallı ajanları kaçırılan kapanmış mumlar üzerinde sırayla oynat → açık emir/stop'ları mum yolunda işle → LLM karar zamanı geldiyse sor → doğrula → uygula → özkaynak anlık görüntüsü. `ana_kasa_otomatik.ps1` içinde core döngüsünden sonra, hatası döngüyü durdurmaz. |
| `arena/leaderboard.py` | Günlük/haftalık/aylık getiri, max düşüş, işlem sayısı, ağır maliyet getirisi, kıyaslara göre fark, DSR. Telegram özeti + panel. |

## 4. Bilgisayar kapalıyken (ev PC'si)
- **Kurallı botlar:** mühürlü ve deterministik oldukları için kapalı geçen kapanmış mumlar açılışta sırayla
  oynatılır; her karar yalnız o mumun kapanışına kadarki veriyi görür. Bu, 7/24 çalışan sistemin yapacağıyla aynıdır.
  Kayıtlarda `replayed=true` işaretlenir; raporda canlı/oynatılmış karar oranı gösterilir.
- **Açık emirler/stop'lar/likidasyon:** tüm ajanlar için kapalı süredeki 15m mumlar üzerinde işlenir.
- **LLM ajanları:** yalnız canlı karar (geçmişe dönük soru sorulmaz); kapalı sürede yeni işlem açamazlar.
  Bu dezavantaj raporda "karar fırsatı sayısı" ile açıkça gösterilir.

## 5. Ajan listesi (v1, mühürlenecek)
Başlangıç sermayesi: her defter **205,93 USDT (= 10.000 TL, ana sistemle aynı kur)**.

| # | Ajan | Tür | Pazar | Özet |
|---|---|---|---|---|
| 1 | grid_v1 | kurallı | spot BTC/ETH | ATR aralıklı grid, 1h, trend filtresi yok |
| 2 | trend_v1 | kurallı | spot evren | 4h EMA rejimi + kırılım girişi, ATR stop |
| 3 | meanrev_v1 | kurallı | spot evren | 1h BB alt bant + RSI<30, ortalamaya dönüşte çıkış, zaman stop'u |
| 4 | breakout_fut_v1 | kurallı | USDT-M ≤3x | 4h Donchian kırılımı long/short, ATR stop |
| 5 | carry_v2_fwd | kurallı | spot+perp | mühürlü funding_carry_v2 kuralları |
| 6–9 | llm_trader_{opus5,fable51,astra,sol} | LLM | 3 bölüm | al-sat 40 % · kaldıraçlı 30 % · haber/olay 30 % |
| 10–13 | llm_manager_{opus5,fable51,astra,sol} | LLM | kurallı ajan kopyaları | 1–5 numaralı botlara sermaye dağıtır (toplam ≤100 %) |
| K1 | bench_btc_hold | kıyas | spot | başlangıçta BTC al, tut |
| K2 | bench_dca | kıyas | spot | haftalık eşit tutarda BTC |
| K3 | bench_usdt_earn | kıyas | nakit | yıllık sabit oran (mühürlenecek, ör. %4) |
| R | ana sistem | referans | — | mevcut `sleeve_equity_snapshots` (ayrı defter değil) |

Deneme sayımı: 13 aday ajan proje çapındaki `n_trials`'a eklenir (18 → 31); kıyaslar sayılmaz.

## 5b. Hesap risk katmanı (`engine/arena/risk.py`, protokol v1.1 `risk1`)
Profesyonel çoklu-strateji fonlarının "bağımsız masa + merkezi risk" modeli: her ajan kendi sermayesiyle
işlem yapar, risk katmanı ajandan bağımsızdır ve ajan limitleri değiştiremez. Her karar anında, ajanın
emirlerinden sonra uygulanır; kıyaslar muaftır.

| Katman | Kural | Sonuç |
|---|---|---|
| İşlem başına | Stop'a kadar risk ≤ %1 özsermaye; spot pozisyon ≤ %20; kaldıraçlı teminat ≤ %10 | Tutar küçültülür (büyütülmez) |
| Portföy | Tüm stoplar birlikte çalışsa kayıp ≤ %5 | Yeni emir kalan bütçeye küçültülür |
| Saatlik / seri | Son 60 dk ≤ 3 piyasa girişi; 3 ardışık zarar → 4 saat soğuma | Yeni giriş reddedilir |
| Sembol | Tek coinde zarar ≥ %3 (stopsuz grid envanteri dahil) | O coin kapatılır, 24 saat işlem yok |
| Dönem | Gün −%3 · ISO hafta −%6 · ay −%10 | Yeni giriş yok, bekleyen açılışlar iptal; stoplar çalışır |
| Toplam | Zirveden −%15 | Her şey kapanır, hesap kalıcı durur (insan kararı) |

Kâr tavanı yoktur. Carry çifti (spot long + kaldıraçlı short) delta-nötr sayılır; bacaklar eşit küçültülür.
Sınırlama: kurallar karar anlarında (1h/4h/1d) uygulanır; aradaki sürede pozisyon stopları 15m mumlarla çalışır.
Sonraki sürümler için aday (sonuç görmeden, yeni protokolle): volatilite hedefleme, korelasyon/VaR tabanlı
portföy riski, stres senaryoları, kazanana sermaye kaydıran merkezi dağıtıcı.

## 6. LLM karar sözleşmesi — uygulanan hal (protokol `arena_v1_llm`, mühürlü)
Aşağıdaki ilk taslağın yerine geçer:
- Saatlik kapanışlar izlenir, **model başına en erken 2 saatte bir** soru (proje sahibi isteği); yalnız canlı karar.
- Tek çağrıda trader emirleri + yönetici ağırlıkları; model başına günlük sınır 12 (laboratuvarla ortak).
- Model **fiyat yazmaz**: stop/hedef yüzde, tutar bölüm sermayesinin yüzdesi; mutlak fiyatları sistem hesaplar.
- Trader bölümleri spot %40 / kaldıraçlı %30 / olay %30 (olay ≤ 72 saat); her emir ayrı bölüm etiketi alır.
- Yönetici defteri işlem açmaz: kurallı v1.1 hesaplarının gerçek özsermaye getirileri üzerinde ağırlık, devir maliyeti
  (normal/ağır), dönem kaybında yatırım oranı artırılamaz, zirveden −%15'te nakit ve kalıcı durdurma.
- Haberler karar anına kadar yayımlananlarla sınırlı (son 12 saat, ≤ 15 başlık).

### İlk taslak (tarihsel)
- En erken 4 saatte bir; tek çağrıda hem trader hem yönetici kararı (abonelik limitini korur).
  Model başına günlük çağrı sınırı `max_calls_per_day` (öneri 6); sınır dolarsa ajan "karar yok" turu geçirir.
- Girdi: tutarlı anlık görüntü (evren özet tablosu, fonlama/OI, Korku&Açgözlülük, olay takvimi, son haberler),
  hesap durumu (bakiye, pozisyonlar, PnL), ajanın son 3 kararının özeti, sabit kurallar.
- Çıktı: katı JSON şeması (pydantic, extra=forbid): `trader.orders[]` (section, symbol, side, notional_usdt,
  leverage, stop, take_profit, time_exit_hours, reason_tr), `trader.close[]`, `manager.weights{agent: pct}`.
- Geçersiz/eksik alan → o emir reddedilir ve kaydedilir; zaman aşımı → tur boş geçer. Mevcut pozisyonların stop'ları sürer.

## 7. Veritabanı (yeni tablolar, FORCE RLS, service_role)
- `arena_accounts` (id, kind rule|llm_trader|llm_manager|benchmark, strategy_version, protocol_sha256, initial_usdt, enabled)
- `arena_fills` append-only (idempotency_key UNIQUE, account, symbol, market, side, qty, price, fee, funding, reason, replayed, snapshot_id)
- `arena_decisions` append-only (account, decided_at, kind, input_snapshot_id, raw/parsed, validation, ai_call_id)
- `arena_equity_snapshots` append-only (account, observed_at, equity_usdt, equity_severe_usdt, positions jsonb)
Hesap durumu `data/arena_state/<account>.json` (atomik, sha256); tutarlılık: fills yeniden oynatılınca aynı bakiye.

## 8. Terfi kapısı (öneri; mühürlenecek)
≥ 90 UTC gün · net getiri > max(BTC tut, USDT faiz) · ağır maliyette de pozitif · max düşüş ≤ %20 ·
≥ 20 kapanmış işlem · DSR (n_trials=31) ≥ 0,95 · insan onayı → önce 2–4 hafta testnet provası.

## 9. Aşamalar
1. Altyapı: costs, market cache/snapshot, broker (spot+futures), DB şeması, runner iskeleti, testler.
2. Kurallı botlar 1–5 + kıyaslar; protokol mühürü.
3. LLM trader/yönetici; şema, doğrulama, çağrı sınırları.
4. Skor tablosu: Telegram + panel. Zengin veri (OI, Korku&Açgözlülük, olay takvimi).
