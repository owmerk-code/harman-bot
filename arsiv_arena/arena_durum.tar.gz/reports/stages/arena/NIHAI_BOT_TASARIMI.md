# Nihai Trader Bot — Tasarım ve Vizyon

**Tarih:** 17 Eylül 2026
**Durum:** tasarım (kod henüz yazılmadı; parçaların bir kısmı hazır)
**Karar:** Arena 90 günü doldurunca (16 Aralık 2026) bu tasarım mühürlenip tek bir sisteme dönüşecek.

---

## 1. Neden şu an tek bir bot yok?

Çünkü **içine ne koyacağımızı henüz bilmiyoruz.** Bugün 28 yarışmacı aynı piyasada, aynı parayla,
aynı kurallarla yarışıyor. Arena bir yarışma değil, **işe alım sürecidir**: 90 gün sonunda hangi
yöntemin gerçekten para kazandığı, hangi AI modelinin işe yaradığı, hangi coinde maliyetin kârı yediği
**ölçülmüş** olacak. Nihai bot, hayatta kalanları işe alan tek sistemdir.

Bugün bir bot yazsaydık, içindeki her seçim bir tahmin olurdu. 90 gün sonra her seçim bir kanıt olacak.

---

## 2. Nihai bot ne olacak? (tek cümle)

> 7/24 çalışan, kendi durumunu her an bilen, geçmiş her işlemini ve o işlemi **neden** açtığını
> hatırlayan, kanıtlanmış yöntemler arasında parayı dağıtan, riski asla aşamayan ve yaptığı her şeyi
> Türkçe açıklayabilen **tek** bir sistem.

---

## 3. Yedi katman

### Katman 1 — Veri
15 dakikalık ve 1/4 saatlik mumlar, fonlama oranı, açık pozisyon (OI), Korku & Açgözlülük, haberler
(5 kaynak), borsa kuralları (minimum tutar, miktar adımı), gecikme ölçümü.
Her kaynak sağlık kaydı tutar; hata veren kaynak üstel olarak bekletilir ama **haber freni asla
kaynaksız kalmaz**. Veri eskirse bot yeni işlem açmaz — bilmediği bir piyasada işlem yapmaz.

### Katman 2 — Durum (bilinç)
Her turda güncellenen canlı bir durum tablosu. Bot karar vermeden önce şunları **bilir**:
- Nakit, açık pozisyonlar, coin bazında maruziyet, toplam açık risk
- Bugün/bu hafta/bu ay kullanılan risk bütçesi ve her frene kalan mesafe
- Her coin için rejim etiketi: **trend / yatay / yüksek oynaklık**
- Son 7 ve 30 günün getirisi, zirveden düşüş, isabet oranı, ücret/kâr oranı
- İşletme durumu: çalışma süresi, veri tazeliği, son hata, borsa gecikmesi

"Bilinçli çalışma" dediğimiz şey somut olarak budur: bot her karardan önce *neredeyim, ne kadar
riskim var, hangi rejimdeyim, son haftam nasıl* sorularını cevaplayabilir.

### Katman 3 — Hafıza (üç zaman ölçeği)

| Ölçek | Ne tutar | Nasıl kullanılır |
|---|---|---|
| **Kısa (anlatı)** | Son 10 işlem: *açarken ne dedim → nasıl bitti, kaç saatte, kaç para* | Karar anında modele/kurala verilir: aynı hatayı tekrarlamasın |
| **Orta (istatistik)** | Coin × rejim × yöntem kırılımında: işlem sayısı, isabet, işlem başı beklenti, ücret payı, ortalama tutma süresi | Örnek sayısı eşiği geçtiyse karar ağırlığına girer |
| **Uzun (yapısal ders)** | İstatistik testinden geçmiş kurallar: "stop 2×ATR'den darsa isabet %15 düşüyor (n=120)" | **Kısıt** olur, öneri değil. Ayda bir gözden geçirilir, kanıt zayıflarsa düşer |

**Disiplin:** 3 kayıptan "ETH kötüdür" dersi çıkarmak batıl inançtır. Her satır örnek sayısı taşır;
eşiğin altındaki hiçbir şey karara dönüşmez. Hafıza **riski azaltabilir, asla artıramaz.**

Açık pozisyonun kendi hikâyesi de hafızadır: ne bekliyordum, şu ana kadar ne oldu, **en çok ne kadar
kârdaydım (MFE)**, en çok ne kadar zarardaydım (MAE), tezim hâlâ geçerli mi.

### Katman 4 — Karar (tek beyin değil, kurul)
1. **Kanıtlanmış yöntemler** sinyal üretir (arena kazananları: grid, trend, makas, rotasyon… hangileri
   kapıları geçtiyse).
2. **Dağıtıcı**, yöntemler arasında parayı böler — ölçülmüş performansa ve rejime göre, duyguyla değil.
3. **AI**, üç iş yapar: haber/olay riskinde **veto veya küçültme**, berabere kalan durumlarda hakemlik,
   ve kararın Türkçe açıklaması. AI **asla** riski artıramaz, limit değiştiremez.
4. Her karar şunları yazar: **tez, geçersizleşme seviyesi (stop), zaman ufku, beklenen sonuç.**
   Böylece her işlem sonradan "haklı mıydı" diye ölçülebilir.

### Katman 5 — Yürütme
Borsa kuralları (miktar adımı, fiyat adımı, minimum tutar), kısmi dolum, tekrar denenebilir emir
kimliği, gecikme ölçümü, emir sonrası borsa durumuyla mutabakat. Testnet ölçümümüz: emir açma ~250 ms,
iptal ~380 ms; 5,00 $'lık emir yuvarlamayla 5,36 $ oluyor. Nihai bot bu gerçekleri hesaba katar.

### Katman 6 — Risk (sert, değişmez)
İşlem başına %1, tek coin %20, kaldıraç ≤3x, toplam açık risk %5, gün −%3 / hafta −%6 / ay −%10'da
yeni giriş yok, zirveden −%15'te her şey kapanır ve **hesap durur** (yeniden başlatmak insan kararı).
Bu katman hafızanın, AI'ın ve dağıtıcının **üstündedir**; hiçbiri onu gevşetemez.

### Katman 7 — Öğrenme döngüsü
- **Her gece:** istatistikler yeniden hesaplanır, hafıza blokları güncellenir, atıf raporu çıkar.
- **Haftalık:** aday dersler çıkarılır ve istatistik kapısından geçirilir (asgari örnek + dönem dışı
  doğrulama). Geçemeyen ders **kaydedilmez**.
- **Aylık:** dağıtım gözden geçirilir; kapılarını kaybeden yöntemin ağırlığı sistematik olarak kesilir.
- **Üç ayda bir:** tam yeniden doğrulama. Yapısal değişiklik = **yeni mühür, yeni sürüm.**

---

## 4. Bir işlemin hayatı (somut)

**Açarken** bot şunları görür: bu coindeki geçmişim (n=…), bu rejimdeki geçmişim, son 10 işlemimin
tez→sonuç defteri, kalan risk bütçem, ilişkili coinlerdeki maruziyetim, haber vetosu var mı.
Sonra yazar: *"ZEC, EMA50 üzerinde +%5, hacim 1,6 kat → 8–24 saatlik kırılım beklentisi; tezim
2×ATR altına düşerse geçersiz."*

**Açıkken** takip eder: en yüksek kâr (MFE), en derin zarar (MAE), süre normalin üstünde mi, rejim
değişti mi. Rejim tersine dönerse stop beklenmeden çıkabilir.

**Kapanırken** kaydeder: sonuç, çıkış sebebi, tez doğru muydu, stop gerçek bir geçersizleşme miydi
yoksa olağan gürültü müydü. Bu kayıt ertesi günün istatistiğine, haftanın dersine girer.

---

## 5. Takvim

| Tarih | Aşama | Çıktı |
|---|---|---|
| 15 Eyl 2026 | Arena başladı | 28 yarışmacı, 5 mühür |
| **1 Eki** (gün 16) | İlk sağlık değerlendirmesi | Çalışma süresi, geçerli cevap oranı, veri bütünlüğü |
| **15 Eki** (gün 30) | Ara rapor | İstatistikler anlam kazanmaya başlar; hiçbir seçim yapılmaz |
| **15 Kas** (gün 60) | İkinci ara rapor | Eğilimler; yine seçim yok |
| **16 Ara** (gün 90) | **Karar** | Mühürlü kapılar uygulanır: kim geçti? |
| Ara–Oca | Nihai bot inşası | Kazananlar + hafıza + dağıtıcı → yeni mühürlü sürüm |
| +30 gün | Tek sistem kâğıt üstünde | Bütünün ölçümü (parçaların değil) |
| Sonra | Gerçek para görüşmesi | **Senin açık kararın**, küçük tutarla, VPS şartıyla |

---

## 6. Bugün hazır olan parçalar

- İşlem defteri, karar kaydı, AI soru-cevap kaydı (kanıt zinciri, makine dışına yedekli)
- **Hafıza motoru** (`engine/arena/memory.py`) — tez→sonuç, coin geçmişi, örnek disiplini
- **Atıf motoru** (`engine/arena/analysis.py`) — kazanç/kayıp nereden, ücret payı
- **Çalışma süresi ölçüsü** (`engine/arena/uptime.py`)
- **Risk katmanı** (`engine/arena/risk.py`) — nihai bota olduğu gibi geçecek
- **Yürütme gerçekleri** (`scripts/testnet_emir_testi.py`) — gecikme, yuvarlama, minimum tutar
- Telegram sorguları (`/arena`, `/analiz`, `/hafiza`), panel, günlük rapor, yedek + geri yükleme

## 7. Eksik parçalar — durum (21 Eylül 2026 güncellemesi)

| Parça | Durum | Nerede |
|---|---|---|
| **Rejim etiketleme** | ✅ yazıldı | `engine/arena/regime.py` — trend/yatay/fırtına; eşik her sembolün kendi ATR ortancasına göre (mutlak değil), `label_at()` ileriye bakmaz |
| **MFE/MAE** | ✅ yazıldı | `engine/arena/excursion.py` — işlem içi en iyi/en kötü an, kâr geri verme, stop gürültü müydü |
| **Ders motoru** | ✅ yazıldı | `engine/arena/lessons.py` — üç kapı (≥20 işlem, belirgin etki, **iki yarıda da aynı yön**), denenen hipotez sayısı raporlanır |
| **Yürütme katmanı** | ✅ yazıldı | `engine/live/execution.py` — adım/tick yuvarlama, bilimsel gösterim yasağı, tekrar-güvenli emir kimliği, kısmi dolum, iki yönlü mutabakat; testnette doğrulandı (252 ms açılış) |
| **Derin çözümleme** | ✅ yazıldı | `scripts/arena_derin_analiz.py` — üçünü defterle birleştirir |
| **Dağıtıcı** | ⏳ 90. günden sonra | Kanıtlanmış yöntemler arası para paylaşımı; kazananlar belli olmadan yazılamaz |
| **Tek sistem koşucusu** | ⏳ 90. günden sonra | Yukarıdakileri tek mühürlü döngüde birleştirir |

Kalan iki parça bilinçli olarak bekletiliyor: ikisi de "hangi yöntem kazandı" cevabına muhtaç.

---

## 8. Dürüst sınırlar

- Hafıza zekâ değildir. Geçmiş istatistik, geleceği garanti etmez.
- ~200 USDT'lik hesapta **maliyet baskındır**: ölçtük, ücret brüt kârın %23'ünü yedi, BTC'de kârı aştı.
  Nihai bot bu yüzden az ve büyük hareket hedefleyen yöntemleri tercih edecek.
- Hiçbir kazanç sözü verilmiyor. Kapılar geçilmezse **doğru karar "gerçek paraya geçmemek"tir** ve
  sistem bunu söyleyecek şekilde kurulmuştur.
- Gerçek para, çalışma süresi kapısı (%99,5) ve senin açık onayın olmadan **hiçbir koşulda** açılmaz.
