# Aşama Kanıtları

Bu dizin [`ANA_UYGULAMA_PLANI.md`](../../ANA_UYGULAMA_PLANI.md) aşamalarının
kanıt ve kapanış raporlarını tutar.

Beklenen yapı:

```text
reports/stages/
  asama-0/
    ASAMA_0_RAPORU.md
    evidence-manifest.json
  asama-1/
    ASAMA_1_RAPORU.md
    ...
```

Bir aşama yalnız imzalı rapor kararı `PASS` ise tamamlanmış sayılır.
