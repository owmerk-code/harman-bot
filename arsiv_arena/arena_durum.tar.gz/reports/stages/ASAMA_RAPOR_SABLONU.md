# Aşama N — Kapanış Raporu

**Rapor kimliği:** QBP-STAGE-N
**Plan sürümü:**
**Başlangıç UTC:**
**Bitiş UTC:**
**Kaynak commit:**
**Karar:** `PASS | FAIL | BLOCKED | EXTEND`

## 1. Amaç ve kapsam

## 2. Başlangıç durumu

## 3. Yapılan değişiklikler

## 4. Çalıştırılan doğrulamalar

| Doğrulama | Komut/kanıt | Sonuç |
|---|---|---|

## 5. Kabul kapısı değerlendirmesi

| Kapı | Eşik | Ölçülen | Karar |
|---|---:|---:|---|

## 6. Doğrulanamayanlar ve açık riskler

## 7. Sonuç ve güvenli sonraki adım

## 8. Kanıt manifesti

- Manifest dosyası:
- SHA-256:

---

AI Koordinatör İmzası : Codex (OpenAI)
Belge                  :
UTC zaman              :
Kaynak commit          :
Kanıt manifest hash'i  :
Karar                  :
İnsan onayı            :
