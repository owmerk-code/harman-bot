# Spot-v5 Quick Mode Reports — Rejected

Bu dizindeki 3 JSON raporu, `--quick` flag'i ile (farkında olmadan) üretildi:

| Dosya | Tarih |
|---|---|
| `spot_v5_validation_20260720_073151.json` | 2026-07-20 |
| `spot_v5_validation_20260720_073240.json` | 2026-07-20 |
| `spot_v5_validation_20260720_073259.json` | 2026-07-20 |

## Neden Geçersiz?

- Quick mode sadece 2019–2020 verisini kullanır (2 yıl, 100 MC sim, 3 WF window)
- `run_walk_forward()`'da train_size=504 (1.4yıl) ve test_size=168 (0.5yıl) ile çalışır
- Holdout 2025 verisi quick modda yüklenmez
- **Bu raporlar validation kanıtı değildir.** AGENTS.md'deki kabul kriterlerini karşılamaz.

## Geçerli Validation

Full validation (`--quick` olmadan) çalıştırılmalıdır:
- Veri: 2017-01-01 → 2024-12-31 (development) + 2025 (holdout)
- Walk-forward: 5 pencere (3yıl train / 1yıl test)
- Monte Carlo: 2000 simülasyon
- Holdout: 2025 verisi (mühürlü)

Rapor `reports/` dizinine yazılacaktır.
