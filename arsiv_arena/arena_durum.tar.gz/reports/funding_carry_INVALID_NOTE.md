# funding_carry — `REJECTED` kararı geçersizdir (`INVALID`)

**Tarih:** 4 Ağustos 2026
**Etkilenen kanıt:**
`reports/funding_carry_validation_20260721_143907.json`,
`reports/funding_carry_validation_20260721_213130.json`,
`reports/funding_carry_validation_20260723_230111.json`
**Yeni sınıf:** `REJECTED` → **`INVALID`**

## Neden geçersiz

Rapor kendi içinde çelişkiliydi:

| Alan | Değer |
|---|---|
| development getirisi | **-%100.0** (final bakiye `$0.000008`) |
| `funding_pnl_total` | **0.0** |
| `sharpe_ratio` | **+1.5211** |
| Monte Carlo p95 (ETHUSDT) | **+%12894.84** |

Hedge oranı 1.0 olan delta-nötr bir defter, funding hiç işlememişken -%100
kaybedip aynı anda pozitif Sharpe üretemez. Bu, stratejiye dair bir bulgu
değil, defterin kendisine dair bir hatadır.

## Kök nedenler — dört ayrı muhasebe hatası

1. **Short, sıfır giriş fiyatıyla markalanıyordu.**
   `equity = cash + spot_qty*fiyat − perp_short_qty*fiyat`
   Bir short'un değeri realize olmamış P&L'dir (`qty × (giriş − fiyat)`),
   notionalin kendisi değil. Eski formül **her barda tüm perp notionalini**
   equity'den düşüyordu.

2. **Çıkışta nakit, notionalin tamamı kadar azaltılıyordu.**
   Açılışta notional nakde hiç girmemişti (short teminatlıdır), ama kapanışta
   `cash -= perp_close_cost` uygulanıyordu. Her round-trip **bir notional
   kadar nakit yok ediyordu**.

3. **Özet `funding_pnl_total` daima 0.0 raporluyordu.**
   Alan, her çıkışta sıfırlanan açık-işlem sayacını okuyordu. İşlem
   kayıtlarında funding doluydu; yalnızca özet boştu.

4. **Pencere sonu tasfiyesi slipaj kaydetmiyordu**, bu yüzden `slippage_total`
   çıkış bacağını eksik gösteriyordu.

## Kanıt

Fiyatın **sabit** olduğu bir senaryoda delta-nötr bir defterin yön P&L'i
analitik olarak tam sıfırdır; tüm getiri funding'den gelmelidir.

| | Düzeltme öncesi | Düzeltme sonrası |
|---|---:|---:|
| Final bakiye (başlangıç 10.000) | **4.588,20** | **10.588,20** |
| Getiri | **-%54,12** | **+%5,88** |
| Raporlanan funding | **0,0** | **615,78** |
| Max drawdown (sabit fiyatta!) | **%60,14** | **%0,14** |

Düzeltme sonrası bakiye bileşenlerinden yeniden kurulabiliyor:
`10.000 + 615,78 − 17,99 komisyon − 9,59 slipaj = 10.588,20`.

Maliyetler sıfırlandığında yön P&L'i **dört farklı fiyat yolunda** (sabit,
+%1.000, -%80, şiddetli salınım) **tam olarak `0.000000000`** çıkıyor — defter
artık kanıtlanabilir biçimde delta-nötrdür.

## Sonuç ve sınır

- Bu not funding_carry ailesini **kabul etmez**. Yalnızca önceki reddin
  ölçüm hatasına dayandığını, dolayısıyla **karar niteliği taşımadığını**
  kaydeder.
- Yeniden değerlendirme, **yeni bir ön-kayıt ve mühürle** ve
  `engine/research/gates.py` (plan v2.0) eşikleriyle yapılmalıdır. Eski
  koşunun sayıları taşınamaz.
- `FUTURES_*` kilitlerinin tamamı **kapalı kalır**. Bu çalışma yalnızca
  backtest/paper kanıt üretebilir; hiçbir runtime bayrağını açmaz.
- Depo bu duruma zaten örnek taşıyor: `reports/_rejected_quick_mode/NOTE.md`
  quick-mode koşularını sonuç değil **geçersiz** ilan etmişti. Aynı ilke
  burada da uygulanmıştır.

## Doğrulama

`tests/test_funding_carry_accounting.py` — 13 test; delta-nötrlük, defter
yeniden kurulabilirliği, funding raporlaması ve her iki bacağın P&L kaydı.
