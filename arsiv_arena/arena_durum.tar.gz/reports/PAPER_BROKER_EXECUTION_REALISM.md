# Paper broker yürütme gerçekçiliği — analiz ve doğru model

**Tarih:** 4 Ağustos 2026
**Durum:** Analiz tamamlandı, **uygulama yapılmadı**
**Plan maddesi:** Faz B5
**Neden şimdi uygulanmadı:** Bu değişiklik `_paper_fill` içindeki ~200 satırlık
bakiye/komisyon invariant doğrulamasına dokunur. Oturum sonuna ~45 dakika kala
başlanan yarım bir değişiklik, hiç yapmamaktan kötüdür.

---

## Sorun

Aşama 4, forward paper kayıtlarını "tek gerçek kanıt" sayar. Ama paper broker
backtest'ten **daha iyimser** bir yürütme modeli kullanıyor:

| | Backtest motoru | Paper broker |
|---|---|---|
| Slipaj | 5–20 bps, yön farkında | **0** |
| Dolum miktarı | tam | tam |
| Kuyruk pozisyonu | modellenmiyor | modellenmiyor |

Yani doğrulaması gereken şeyden daha iyimser bir ölçüm aletiyle ölçüyoruz.
`engine/exchange/client.py` docstring'i bunu dürüstçe kabul ediyor:
*"ticker data provides no defensible liquidity estimate"*.

---

## Naif çözüm YANLIŞ olurdu

İlk akla gelen "backtest gibi limit dolumlarına da slipaj ekleyelim" çözümü
**hatalıdır**:

> Bir LIMIT BUY emri 100'de duruyorsa, 100,5'ten dolmaz. Limit emrin tanımı
> budur. Limit fiyatına slipaj eklemek, borsanın yapmayacağı bir şeyi
> modellemek olur.

Limit emirlerdeki gerçek iyimserlik **fiyat** değil, **dolum olasılığı**:

1. **Kuyruk pozisyonu.** Fiyat sizin seviyenize *değdiğinde* önünüzde bir
   emir yığını vardır. Mevcut model, değdiği an tam miktarla dolduruyor.
2. **Ters seçim (adverse selection).** Limit alışınız tam olarak piyasa
   düşmeye devam edecekken dolar. Dolan emirler sistematik olarak "kötü"
   emirlerdir.

---

## Doğru model

**LIMIT emirler — fiyat değil, dolum koşulu sıkılaştırılmalı:**

```
PAPER_LIMIT_FILL_THROUGH_BIPS  (öneri: 5)
```
Emrin dolması için fiyatın limit seviyesini bu kadar **aşması** gerekir
(BUY için limit×(1−bps), SELL için limit×(1+bps)). Sadece değmek yetmez.
Bu, kuyruk pozisyonunu modellemenin en basit savunulabilir yoludur ve
backtest motorunun `adverse` intrabar politikasıyla aynı felsefededir.

**MARKET emirler — burada slipaj gerçekten doğru:**

```
PAPER_MARKET_SLIPPAGE_BIPS  (öneri: 5, severe kanıt için 20)
```
Alış fiyatı yukarı, satış fiyatı aşağı kaydırılır. Trend girişleri
`create_market_quote_order` kullandığı için bu yol fiilen aktiftir.

**Kısmi dolum** altyapısı `_paper_fill(fill_quantity=...)` ile zaten var;
şu an yalnızca hata enjeksiyonu için kullanılıyor. Likidite tahmini
olmadan olasılıksal kısmi dolum uydurmak yerine, yukarıdaki iki değişiklik
yeterli ve savunulabilir.

---

## Uygulama notları

- İki ayar da **env-only** olmalı; panel beyaz listesine girmemeli. Aksi
  halde panelden slipaj kapatılıp kanıt iyileştirilebilir.
- Mevcut paper kampanyası (`data/paper_state/spot-paper-v1.json`) bu
  değişiklikten **önce** üretildi; karşılaştırılabilirlik için Aşama 4
  kampanyası temiz bir defterle başlamalı.
- Aşama 4 kabulü hem `normal` (5 bps) hem `severe` (20 bps) varsayımıyla
  raporlanmalı — backtest kapılarındaki maliyet katmanı mantığının aynısı.

## Doğrulama ölçütü

Aynı sinyal ve aynı dönem için paper ile backtest net P&L farkı, uygulanan
slipaj/komisyon modeliyle **açıklanabilir sınırda** kalmalı. `funding_carry`
düzeltmesinde kullanılan yöntem budur: fark, bileşenlerden yeniden
kurulabilmeli.
