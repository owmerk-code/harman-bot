# Quant — Aşama 2: Strateji Ön-Kaydı

**Tarih:** 22 Temmuz 2026  
**Bu belge sonuç görülmeden dondurulmuştur.** Hiçbir parametre, eşik veya kural bu belge imzalandıktan sonra aynı sürüm içinde değiştirilemez.

---

## 1. Sürüm Kimliği ve Hipotez

| Alan | Değer |
|---|---|
| **Sürüm** | `trend_execution_v1` |
| **Aile** | Trend-following (EMA crossover + MACD teyit + RSI filtresi) |
| **Hipotez** | Spot piyasada, yüksek likiditeli paritelerde EMA yön değişimi + MACD momentum teyidi ile trend girişi yapılır; RSI aşırı alım/satım bölgelerinde taze crossover'ın gücü düşürülür. Yön ve momentum çelişkiliyse işlem açılmaz. |
| **İşlem yapılmayan durum** | Yön-momentum çelişkisi (EMA yönü ↔ MACD histogram zıt işaret), RANGING/UNKNOWN/DOWNTREND rejim (multi-TF), yetersiz veri (<60 mum), breaker açık |

## 2. Evren

- **Sadece spot**
- **Başlangıç:** BTCUSDT
- **Seçim ölçütü:** Binance USDT pariteleri, 24h işlem hacmi ≥ 10M USDT
- **Çıkarma kuralı:** Sembol delist edilirse veya 7 gün üst üste hacim eşiği altında kalırsa çıkarılır

## 3. Zaman Dilimi ve Veri

| Alan | Değer |
|---|---|
| **Zaman dilimi** | 1 saat (1h) — günlük karar, saatlik güncelleme |
| **Veri kaynağı** | Binance spot kline (open, high, low, close, volume) |
| **Eksik veri politikası** | <60 mum varsa işlem açılmaz (observe-only). Eksik mum varsa mevcut veriyle değerlendirme yapılır |
| **Saat dilimi** | UTC |
| **Maliyet verisi** | Gerçek borsa komisyon oranı (varsayılan %0.1), spread-slippage muhafazakâr (%0.05) |

## 4. Giriş/Çıkış Kuralları (Deterministik)

### Giriş (FLAT → LONG)
1. TREND_EXECUTION_ENABLED = true
2. TREND_EXECUTION_AUTOPILOT_ENABLED = true (veya force)
3. PAPER_TRADING = true (veya MAINNET_APPROVED)
4. Breaker kapalı
5. Multi-TF rejim: 1h + 4h + 1d'den en az 2'si UPTREND
6. Signal: STRONG_BUY veya BUY
7. Rearm gerekiyorsa bekle (stop sonrası sinyal reset)

### Çıkış (LONG → FLAT)
1. **Stop:** Trailing stop (başlangıç %10, watermark'tan itibaren %10 aşağı) VEYA hard stop (giriş fiyatının %10 altı)
2. **Signal exit:** target_long=False olduğunda (EMA yön değişimi)
3. **Regime exit:** UPTREND değil ve yüksek volatilite değilse (sinyal beklemeden çıkış YOK, sadece uyarı)

### Stop sonrası
- Rearm flag set edilir; sinyal resetlenene kadar yeni giriş engellenir

## 5. Pozisyon Boyutlama

| Alan | Değer |
|---|---|
| **İşlem başı risk** | Portföyün %20'si (TREND_EXECUTION_ALLOCATION_PERCENT) |
| **Maksimum quote** | 100 USDT (TREND_EXECUTION_MAX_QUOTE) |
| **Eşzamanlı pozisyon** | 1 (tek sembol: BTCUSDT) |
| **Nakit oranı** | En az %30 rezerv (MIN_CASH_RESERVE_PERCENT) |
| **Portföy değeri** | Paper bakiye (başlangıç 250 USDT) |

**Formül:** `min(portfolio * allocation_pct / 100, max_quote)`
- portfolio = 250 USDT → min(250 × 0.20, 100) = 50 USDT
- portfolio = 1000 USDT → min(1000 × 0.20, 100) = 100 USDT

## 6. Maliyet Modeli

| Kalem | Varsayılan |
|---|---|
| **Maker komisyonu** | %0.1 |
| **Taker komisyonu** | %0.1 |
| **Spread/slippage** | %0.05 (market emirleri için muhafazakâr) |
| **Min notional** | 5 USDT |
| **Min lot** | 0.00001 BTC |
| **Precision** | Binance spot kuralları (lot_step_size, tick_size) |

Backtest ve paper'da her işlemde giriş+çıkış için %0.2 toplam maliyet (komisyon × 2 + slippage) uygulanır.

## 7. Koruma Kuralları

| Kural | Değer |
|---|---|
| **Trailing stop** | %10 (watermark'tan itibaren) |
| **Hard stop** | Giriş fiyatının %10 altı |
| **Günlük zarar limiti** | Config'den (DAILY_LOSS_LIMIT) |
| **Maksimum drawdown** | Config'den (MAX_DRAWDOWN_PERCENT) |
| **Breaker** | Risk.tripped = true ise tüm yeni girişler engellenir |
| **Reconciliation** | Bot-sahipli bakiye ile DB state tutarsızsa RiskError + fail-closed |
| **No-trade rejimleri** | RANGING, UNKNOWN, yüksek volatilite (1h+4h+1d konsensüs) |
| **Veri hatası** | Fiyat alınamazsa, mum çekilemezse → error döner, işlem açılmaz |

## 8. Test Takvimi

| Aşama | Dönem | Açıklama |
|---|---|---|
| **Eğitim** | 2020-01 — 2023-12 | Parametre geliştirme |
| **Doğrulama** | 2024-01 — 2024-12 | Walk-forward validasyonu |
| **Dokunulmamış holdout** | 2025-01 — 2025-12 | **Hiçbir parametre bu döneme ayarlanmaz** |
| **Stres testi** | 2020-01 — 2025-12 | Çöküş, yüksek vol, düşük hacim bölgeleri |
| **Paper kampanya** | Holdout geçerse → 90 gün | Mainnet-public fiyat, paper sermaye |

## 9. Kabul/Ret Eşikleri

| Eşik | Değer |
|---|---|
| **Net P&L (maliyet sonrası)** | Pozitif (eğitim + validasyon + holdout ayrı ayrı) |
| **Holdout P&L** | Negatifse → **RET** |
| **Maksimum forward drawdown** | ≤ %12 |
| **İşlem sayısı** | ≥ 30 (anlamlı istatistik) |
| **Kazanma oranı** | Kayıt amaçlı (geçit değil) |
| **Rejim dayanıklılığı** | Yalnız tek rejimden kazanç geliyorsa → **RET** |
| **Monte Carlo ruin** | ≥ %30 → **RET** |
| **Walk-forward pozitif pencere** | ≥ %60 |
| **Selection risk (PBO)** | Düşük/orta olmalı |

## 10. Parametre Sayısı

| Parametre | Varsayılan | Aralık (deneme) |
|---|---|---|
| ema_fast | 20 | 10-40 |
| ema_slow | 50 | 30-100 |
| macd_fast | 12 | Sabit |
| macd_slow | 26 | Sabit |
| macd_signal | 9 | Sabit |
| rsi_length | 14 | 10-20 |
| rsi_overbought | 70 | 65-80 |
| rsi_oversold | 30 | 20-35 |
| trailing_stop_bips | 1000 (%10) | 500-1500 |
| stop_loss_pct | 10.0 | 5-15 |
| allocation_pct | 20 | 10-30 |
| max_quote | 100 | 50-200 |

**Serbest parametre sayısı:** 8 (belirtilen aralıklarda)
**Sabit parametreler:** 4 (MACD)
**Deneme bütçesi:** En fazla 50 kombinasyon

---

## Karar

**Bu belge 22 Temmuz 2026'da dondurulmuştur.** Sonuçlara bakılarak hiçbir değişiklik yapılmaz. Değişiklik gerekirse yeni sürüm kimliği ile baştan başlanır.

İmza: (manuel inceleme için boş)
