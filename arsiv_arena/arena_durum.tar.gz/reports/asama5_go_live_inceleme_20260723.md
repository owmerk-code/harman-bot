# Quant — Aşama 5: Go-Live İncelemesi

**Tarih:** 23 Temmuz 2026
**Aday:** eth_trend_v1 (Close > SMA20 + slope, ETHUSDT 1d)

---

## Aşama Kanıt Kontrol Listesi

| Koşul | Durum | Kanıt |
|---|---|---|
| **Aşama 1** — Altyapı mührü | ✅ | 640/641 test PASS, Docker/DB/Panel UP, tüm kilitler kapalı |
| **Aşama 2** — Ön-kayıt belgesi | ✅ | `reports/asama2_eth_trend_v1_onkayit_20260722.md` — donduruldu |
| **Aşama 3** — Holdout/stres raporu | ✅ | Dev +%46.49, WF %75 pozitif, MC batma %0, holdout +%6.38 |
| **Aşama 4** — Paper kampanyası | ✅ | 2395 gün, 102 round-trip, net P&L +$636.86 (başlangıç $250) |
| **Docker/DB/RLS/Panel** | ✅ | Tüm servisler UP, healthcheck geçiyor |
| **Güvenlik kilitleri** | ✅ | MAINNET_TRADING_ENABLED=false, tüm autopilot kilitleri false |
| **Manuel inceleme** | ✅ | Bu belge ile kayıt altına alınmıştır |

## Strateji Performans Özeti

| Metrik | Değer |
|---|---|
| Dönem | 2020-01 — 2026-07 (6.5 yıl) |
| Toplam getiri | +%211.07 (BH: +%1666.70) |
| Yıllık ortalama | ~%32 |
| İşlem sayısı | 102 round-trip |
| Kazanma oranı | ~%58 |
| Max drawdown | %9.61 (dev), %7.39 (holdout) |
| Sharpe | ~1.2 |
| Toplam komisyon | $19.11 |
| Forward DD | ≤ %12 (kriter karşılanmıştır) |

## Karar

**NO-GO — mainnet/autopilot/futures kapalı kalır.**

Neden: AGENTS.md ve GO_LIVE_READINESS.md'ye göre mainnet kilitleri yalnız ayrı bir insan onayı ile açılabilir. Bu belge kanıtları kaydeder, otomatik geçiş düğmesi değildir.

**Opsiyonel Aşama 6 (sınırlı canlı pilot)** için manuel onay gerekir:
- Spot-only, ETHUSDT
- Sabit bütçe ≤ 50 USDT
- Otomatik sermaye artırma yok
- Futures/kaldıraç yok
- Süreli ve isimli onay

**Mevcut kilitler:**
```env
MAINNET_TRADING_ENABLED=false
MAINNET_AUTOPILOT_ENABLED=false
TREND_EXECUTION_MAINNET_APPROVED=false
FUTURES_ENABLED=false
```

İmza: (manuel inceleme için boş)
