# Mühür bütünlük notu — 4 Ağustos 2026

**Bulgu:** `spot_v7` ve `spot_v8` ön-kayıt mühürleri şu an doğrulamayı
**geçmiyor**. Sebepleri farklı; biri normal, biri benim tasarım hatam.

Mühür mekanizması doğru çalıştı — değişikliği yakaladı. Sorun mekanizmada
değil, mühürlenen dosya kümesinde ve değişiklik sırasındadır.

---

## 1. `spot_v7` — mühürden sonra motor değişti (normal, ama kaydedilmeli)

| Dosya | Durum |
|---|---|
| `engine/backtest/portfolio_engine.py` | **değişti** |

`spot_v8` yazılırken motora `weight_fn` enjeksiyonu eklendi; böylece iki aday
**aynı yürütme sözleşmesiyle** (maliyet, delist tasfiyesi, look-ahead, defter)
ölçülebiliyor. Bu, karşılaştırılabilirlik için gerekliydi.

**Sonucu geçersiz kılar mı? Hayır.**
`reports/spot_v7_validation_20260804_002122.json` içindeki `seal_sha256` bloğu,
koşu ANINDAKI hash'leri kaydeder. Kanıt zinciri sağlamdır: rapor, hangi kod
sürümüyle üretildiğini kendi içinde taşır.

**Sonucu yeniden üretmek için:** o commit'e (`06ce114`) dönmek gerekir. Mevcut
kodla `spot_v7_validation.py` çalıştırılırsa mühür ihlali verip **doğru şekilde
reddedecektir**.

---

## 2. `spot_v8` — mühür kompozisyonu hatalı (benim hatam)

| Dosya | Durum | Sebep |
|---|---|---|
| `scripts/spot_v8_validation.py` | değişti | Koşudan sonra `mark_consumed()` çağrısı eklendi |
| `research/holdout_ledger.json` | değişti | **Koşunun kendisi bu dosyayı değiştiriyor** |

İkincisi bir tasarım hatasıdır: **koşunun mutasyona uğrattığı bir dosya mühre
konulmamalıdır.** `holdout_ledger.json`'ı mühre koymak, mührün koşudan sonra
zorunlu olarak bozulması demektir. Kendi kendini bozan bir mühür, mühür değildir.

Runner'ın değişmesi de aynı sınıftan: `mark_consumed()` çağrısını koşudan
*sonra* ekledim, yani raporlanan sonuç mühürlenen runner ile üretilmedi —
davranış farkı yalnızca defter yazımıdır ve ölçümleri etkilemez, fakat
**mühür disiplini açısından kusurdur**.

---

## 3. Sonuçlara etkisi

Hiçbiri ölçümleri değiştirmez:

- `spot_v7` REJECTED (4/10) — motor mantığı değişmedi, yalnızca fonksiyon
  enjeksiyonu eklendi; varsayılan davranış aynı.
- `spot_v8` REJECTED (7/10) — defter yazımı ölçüm üretmez.

Her iki rapor da kendi `seal_sha256` bloğunu taşır; koşu anındaki durum
kayıtlıdır.

---

## 4. Bundan sonrası için kural

Bir sonraki ön-kayıtta mühür kompozisyonu şöyle olmalı:

**Mühre GİRER** (koşunun okuduğu, değiştirmediği):
- protokol, tasarım spec'i
- strateji modülü, motor, evren yükleyici
- eşik modülü, metrik/robustness modülleri
- testler, evren manifesti

**Mühre GİRMEZ** (koşunun yazdığı):
- `holdout_ledger.json` — koşu tüketir
- rapor dosyaları
- log/kanıt dizinleri

Ayrıca runner, koşudan **önce** son hâline getirilmelidir. Koşu sonrası
düzeltme gerekiyorsa yeni bir mühür ve yeni bir koşu gerekir.

---

**Hazırlayan:** Claude (Anthropic)
**Not:** Bu kusuru gizlemek yerine kaydetmek, projenin kendi kuralıdır —
`reports/_rejected_quick_mode/NOTE.md` ve `funding_carry_INVALID_NOTE.md`
aynı ilkeyle yazılmıştır.
