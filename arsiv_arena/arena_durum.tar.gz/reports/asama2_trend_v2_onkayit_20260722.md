# Quant — Aşama 2: Strateji Ön-Kaydı (trend_execution_v2)

**Tarih:** 22 Temmuz 2026
**Bu belge sonuç görülmeden dondurulmuştur.**

---

## 1. Sürüm Kimliği ve Hipotez

| Alan | Değer |
|---|---|
| **Sürüm** | `trend_execution_v2` |
| **Aile** | Günlük trend-following (EMA + MACD + RSI + ADX) |
| **Hipotez** | Günlük zaman diliminde EMA yön değişimi + MACD momentum + ADX trend gücü filtresi ile daha az işlem, daha yüksek sinyal kalitesi. ADX ≥ 25 şartı yalancı kırılımları eler. |
| **İşlem yapılmayan durum** | ADX < 25 (trend gücü yetersiz), yön-momentum çelişkisi, rejim UPTREND değil |

## 2. Evren

BTCUSDT spot, zamanla genişletilebilir.

## 3. Zaman Dilimi ve Veri

**1 gün (1d)** — UTC, Binance spot kline, ≥ 250 mum.

## 4. Giriş/Çıkış

**Giriş (FLAT → LONG):** `EMA20 > EMA50 AND MACD histogram > 0 AND ADX ≥ 25`
**Çıkış (LONG → FLAT):** Trailing stop %15 VEYA `EMA20 < EMA50` (trend dönüşü)

## 5. Pozisyon Boyutlama

Aynı: %20 portföy, max 100 USDT, ≥%30 nakit rezerv.

## 6. Maliyet Modeli

%0.1 komisyon + %0.05 slippage (market emir). Toplam: %0.25 giriş+çıkış.

## 7. Koruma Kuralları

Trailing stop %15, hard stop %10, günlük zarar limiti, breaker, reconciliation fail-closed.

## 8. Test Takvimi

| Dönem | Rol |
|---|---|
| 2020-01 — 2023-12 | Development |
| 2024-01 — 2024-12 | Walk-forward validation |
| 2025-01 — 2025-12 | Dokunulmamış holdout |

## 9. Eşikler

| Eşik | Değer |
|---|---|
| Dev net P&L | >0 |
| Walk-forward pozitif pencere | ≥%50 |
| Monte Carlo ruin | <%30 |
| Holdout P&L | >0 |
| Holdout DD | ≤%12 |

## 10. Parametreler

| Parametre | Varsayılan | Deneme |
|---|---|---|
| ema_fast | 20 | Sabit |
| ema_slow | 50 | Sabit |
| adx_min | 25 | 20-30 |
| trailing_stop_pct | 15 | 10-20 |

**Serbest parametre:** 2 (adx_min, trailing_stop_pct)
**Deneme bütçesi:** 10 kombinasyon

---

**22 Temmuz 2026'da dondurulmuştur.**
