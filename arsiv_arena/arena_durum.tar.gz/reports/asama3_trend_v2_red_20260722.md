# Quant — Aşama 3: trend_execution_v2 Red Raporu

**Tarih:** 22 Temmuz 2026
**Karar:** REJECTED

## Kapı Sonuçları

| Kapı | Sonuç | Detay |
|---|---|---|
| Dev backtest | ✅ PASS | +28.18% (eşik: >0) |
| Walk-forward | ⛔ FAIL | 4 pencere, %25 pozitif (eşik: ≥%50) |
| Monte Carlo | ✅ PASS | Batma %0, kâr olasılığı %67 |
| Holdout | ⛔ FAIL | -1.53% (eşik: >0) |

## Red Nedeni

Günlük ADX+EMA+MACD stratejisi çok az işlem üretti (38 trade/4 yıl). Walk-forward'da 3/4 pencerede trade açılmamış. Holdout 2025'te -%1.53. Düşük işlem sayısı istatistiksel anlamlılığı zayıflatıyor.
