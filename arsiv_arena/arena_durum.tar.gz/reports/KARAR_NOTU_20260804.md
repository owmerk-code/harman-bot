# Karar Notu — 4 Ağustos 2026

**Kime:** Proje sahibi
**Konu:** 13 aile reddedildi, rezerve holdout kalmadı. Sıradaki adım gerçek bir karar.

---

## 1. Nerede olduğumuz

| | |
|---|---|
| Denenen strateji ailesi | **13** |
| Kabul edilen | **0** |
| Aşama 1 (altyapı) | soak koşuyor, 7 Ağustos'ta biter |
| Aşama 3 | son iki aday da reddedildi |
| Rezerve tarihsel holdout | **kalmadı** |
| Canlı karar | `NO-GO` |

Bu oturumda eklenen: survivorship-bias'sız 574 sembollük evren, PBO ve
Deflated Sharpe, holdout tüketim defteri, dört muhasebe hatasının düzeltilmesi.
**Ölçüm aleti artık güvenilir. Ölçülen şey hâlâ sıfır.**

---

## 2. Adını koymak gerekiyor

13 aile şunları kapsadı: kırılım, haftalık SMA, Donchian, TSMOM (tek ve
çok varlıklı), ATR-adaptif grid, Bollinger mean-reversion, grid+trend,
volatilite hasadı, funding carry, EMA/MACD/RSI trend, kesitsel momentum.

Hepsi reddedildi. Bu artık tek tek şanssızlık değil, bir **örüntü**:

> Günlük kripto barları üzerinde, standart teknik mekaniklerle, ücret ve
> slipaj sonrası kalıcı bir avantaj bulunamadı.

Bu ihtimal projenin başından beri planda yazılıydı ("avantaj yoksa stratejiyi
reddet"). Şu an olan tam olarak budur ve sistem doğru çalışıyor.

Yanıltıcı olmayan tek okuma şudur: **elimizdeki veri ve yöntemlerle ulaşılabilir
basit sistematik stratejilerin edge'i yok.**

---

## 3. Sert kısıt: holdout bitti

2025 dönemi 12 kez, 2026 H1 bir kez puanlandı. Geriye dokunulmamış tarihsel
dönem kalmadı.

Yani **bundan sonraki her aday için** dürüst bir out-of-sample ölçümü
yalnızca iki yolla gelir:

1. **İleriye dönük zaman** — Aşama 4 forward paper (90 gün)
2. **Takvimin ilerlemesi** — 2026 H2 tamamlandığında (Aralık 2026) yeni bir
   tarihsel pencere açılır

Yeni bir aday üretip eski veride test etmek artık **bilgi üretmez**.

---

## 4. Seçenekler

### A. `funding_carry` v2 — yapısal olarak farklı olan tek fikir

Delta-nötr: spot al + perp sat. Fiyat yönünden **bağımsız**; getirisi bir
örüntü tahmini değil, gerçek bir **risk primi** (uzun pozisyon sahipleri
kısa pozisyon sahiplerine öder).

- Önceki reddi **kanıtlanmış bir kod hatasıydı** — dört muhasebe hatası
  düzeltildi, defter artık kanıtlanabilir şekilde delta-nötr
  ([`funding_carry_INVALID_NOTE.md`](funding_carry_INVALID_NOTE.md)).
- Diğer 13 ailenin hepsi yön tahmini yapıyordu. Bu yapmıyor.
- **Futures gerektirir.** Sizin kararınız "araştırmaya açık, canlıya kapalı"
  idi; bu kapsamda kalır, `FUTURES_*` kilitleri kapalıdır.
- Elimizde 2019-09 → 2024-12 funding verisi var.

**Zayıflığı:** holdout için 2026 H2'yi beklemek veya doğrudan forward paper'a
geçmek gerekir.

### B. Aşama 4'e `spot_v7` ile araştırma amaçlı geçmek

`spot_v7` Aşama 3'ü geçmedi ama **overfit değildi** (PBO %8,57) ve holdout'ta
buy & hold'u 7,46 puan yendi. Forward paper, kirlenmemiş veri üretmenin tek
yolu olduğu için, onu *kabul edilmiş gibi* değil *araştırma amaçlı* forward'a
almak düşünülebilir.

**Ama plan bunu yasaklıyor** ve haklı olarak: reddedilmiş bir adayı forward'a
almak, red kararını fiilen geçersiz kılar. Bu seçenek ancak planın açıkça
değiştirilmesiyle mümkün — ve ben önermiyorum.

### C. Durmak ve altyapıyı tamamlamak

Aşama 1'i kapat, B5'i (paper broker slipajı) uygula, sistemi çalışır durumda
bırak. Strateji arayışını Aralık 2026'da yeni holdout açıldığında sürdür.

**Dürüst yanı:** para kazandırmaz ama kayıp da ettirmez ve altyapı hazır kalır.

### D. Kapsamı değiştirmek

Şu ana kadarki bütün çalışma **günlük bar + spot + yön tahmini** kutusunda.
Bu kutunun dışına çıkmak farklı veri gerektirir: intraday barlar, emir defteri,
on-chain veri, ya da market-making. Bunların hiçbiri şu an elimizde yok ve
her biri haftalarca altyapı işi demek.

---

## 5. Önerim

**A — `funding_carry` v2.**

Gerekçe: 13 ailenin 13'ü de yön tahmini yapıyordu ve 13'ü de başarısız oldu.
Yön tahmininin bu veri setinde çalışmadığına dair kanıt artık güçlü. Delta-nötr
carry, denenmemiş **tek yapısal olarak farklı** fikirdir ve reddi kanıtlanmış
bir hatadan kaynaklanmıştı.

Ayrıca beklentiyi doğru kurmak gerekir: funding carry'nin gerçek getirisi
tipik olarak **yıllık %5–15** bandındadır ve fonlama oranı negatife döndüğünde
durur. 1.000–5.000 USD'de bu, yılda **50–750 USD**. Küçük ama **gerçek** ve
yön riski taşımıyor.

Eğer bu da başarısız olursa, dürüst sonuç şudur: bu veri ve bu ölçekte
sistematik bir avantaj bulunamamıştır — ve o da geçerli bir cevaptır.

---

## 6. Karar bekleyen noktalar

1. Sıradaki aday: **A**, **C**, **D** ya da başka bir yön?
2. funding_carry v2 seçilirse holdout: 2026 H2'yi beklemek mi, doğrudan
   forward paper mı?
3. Aşama 1 soak'ı 7 Ağustos'ta bittiğinde kapanış raporu üretilsin mi?

---

**Hazırlayan:** Claude (Anthropic)
**Karar:** Proje sahibine aittir. Bu not bir öneri sunar, karar vermez.
