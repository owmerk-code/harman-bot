# Quant — Aşama 2: eth_trend_v1 Ön-Kaydı

**22 Temmuz 2026 — Dondurulmuştur.** Sonuç görülmeden imzalanmıştır.

---

**Sürüm:** `eth_trend_v1`
**Hipotez:** ETH/USDT günlük fiyatı yükselen 20 günlük hareketli ortalamanın üzerindeyken long, altındayken cash. Trend yön değiştirdiğinde mevcut olmayan trende girmek yerine koruma amaçlı nakitte kalınır.

**Giriş (FLAT → LONG):** `Close > SMA20 AND SMA20[0] > SMA20[-5]`
**Çıkış (LONG → FLAT):** `Close < SMA20` VEYA trailing stop %15 VEYA stop loss %10

**Zaman dilimi:** 1d (günlük)
**Evren:** ETHUSDT (spot)
**Boyutlama:** %20 portföy, max 100 USDT, ≥%30 nakit rezerv

**Serbest parametreler:**
| Parametre | Varsayılan | Deneme aralığı |
|---|---|---|
| sma_period | 20 | 15-30 |
| slope_lookback | 5 | 3-10 |
| trailing_stop_pct | 15 | 10-20 |

**Deneme bütçesi:** 20 kombinasyon

**Test takvimi:**
- Development: 2020-01 — 2023-12
- Walk-forward: 2024-01 — 2024-12 (4 pencere)
- Holdout: 2025-01 — 2025-12 (dokunulmamış)

**Kabul eşikleri:**
| Kapı | Eşik |
|---|---|
| Dev P&L | >%0 |
| Walk-forward pozitif pencere | ≥%50 |
| Monte Carlo batma | <%30 |
| Holdout P&L | >%0 |
| Holdout max DD | ≤%12 |
