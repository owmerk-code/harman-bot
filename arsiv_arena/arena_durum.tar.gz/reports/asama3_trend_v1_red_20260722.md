# Quant — Aşama 3: trend_execution_v1 Red Raporu

**Tarih:** 22 Temmuz 2026
**Karar:** REJECTED

## Kapı Sonuçları

| Kapı | Sonuç | Detay |
|---|---|---|
| Development backtest | ⛔ FAIL | -14.64% (eşik: >0) |
| Walk-forward | ✅ PASS | 4 pencere, %50 pozitif (eşik: ≥%50) |
| Monte Carlo | ✅ PASS | Batma %0 (eşik: <%30) |
| Holdout | ⛔ FAIL | -13.24%, DD %14.24 (eşik: >0, ≤%12) |

## Red Nedeni

Look-ahead bias düzeltildikten sonra trend_execution_v1 (EMA 20/50 + MACD + RSI, 1h) dört yıllık geliştirme döneminde -%14.64 kaybetti. 1h zaman diliminde EMA/MACD sinyalleri çok sık dönüyor, işlem başına beklenti negatif.

## Sonraki Aday İçin Dersler

- 1h → **1d** zaman dilimi (daha az işlem, daha güçlü sinyal)
- Daha güçlü trend filtresi (ADX + EMA eğimi)
- Daha az parametre
